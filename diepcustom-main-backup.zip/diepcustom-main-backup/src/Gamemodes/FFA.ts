/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import ArenaEntity, { ArenaState } from "../Native/Arena";
import Boulder from "../Entity/Misc/Boulder";
import MazeWall from "../Entity/Misc/MazeWall";
import { VectorAbstract } from "../Physics/Vector";
import GameServer from "../Game";
import ObjectEntity from "../Entity/Object";

import Pentagon from "../Entity/Shape/Pentagon";

import { Color, ArenaFlags, PhysicsFlags } from "../Const/Enums";
import { NameGroup } from "../Native/FieldGroups";
import AbstractShape from "../Entity/Shape/AbstractShape";

/**
 * FFA Gamemode Arena
 */
export default class FFAArena extends ArenaEntity {
    private placeholderX = 0;
    private placeholderY = 0;

    public constructor(game: GameServer) {
        super(game);

        const distFromMapEdgeX = this.arenaData.rightX / 2.5;
        const distFromMapEdgeY = this.arenaData.topY / 2.5;
        const RockChance = 0.3;
        const groupSize = Math.floor(this.arenaData.rightX / 6)
        let bouldersInGroup = Math.random() * 3 + 5;
        let xPositions = [];
        let yPositions = [];
        let canBePlaced: boolean = false;

        for (let i = 0; i < bouldersInGroup; i++) {
            this.placeholderX = Math.random() * groupSize - groupSize / 2;
            this.placeholderY = Math.random() * groupSize - groupSize / 2;

            if (xPositions.length != 0) {
                while (true) {
                    canBePlaced = true;
                    for (let j = 0; j < xPositions.length; j++) {
                        if (Math.sqrt((xPositions[j] - this.placeholderX) ** 2 + (yPositions[j] - this.placeholderY) ** 2) < 85 * 3.5) {
                            canBePlaced = false;
                            this.placeholderX = Math.random() * groupSize - groupSize / 2;
                            this.placeholderY = Math.random() * groupSize - groupSize / 2;
                        }
                    }
                    if (canBePlaced) break;
                }
            }
            xPositions.push(this.placeholderX);
            yPositions.push(this.placeholderY);

        }
        for (let k = 0; k < bouldersInGroup; k++) {
            new Boulder(this.game, this.arenaData.leftX + distFromMapEdgeX + xPositions[k], this.arenaData.bottomY + distFromMapEdgeY + yPositions[k], Math.random() <= RockChance);
        }
        ////////////
        ////////////
        bouldersInGroup = Math.random() * 3 + 5;
        xPositions = [];
        yPositions = [];
        canBePlaced = false;

        for (let i = 0; i < bouldersInGroup; i++) {
            this.placeholderX = Math.random() * groupSize - groupSize / 2;
            this.placeholderY = Math.random() * groupSize - groupSize / 2;

            if (xPositions.length != 0) {
                while (true) {
                    canBePlaced = true;
                    for (let j = 0; j < xPositions.length; j++) {
                        if (Math.sqrt((xPositions[j] - this.placeholderX) ** 2 + (yPositions[j] - this.placeholderY) ** 2) < 85 * 3) {
                            canBePlaced = false;
                            this.placeholderX = Math.random() * groupSize - groupSize / 2;
                            this.placeholderY = Math.random() * groupSize - groupSize / 2;
                        }
                    }
                    if (canBePlaced) break;
                }
            }
            xPositions.push(this.placeholderX);
            yPositions.push(this.placeholderY);

        }
        for (let k = 0; k < bouldersInGroup; k++) {
            new Boulder(this.game, this.arenaData.rightX - distFromMapEdgeX + xPositions[k], this.arenaData.bottomY + distFromMapEdgeY + yPositions[k], Math.random() <= RockChance);
        }
        ////////////
        ////////////
        bouldersInGroup = Math.random() * 3 + 5;
        xPositions = [];
        yPositions = [];
        canBePlaced = false;

        for (let i = 0; i < bouldersInGroup; i++) {
            this.placeholderX = Math.random() * groupSize - groupSize / 2;
            this.placeholderY = Math.random() * groupSize - groupSize / 2;

            if (xPositions.length != 0) {
                while (true) {
                    canBePlaced = true;
                    for (let j = 0; j < xPositions.length; j++) {
                        if (Math.sqrt((xPositions[j] - this.placeholderX) ** 2 + (yPositions[j] - this.placeholderY) ** 2) < 85 * 3) {
                            canBePlaced = false;
                            this.placeholderX = Math.random() * groupSize - groupSize / 2;
                            this.placeholderY = Math.random() * groupSize - groupSize / 2;
                        }
                    }
                    if (canBePlaced) break;
                }
            }
            xPositions.push(this.placeholderX);
            yPositions.push(this.placeholderY);

        }
        for (let k = 0; k < bouldersInGroup; k++) {
            new Boulder(this.game, this.arenaData.rightX - distFromMapEdgeX + xPositions[k], this.arenaData.topY - distFromMapEdgeY + yPositions[k], Math.random() <= RockChance);
        }
        ////////////
        ////////////
        bouldersInGroup = Math.random() * 3 + 5;
        xPositions = [];
        yPositions = [];
        canBePlaced = false;

        for (let i = 0; i < bouldersInGroup; i++) {
            this.placeholderX = Math.random() * groupSize - groupSize / 2;
            this.placeholderY = Math.random() * groupSize - groupSize / 2;

            if (xPositions.length != 0) {
                while (true) {
                    canBePlaced = true;
                    for (let j = 0; j < xPositions.length; j++) {
                        if (Math.sqrt((xPositions[j] - this.placeholderX) ** 2 + (yPositions[j] - this.placeholderY) ** 2) < 85 * 4) {
                            canBePlaced = false;
                            this.placeholderX = Math.random() * groupSize - groupSize / 2;
                            this.placeholderY = Math.random() * groupSize - groupSize / 2;
                        }
                    }
                    if (canBePlaced) break;
                }
            }
            xPositions.push(this.placeholderX);
            yPositions.push(this.placeholderY);

        }
        for (let k = 0; k < bouldersInGroup; k++) {
            new Boulder(this.game, this.arenaData.leftX + distFromMapEdgeX + xPositions[k], this.arenaData.topY - distFromMapEdgeY + yPositions[k], Math.random() <= RockChance);
        }
    }
}



