/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import Client from "../Client";
import { Color, ArenaFlags, ClientBound, StyleFlags } from "../Const/Enums";
import Core from "../Entity/Misc/Core";
import Dominator from "../Entity/Misc/Dominator";
import MazeWall from "../Entity/Misc/MazeWall";
import TeamBase from "../Entity/Misc/TeamBase";
import { TeamEntity } from "../Entity/Misc/TeamEntity";
import TeamMazeWall from "../Entity/Misc/TeamMazeWall";
import ShapeManager from "../Entity/Shape/Manager";
import TankBody from "../Entity/Tank/TankBody";
import GameServer from "../Game";
import ArenaEntity, { ArenaState } from "../Native/Arena";
import ClientCamera from "../Native/Camera";
import { Entity } from "../Native/Entity";
import * as util from "../util";



const ARENA_SIZE = 11150;
const BASE_SIZE = 635;

/**
 * Domination Gamemode Arena
 */

export class Domination2ShapeManager extends ShapeManager {
    protected get wantedShapes() {
        return (68);
    }
}

export default class Domination2Arena extends ArenaEntity {
    protected shapes: ShapeManager = new Domination2ShapeManager(this);
    public redTeam: TeamEntity = new TeamEntity(this.game, Color.TeamRed);
    public blueTeam: TeamEntity = new TeamEntity(this.game, Color.TeamBlue);
    public isOpen: boolean = true;
    public bluePlayerCount = 0;
    public redPlayerCount = 0;

    public topCoreBaseRed: TeamBase = new TeamBase(
        this.game,
        this.redTeam,
        635 * 8, // x
        -635 * 4, // y
        BASE_SIZE,
        BASE_SIZE,
        false
    );
    public midCoreBaseRed: TeamBase = new TeamBase(
        this.game,
        this.redTeam,
        635 * 8, // x
        -635 * 0, // y
        BASE_SIZE,
        BASE_SIZE,
        false
    );
    public botCoreBaseRed: TeamBase = new TeamBase(
        this.game,
        this.redTeam,
        635 * 8, // x
        -635 * -4, // y
        BASE_SIZE,
        BASE_SIZE,
        false
    );
    public topCoreBaseBlue: TeamBase = new TeamBase(
        this.game,
        this.blueTeam,
        -635 * 8, // x
        -635 * 4, // y
        BASE_SIZE, // width
        BASE_SIZE, // height
        false // if it damages other players
    );
    public midCoreBaseBlue: TeamBase = new TeamBase(
        this.game,
        this.blueTeam,
        -635 * 8, // x
        -635 * 0, // y
        BASE_SIZE, // width
        BASE_SIZE, // height
        false // if it damages other players
    );
    public botCoreBaseBlue: TeamBase = new TeamBase(
        this.game,
        this.blueTeam,
        -635 * 8, // x
        -635 * -4, // y
        BASE_SIZE, // width
        BASE_SIZE, // height
        false // if it damages other players
    );
    public topRedCore: Core = new Core(
        this,
        this.topCoreBaseRed.positionData.x,
        this.topCoreBaseRed.positionData.y,
        this.redTeam,
        this.topCoreBaseRed,
        this.topCoreBaseRed,
        false
    );
    public midRedCore: Core = new Core(
        this,
        this.midCoreBaseRed.positionData.x,
        this.midCoreBaseRed.positionData.y,
        this.redTeam,
        this.midCoreBaseRed,
        this.midCoreBaseRed,
        true
    );
    public botRedCore: Core = new Core(
        this,
        this.botCoreBaseRed.positionData.x,
        this.botCoreBaseRed.positionData.y,
        this.redTeam,
        this.botCoreBaseRed,
        this.botCoreBaseRed,
        false
    );
    public topBlueCore: Core = new Core(
        this,
        this.topCoreBaseBlue.positionData.x,
        this.topCoreBaseBlue.positionData.y,
        this.blueTeam,
        this.topCoreBaseBlue,
        this.topCoreBaseBlue,
        false
    );
    public midBlueCore: Core = new Core(
        this,
        this.midCoreBaseBlue.positionData.x,
        this.midCoreBaseBlue.positionData.y,
        this.blueTeam,
        this.midCoreBaseBlue,
        this.midCoreBaseBlue,
        true
    );
    public botBlueCore: Core = new Core(
        this,
        this.botCoreBaseBlue.positionData.x,
        this.botCoreBaseBlue.positionData.y,
        this.blueTeam,
        this.botCoreBaseBlue,
        this.botCoreBaseBlue,
        false
    );

    public playerTeamMap: Map<Client, Core> = new Map();
    public coresDestroyed = [this.topBlueCore, this.topRedCore, this.botBlueCore, this.botRedCore, this.midBlueCore, this.midRedCore];

    public constructor(game: GameServer) {
        super(game);
        this.shapeScoreRewardMultiplier = 3.0;

        this.updateBounds(635 * 19, 635 * 19);

        this.arenaData.values.flags |= ArenaFlags.hiddenScores;

        // HORRIBLE MAZE GENERATION CODE INCOMING //
        new MazeWall(this.game, this.arenaData.leftX - 635 + 635 * 21 / 2, this.arenaData.bottomY + 635 / 2 - 635 * 1.5, 635 * 6, 635 * 21);
        new MazeWall(this.game, this.arenaData.leftX - 635 + 635 * 21 / 2, this.arenaData.topY - 635 / 2 + 635 * 1.5, 635 * 6, 635 * 21);
        new MazeWall(this.game, this.arenaData.leftX - 635 / 2, this.arenaData.topY + 635 * 19 / 2, 635 * 11, 635);
        new MazeWall(this.game, this.arenaData.rightX + 635 / 2, this.arenaData.topY + 635 * 19 / 2, 635 * 11, 635);
        let rand = Math.random();

        // Generates the ~3 blue maze walls between the cores
        if (rand >= 0.5) {
            new TeamMazeWall(this, -635 * 8, -635 * 2, 635, 635, this.blueTeam, Color.TeamBlue);
        }
        else {
            new TeamMazeWall(this, -635 * 8, -635 * -2, 635, 635, this.blueTeam, Color.TeamBlue);
        }

        rand = Math.random();
        if (rand <= 1 / 2) new MazeWall(this.game, -635 * 7, -635 * -2, 635, 635);
        else if (rand <= 3 / 4) new TeamMazeWall(this, -635 * 7, -635 * -2, 635, 635, this.blueTeam, Color.TeamBlue);

        rand = Math.random();
        if (rand <= 1 / 2) new MazeWall(this.game, -635 * 7, -635 * 2, 635, 635);
        else if (rand <= 3 / 4) new TeamMazeWall(this, -635 * 7, -635 * 2, 635, 635, this.blueTeam, Color.TeamBlue);

        // Generates the ~3 red maze walls between the cores
        if (rand >= 0.5) {
            new TeamMazeWall(this, -635 * -8, -635 * 2, 635, 635, this.redTeam, Color.TeamRed);
        }
        else {
            new TeamMazeWall(this, -635 * -8, -635 * -2, 635, 635, this.redTeam, Color.TeamRed);
        }

        rand = Math.random();
        if (rand <= 1 / 2) new MazeWall(this.game, -635 * -7, -635 * -2, 635, 635);
        else if (rand <= 3 / 4) new TeamMazeWall(this, -635 * -7, -635 * -2, 635, 635, this.redTeam, Color.TeamRed);

        rand = Math.random();
        if (rand <= 1 / 2) new MazeWall(this.game, -635 * -7, -635 * 2, 635, 635);
        else if (rand <= 3 / 4) new TeamMazeWall(this, -635 * -7, -635 * 2, 635, 635, this.redTeam, Color.TeamRed);

        // Generates 0 - 2 maze walls at the bottom left, bottom right, top left, and top right corners of the map
        let bl = null; //++
        let br = null; //+-
        let tl = null; //-+
        let tr = null; //--
        rand = Math.random()
        if (rand <= 0.25) {
            if (Math.random() < 0.6) new MazeWall(this.game, -635 * -6, -635 * -5, 635, 635);
            if (Math.random() < 0.6) new MazeWall(this.game, -635 * -5, -635 * -5, 635, 635);
        }
        else if (rand <= 0.5) new MazeWall(this.game, -635 * -6, -635 * -5, 635, 635);
        else if (rand <= 0.75) new MazeWall(this.game, -635 * -5, -635 * -5, 635, 635);
        rand = Math.random()
        if (rand <= 0.25) {
            if (Math.random() < 0.6) new MazeWall(this.game, -635 * 6, -635 * -5, 635, 635);
            if (Math.random() < 0.6) new MazeWall(this.game, -635 * 5, -635 * -5, 635, 635);
        }
        else if (rand <= 0.5) new MazeWall(this.game, -635 * 6, -635 * -5, 635, 635);
        else if (rand <= 0.75) new MazeWall(this.game, -635 * 5, -635 * -5, 635, 635);

        // Generates the four walls between the cores on each side
        new MazeWall(this.game, -635 * 9, -635 * 2, 635, 635);
        new MazeWall(this.game, -635 * 9, -635 * -2, 635, 635);
        new MazeWall(this.game, -635 * -9, -635 * 2, 635, 635);
        new MazeWall(this.game, -635 * -9, -635 * -2, 635, 635);

        // Generates the three maze wall structures on the bottom middle and on the top middle
        new MazeWall(this.game, -635 * 3.5, -635 * -2, 635, 635 * 2);
        new MazeWall(this.game, -635 * 3.5, -635 * 2, 635, 635 * 2);
        new MazeWall(this.game, -635 * -3.5, -635 * -2, 635, 635 * 2);
        new MazeWall(this.game, -635 * -3.5, -635 * 2, 635, 635 * 2);
        new MazeWall(this.game, -635 * 0, -635 * -2, 635, 635 * 3);
        new MazeWall(this.game, -635 * 0, -635 * 2, 635, 635 * 3);

        // Generates the four passageways in between the middle blocks
        if (Math.random() <= 0.5) {
            if (Math.random() <= 0.5) {
                new MazeWall(this.game, -635 * 2, -635 * 2, 635, 635);
                new MazeWall(this.game, -635 * -2, -635 * -2, 635, 635);
            }
            else {
                new TeamMazeWall(this, -635 * 2, -635 * 2, 635, 635, this.blueTeam, Color.TeamBlue);
                new TeamMazeWall(this, -635 * -2, -635 * -2, 635, 635, this.redTeam, Color.TeamRed);
            }
        }
        else {
            if (Math.random() <= 0.5) {
                new MazeWall(this.game, -635 * 2, -635 * -2, 635, 635);
                new MazeWall(this.game, -635 * -2, -635 * 2, 635, 635);
            }
            else {
                new TeamMazeWall(this, -635 * 2, -635 * -2, 635, 635, this.blueTeam, Color.TeamBlue);
                new TeamMazeWall(this, -635 * -2, -635 * 2, 635, 635, this.redTeam, Color.TeamRed);
            }
        }

        // Generates the random blocks in the three main hallways
        let y = 0;
        for (let i = 0; i < 3; i++) {
            y = i * 4 - 4;
            rand = Math.ceil(Math.random() * 5);
            new MazeWall(this.game, -635 * rand, -635 * y, 635, 635);
        }
        for (let i = 0; i < 3; i++) {
            y = i * 4 - 4;
            rand = Math.ceil(Math.random() * 5);
            new MazeWall(this.game, -635 * rand * -1, -635 * y, 635, 635);
        }
        for (let i = 0; i < 3; i++) {
            y = i * 4 - 5;
            if (Math.random() <= 0.5) y += 2

            rand = Math.ceil(Math.random() * 5);
            if (Math.random() > 0.5) new MazeWall(this.game, -635 * rand, -635 * y, 635, 635);
        }
        for (let i = 0; i < 3; i++) {
            y = i * 4 - 5;
            if (Math.random() <= 0.5) y += 2

            rand = Math.ceil(Math.random() * 5);
            if (Math.random() > 0.5) new MazeWall(this.game, -635 * rand * -1, -635 * y, 635, 635);
        }
    }

    public spawnPlayer(tank: TankBody, client: Client) {
        tank.positionData.values.y = ARENA_SIZE * Math.random() - ARENA_SIZE;

        const xOffset = (Math.random() - 0.5) * BASE_SIZE,
            yOffset = (Math.random() - 0.5) * BASE_SIZE;

        let base = undefined;

        if (this.bluePlayerCount < this.redPlayerCount) {
            base = this.playerTeamMap.get(client) || [this.topBlueCore, this.midBlueCore, this.botBlueCore][0 | Math.random() * 3];
            while (base.styleData.values.color == Color.Barrel) base = this.playerTeamMap.get(client) || [this.topBlueCore, this.midBlueCore, this.botBlueCore][0 | Math.random() * 3];
        }
        else if (this.redPlayerCount < this.bluePlayerCount) {
            base = this.playerTeamMap.get(client) || [this.topRedCore, this.midRedCore, this.botRedCore][0 | Math.random() * 3];
            while (base.styleData.values.color == Color.Barrel) base = this.playerTeamMap.get(client) || [this.topRedCore, this.midRedCore, this.botRedCore][0 | Math.random() * 3];
        }
        else {
            base = this.playerTeamMap.get(client) || [this.topBlueCore, this.topRedCore, this.midBlueCore, this.midRedCore, this.botBlueCore, this.botRedCore][0 | Math.random() * 6];
            while (base.styleData.values.color == Color.Barrel) base = this.playerTeamMap.get(client) || [this.topBlueCore, this.topRedCore, this.midBlueCore, this.midRedCore, this.botBlueCore, this.botRedCore][0 | Math.random() * 6];
        }        

        //base = this.playerTeamMap.get(client) || [this.topBlueCore, this.topRedCore, this.midBlueCore, this.midRedCore, this.botBlueCore, this.botRedCore][0 | Math.random() * 6];
        //while (base.styleData.values.color == Color.Barrel) base = this.playerTeamMap.get(client) || [this.topBlueCore, this.topRedCore, this.midBlueCore, this.midRedCore, this.botBlueCore, this.botRedCore][0 | Math.random() * 6];
        tank.relationsData.values.team = base.relationsData.values.team;
        tank.styleData.values.color = base.styleData.values.color;
        tank.positionData.values.x = base.positionData.values.x + xOffset;
        tank.positionData.values.y = base.positionData.values.y + yOffset;
        this.playerTeamMap.set(client, base);

        if (client.camera) client.camera.relationsData.team = tank.relationsData.values.team;

        if (tank.relationsData.values.team == this.botRedCore.relationsData.values.team) this.redPlayerCount += 1;
        else this.bluePlayerCount += 1;

        util.log(this.bluePlayerCount, this.redPlayerCount);
    }
    public tick(tick: number) {

        if (this.topBlueCore.styleData.values.color == Color.Barrel && this.botBlueCore.styleData.values.color == Color.Barrel) {
            this.midBlueCore.destroyShield();
        }
        if (this.topRedCore.styleData.values.color == Color.Barrel && this.botRedCore.styleData.values.color == Color.Barrel) {
            this.midRedCore.destroyShield();
        }

        if (this.isOpen && ((this.topBlueCore.styleData.values.color == Color.Barrel && this.midBlueCore.styleData.values.color == Color.Barrel && this.botBlueCore.styleData.values.color == Color.Barrel) || this.topRedCore.styleData.values.color == Color.Barrel && this.midRedCore.styleData.values.color == Color.Barrel && this.botRedCore.styleData.values.color == Color.Barrel)) {
            if (this.topRedCore.styleData.values.color == Color.Barrel && this.midRedCore.styleData.values.color == Color.Barrel && this.botRedCore.styleData.values.color == Color.Barrel) {
                this.game.broadcast()
                    .u8(ClientBound.Notification)
                    .stringNT("The Blue Team has won the game!")
                    .u32(0x00B2E1)
                    .float(10000)
                    .stringNT("").send();
            }
            if (this.topBlueCore.styleData.values.color == Color.Barrel && this.midBlueCore.styleData.values.color == Color.Barrel && this.botBlueCore.styleData.values.color == Color.Barrel) {
                this.game.broadcast()
                    .u8(ClientBound.Notification)
                    .stringNT("The Red Team has won the game!")
                    .u32(0xF14E54)
                    .float(10000)
                    .stringNT("").send();
            }
            this.isOpen = false;
            setTimeout(() => {
                this.close();
                /*setTimeout(() => {
                    this.game.end();
                }, 15000);*/
            }, 2500);
        }
        if (this.topRedCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.topRedCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.topRedCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A red core has been destroyed!")
                .u32(0x00B2E1)
                .float(10000)
                .stringNT("").send();
        }
        if (this.midRedCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.midRedCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.midRedCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A red core has been destroyed!")
                .u32(0x00B2E1)
                .float(10000)
                .stringNT("").send();
        }
        if (this.botRedCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.botRedCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.botRedCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A red core has been destroyed!")
                .u32(0x00B2E1)
                .float(10000)
                .stringNT("").send();
        }
        if (this.topBlueCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.topBlueCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.topBlueCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A blue core has been destroyed!")
                .u32(0xF14E54)
                .float(10000)
                .stringNT("").send();
        }
        if (this.midBlueCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.midBlueCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.midBlueCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A blue core has been destroyed!")
                .u32(0xF14E54)
                .float(10000)
                .stringNT("").send();
        }
        if (this.botBlueCore.styleData.values.color == Color.Barrel && this.coresDestroyed.includes(this.botBlueCore)) {
            this.coresDestroyed.splice(this.coresDestroyed.indexOf(this.botBlueCore), 1);
            this.game.broadcast()
                .u8(ClientBound.Notification)
                .stringNT("A blue core has been destroyed!")
                .u32(0xF14E54)
                .float(10000)
                .stringNT("").send();
        }


        super.tick(tick);

        const players: TankBody[] = [];

        for (let id = 0; id <= this.game.entities.lastId; ++id) {
            const entity = this.game.entities.inner[id];

            if (Entity.exists(entity) && entity instanceof TankBody && entity.cameraEntity instanceof ClientCamera && entity.cameraEntity.cameraData.values.player === entity) players.push(entity);
        }

        // Sorts them too DONT FORGET
        this.updateScoreboard(players);


        if (players.length === 0 && this.state === ArenaState.CLOSING) {
            this.state = ArenaState.CLOSED;

            setTimeout(() => {
                this.game.end();
            }, 10000);
            return;
        }
    }
}
