/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import Barrel from "../Tank/Barrel";
import AutoTurret, { AutoTurretDefinition } from "../Tank/AutoTurret";
import AbstractBoss from "./AbstractBoss";

import { Color, Tank, PositionFlags } from "../../Const/Enums";
import { AIState } from "../AI";

import { BarrelDefinition } from "../../Const/TankDefinitions";
import { PI2 } from "../../util";
/**
 * Definitions (stats and data) of the trap launcher on Hexadecagor
 */
const HexadecagorDefinition: BarrelDefinition = {
    angle: 0,
    offset: 0,
    size: 240,
    width: 50,
    delay: 2,
    reload: 12,
    recoil: 0,
    isTrapezoid: false,
    trapezoidDirection: 0,
    addon: "trapLauncher",
    forceFire: true,
    bullet: {
        type: "trap",
        sizeRatio: 1,
        health: 6,
        damage: 2.15,
        speed: 3,
        scatterRate: 1,
        lifeLength: 4.45,
        absorbtionFactor: 1,
        color: Color.Neutral
    }
}

// The size of a Hexadecagor by default
const HEXADECAGOR_SIZE = 215;

/**
 * Class which represents the boss "Hexadecagor"
 */
export default class Hexadecagor extends AbstractBoss {

    /** Hexadecagor's trap launchers */
    private trappers: Barrel[] = [];
    /** See AbstractBoss.movementSpeed */
    public movementSpeed = 0.27;

    public constructor(game: GameServer) {
        super(game);
        this.nameData.values.name = 'Hexadecagor';
        this.styleData.values.color = Color.EnemyTriangle;
        this.relationsData.values.team = this.game.arena;
        this.physicsData.values.size = HEXADECAGOR_SIZE * Math.SQRT1_2;
        this.ai.viewRange = 2100;

        this.physicsData.values.sides = 16;

        for (let i = 0; i < 16; ++i) {
            // Add spawner
            this.trappers.push(new Barrel(this, {
                ...HexadecagorDefinition,
                angle: PI2 * ((i / 16) - 1 / 1)
            }));
        }
        for (let j = 0; j < 4; ++j) {
            // TODO:
            // Maybe make this into a class of itself - DefenderAutoTurret
            const autoturret = new AutoTurret(this, {
                angle: 0,
                offset: 0,
                size: 95,
                width: 85,
                delay: 0.01,
                reload: 6,
                recoil: 0,
                isTrapezoid: false,
                addon: null,
                trapezoidDirection: 0,
                bullet: {
                    type: "bullet",
                    health: 100,
                    damage: 10,
                    speed: 1,
                    scatterRate: 1,
                    lifeLength: 3,
                    sizeRatio: 1,
                    absorbtionFactor: 0.1
                }
            });
            autoturret.baseSize = 55;

            autoturret.influencedByOwnerInputs = true;

            const angle = autoturret.ai.inputs.mouse.angle = PI2 * (j / 4); // Ex? (j /5 = 72 degrees)

            autoturret.positionData.values.y = this.physicsData.values.size * Math.sin(angle) * 0.93;
            autoturret.positionData.values.x = this.physicsData.values.size * Math.cos(angle) * 0.93;

            autoturret.physicsData.values.flags |= PositionFlags.absoluteRotation;

            const tickBase = autoturret.tick;
            autoturret.tick = (tick: number) => {
                autoturret.positionData.y = this.physicsData.values.size * Math.sin(angle) * 0.93;
                autoturret.positionData.x = this.physicsData.values.size * Math.cos(angle) * 0.93;

                tickBase.call(autoturret, tick);
            }
        }
    }

    public get sizeFactor() {
        return (this.physicsData.values.size / Math.SQRT1_2) / HEXADECAGOR_SIZE;
    }

    public tick(tick: number) {
        super.tick(tick);

        if (this.ai.state !== AIState.possessed) {
            this.positionData.angle += this.ai.passiveRotation * Math.PI * Math.SQRT1_2;
        }
    }
}