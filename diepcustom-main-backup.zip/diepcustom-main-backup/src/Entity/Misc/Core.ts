/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import { Color, HealthFlags, NameFlags, StyleFlags, Tank } from "../../Const/Enums";
import ArenaEntity from "../../Native/Arena";
import { CameraEntity } from "../../Native/Camera";
import { PI2 } from "../../util";
import { AI, AIState, Inputs } from "../AI";
import LivingEntity from "../Live";
import Bullet from "../Tank/Projectile/Bullet";
import TankBody from "../Tank/TankBody";
import CoreParticle from "./CoreParticle";
import CoreShield from "./CoreShield";
import TeamBase from "./TeamBase";
import { TeamEntity } from "./TeamEntity";

/**
 * Dominator Tank
 */
export default class Core extends TankBody {
    /** Size of a dominator */
    public static SIZE = 160;
    public hasShield: boolean = false;
    public shieldDestroyed: boolean = false;

    /** The base its located on (used to change base color). */
    public base: TeamBase;

    public constructor(arena: ArenaEntity, x: number, y: number, team: TeamEntity, coreBase: TeamBase, spawnBase: TeamBase, isMain: boolean) {
        let tankId: Tank;
        /*if (pTankId === null) {
            const r = Math.random() * 3;

            if (r < 1) tankId = Tank.DominatorD;
            else if (r < 2) tankId = Tank.DominatorG;
            else tankId = Tank.DominatorT;
        } else tankId = pTankId;*/
        if (isMain) {
            tankId = Tank.CoreShielded;
        }
        else {
            tankId = Tank.Core;
        }

        const inputs = new Inputs();
        const camera = new CameraEntity(arena.game);

        camera.setLevel(75);
        camera.sizeFactor = (Core.SIZE / 50);

        super(arena.game, camera, inputs);

        this.physicsData.values.size = Core.SIZE;

        this.relationsData.values.team = team;
        this.styleData.values.color = team.teamData.teamColor;

        this.setTank(tankId);
        const def = (this.definition = Object.assign({}, this.definition));
        def.speed = camera.cameraData.values.movementSpeed = 0;
        this.nameData.values.name = "Core";
        this.nameData.values.flags |= NameFlags.hiddenName;
        this.physicsData.values.absorbtionFactor = 0;
        
        this.positionData.values.x = x;
        this.positionData.values.y = y;

        this.physicsData.pushFactor = 5;
        
        this.scoreReward = 0;
        camera.cameraData.values.player = this;

        this.base = coreBase;

        this.regenPerTick = 0;
        //this.lastDamageTick = this.game.tick; // Should disable health regeneration

        let shieldColor = null;
        if (isMain) {
            if (this.styleData.values.color == Color.TeamBlue) shieldColor = 20;
            else if (this.styleData.values.color == Color.TeamRed) shieldColor = 21;
            else shieldColor = 12;
            new CoreShield(this.game, this.positionData.values.x, this.positionData.values.y, shieldColor, this.styleData.zIndex + 100000, this, PI2 / 30 / 4, 0.36, 0, 1.1, 1, 1);
            new CoreShield(this.game, this.positionData.values.x, this.positionData.values.y, shieldColor, this.styleData.zIndex + 100000, this, PI2 / 30 / -2.73, 0.23, 1.7, 1.35, 1.6, 1.3);
            new CoreShield(this.game, this.positionData.values.x, this.positionData.values.y, shieldColor, this.styleData.zIndex + 100000, this, PI2 / 30 / -1.19, 0.28, 83.2, 1.4, 0.65, 0.8);
            new CoreShield(this.game, this.positionData.values.x, this.positionData.values.y, shieldColor, this.styleData.zIndex + 100000, this, PI2 / 30 / 1.21, 0.17, 937.91, 1.43, 1.42, 1.467);
        }
        this.hasShield = isMain;
    }

    public onDeath(killer: LivingEntity) {
        this.relationsData.team = this.game.arena;
        this.styleData.color = Color.Barrel;
        this.base.relationsData.team = this.relationsData.values.team;
        this.isInvulnerable = true;
        this.damagePerTick = 0.01;
        this.healthData.health = this.healthData.values.maxHealth;
        this.healthData.flags |= HealthFlags.hiddenHealthbar;
        this.styleData.flags |= StyleFlags.hasNoDmgIndicator;
        this.base.styleData.color = this.styleData.values.color;
        this.base.relationsData.team = this.relationsData.values.team;

        for (let i = 1; i <= this.game.entities.lastId; ++i) {
            const entity = this.game.entities.inner[i];
            if (entity instanceof CoreParticle && entity.relationsData.values.owner === this) {
                entity.styleData.color = this.styleData.values.color;
            }
        }
    }

    public tick(tick: number) {

        if (this.styleData.color == Color.Barrel) {
            /*const collidedEntities = this.findCollisions();
            for (let i = 0; i < collidedEntities.length; ++i) {
                if ((collidedEntities[i] instanceof Bullet) && collidedEntities[i].relationsData.values.team != this.relationsData.values.team) collidedEntities[i].delete();
            }*/
            if (Math.random() >= 0.5) new CoreParticle(this.game, this.positionData.values.x, this.positionData.values.y, this.styleData.values.color, this.styleData.values.zIndex, this, Math.random() * 2 * Math.PI, 8 * (Math.random() * 0.9 + 0.2));
        }
        //if (Math.abs(this.lastDamageTick - this.game.tick) < 2 && !this.hasShield) new CoreParticle(this.game, this.positionData.values.x, this.positionData.values.y, this.styleData.values.color, this.styleData.values.zIndex, this, Math.random() * 2 * Math.PI, 16 * (Math.random() * 0.9 + 0.2));

        const collidedEntities = this.findCollisions();
        for (let i = 0; i < collidedEntities.length; ++i) {
            if ((collidedEntities[i] instanceof Bullet) && !this.hasShield) new CoreParticle(this.game, this.positionData.values.x, this.positionData.values.y, this.styleData.values.color, this.styleData.values.zIndex, this, Math.random() * 2 * Math.PI, 16 * (Math.random() * 0.9 + 0.2));
        }

        super.tick(tick);
        this.lastDamageTick = this.game.tick; // Should disable health regeneration
    }

    public destroyShield() {
        if (!this.shieldDestroyed) {
            for (let i = 1; i <= this.game.entities.lastId; ++i) {
                const entity = this.game.entities.inner[i];
                if (entity instanceof CoreShield && entity.relationsData.values.owner === this) {
                    entity.delete();
                }
            }
            this.setTank(Tank.Core);
            this.physicsData.values.size = Core.SIZE;

            this.nameData.values.name = "Core";
            this.nameData.values.flags |= NameFlags.hiddenName;
            this.physicsData.values.absorbtionFactor = 0;
            this.physicsData.pushFactor = 5;
            this.regenPerTick = 0;
            this.lastDamageTick = this.game.tick;

            this.shieldDestroyed = true;
            this.hasShield = false;
        }
    }
}
