/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import { PhysicsFlags, Color, HealthFlags, StyleFlags, ClientBound } from "../../Const/Enums";
import LivingEntity from "../Live";
import TankBody from "../Tank/TankBody";
import ArenaEntity from "../../Native/Arena";
import { TeamEntity } from "./TeamEntity";

export default class TeamMazeWall extends LivingEntity {

    private restoreTimeout: NodeJS.Timeout | null = null;

    public constructor(arena: ArenaEntity, x: number, y: number, width: number, height: number, team: TeamEntity | null, color: number) {
        super(arena.game);

        if (team == null) this.relationsData.values.team = this.game.arena;
        else this.relationsData.values.team = team;

        this.positionData.values.x = x;
        this.positionData.values.y = y;

        this.physicsData.values.flags ^= PhysicsFlags.noOwnTeamCollision;

        this.physicsData.values.width = width;
        this.physicsData.values.size = height;
        this.physicsData.values.sides = 2;
        this.physicsData.values.flags |= PhysicsFlags.showsOnMap;
        this.physicsData.values.pushFactor = 5;
        this.physicsData.values.absorbtionFactor = 0;


        this.damagePerTick = 15;
        this.healthData.health = this.healthData.maxHealth = 300;
        this.healthData.flags |= HealthFlags.hiddenHealthbar;
        this.styleData.flags |= StyleFlags.hasNoDmgIndicator;

        this.styleData.values.borderWidth = 10;
        this.styleData.values.color = color;
    }

    /** Extends ObjectEntity.destroy() - diminishes health as well. */
/*    public destroy(animate = false) {
        if (this.hash === 0) return; // already deleted;
        if (animate) this.healthData.health = 0;
        if (this.restoreTimeout === null) this.restoreTimeout = setTimeout(() => new TeamMazeWall(this.game, this.positionData.values.x, this.positionData.values.y, this.initialWidth, this.initialHeight), 30000 + 90000 * Math.random());
        super.destroy(animate);
    }*/

    public onDeath(killer: LivingEntity) {
        if (killer instanceof TankBody) {
            this.relationsData.team = killer.relationsData.values.team || this.game.arena;
            this.styleData.color = this.relationsData.team.teamData?.teamColor || killer.styleData.values.color;
            this.physicsData.values.flags |= PhysicsFlags.noOwnTeamCollision;
        } /*else {
            this.relationsData.team = killer.relationsData.values.team || this.game.arena;
            this.styleData.color = this.relationsData.team.teamData?.teamColor || killer.styleData.values.color;
            this.physicsData.values.flags |= PhysicsFlags.noOwnTeamCollision;
        }*/

        this.styleData.color = this.styleData.values.color;
        this.relationsData.team = this.relationsData.values.team;;

        this.healthData.health = this.healthData.values.maxHealth;
    }

    public tick(tick: number): void {
        this.styleData.opacity = this.healthData.health / this.healthData.maxHealth * 0.8 + 0.2;
       // if (this.styleData.opacity < 0.3) this.styleData.opacity = 0.3;
        super.tick(tick);
        /*this.game.broadcast()
            .u8(ClientBound.Notification)
            .stringNT('diep')
            .u32(0x000000)
            .float(10000)
            .stringNT("").send();*/
    }
}