/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import ArenaEntity from "../../Native/Arena";
import LivingEntity from "../Live";
import AbstractShape from "./AbstractShape";

import { Color, PhysicsFlags, PositionFlags, StyleFlags } from "../../Const/Enums";
import { AI, AIState } from "../AI";
import { BarrelBase } from "../Tank/TankBody";
import Crasher from "./Crasher";
import { Entity } from "../../Native/Entity";
import AutoTurret from "../Tank/AutoTurret";
import TripleAutoTurret from "../Tank/TripleAutoTurret";
import { BarrelDefinition } from "../../Const/TankDefinitions";
import Barrel from "../Tank/Barrel";
import { normalizeAngle, PI2 } from "../../util";

/**
 * Crasher entity class.
 */

export class Sentry extends Crasher implements BarrelBase {
    protected static BASE_ROTATION = 0;
    protected static BASE_ORBIT = 0;
    protected static BASE_VELOCITY = 0;
    public sizeFactor: number;
    public cameraEntity: Entity = this;
    public inputs;
    public reloadTime = 4;
    public constructor(arena: ArenaEntity, game: GameServer) {
        super(arena, game);

        this.sizeFactor = this.physicsData.values.size / 50;
        this.inputs = this.ai.inputs;
        this.isLarge = false;
        const rand = Math.random();
        this.targettingSpeed *= 0.6;
        //his.ai.viewRange * 0.8;

        if (rand < 0.2) {
            this.nameData.values.name = "Protector Sentry";
            let barsss: Barrel;
            let GuardianSpawnerDefinition: BarrelDefinition = {
                angle: Math.PI,
                offset: 0,
                size: 115,
                width: 150,
                delay: 0,
                reload: 6.5,
                recoil: 1,
                isTrapezoid: false,
                trapezoidDirection: 0,
                addon: "trapLauncher",
                bullet: {
                    type: "trap",
                    sizeRatio: 0.8,
                    health: 7,
                    damage: 4,
                    speed: 2,
                    scatterRate: 1.5,
                    lifeLength: 2,
                    absorbtionFactor: 1
                }
            };
            barsss = new Barrel(this, GuardianSpawnerDefinition);
            const atuo = new AutoTurret(this, {
                angle: 0,
                offset: 0,
                size: 105,
                width: 75,
                delay: 0.01,
                reload: 2.53,
                recoil: 0.3,
                isTrapezoid: false,
                trapezoidDirection: 0,
                addon: "trapLauncher",
                bullet: {
                    type: "trap",
                    health: 2 * 2,
                    damage: 1 * 3,
                    speed: 5,
                    scatterRate: 1,
                    lifeLength: 1.5,
                    sizeRatio: 1.2,
                    absorbtionFactor: 1
                }
            });
            atuo.baseSize *= 2.8;
            atuo.positionData.values.angle = this.positionData.values.angle;
            atuo.styleData.values.flags |= StyleFlags.showsAboveParent;
            atuo.ai.viewRange = this.ai.viewRange * 0.9;
        }
        else if (rand < 0.4) {
            this.nameData.values.name = "Chaotic Sentry";
            const atuo = new TripleAutoTurret(this, {
                angle: 0,
                offset: 0,
                size: 140,
                width: 65,
                delay: 0.01,
                reload: 2.7,
                recoil: 0.1,
                isTrapezoid: false,
                trapezoidDirection: 0,
                addon: null,
                bullet: {
                    type: "bullet",
                    health: 1 * 2.2,
                    damage: 1 * 1.5,
                    speed: 1.25,
                    scatterRate: 0.3,
                    lifeLength: 0.7,
                    sizeRatio: 1,
                    absorbtionFactor: 1
                }
            },
                {
                    angle: 0,
                    offset: -38,
                    size: 125,
                    width: 65,
                    delay: 0.5,
                    reload: 2.7,
                    recoil: 0.1,
                    isTrapezoid: false,
                    trapezoidDirection: 0,
                    addon: null,
                    bullet: {
                        type: "bullet",
                        health: 1 * 2.2,
                        damage: 1 * 1.5,
                        speed: 1.25,
                        scatterRate: 0.3,
                        lifeLength: 0.7,
                        sizeRatio: 1,
                        absorbtionFactor: 1
                    }
                },
                {
                    angle: 0,
                    offset: 38,
                    size: 125,
                    width: 65,
                    delay: 0.5,
                    reload: 2.7,
                    recoil: 0.1,
                    isTrapezoid: false,
                    trapezoidDirection: 0,
                    addon: null,
                    bullet: {
                        type: "bullet",
                        health: 1 * 2.2,
                        damage: 1 * 1.5,
                        speed: 1.25,
                        scatterRate: 0.3,
                        lifeLength: 0.7,
                        sizeRatio: 1,
                        absorbtionFactor: 1
                    }
                }
            );
            atuo.baseSize *= 2.8;
            atuo.positionData.values.angle = this.positionData.values.angle;
            atuo.styleData.values.flags |= StyleFlags.showsAboveParent;
            atuo.ai.viewRange = this.ai.viewRange * 1;
        }
        else if (rand < 0.6) {
            this.nameData.values.name = "Commander Sentry";
            let barsss: Barrel;
            let GuardianSpawnerDefinition: BarrelDefinition = {
                angle: Math.PI,
                offset: 0,
                size: 165,
                width: 110,
                delay: 0,
                reload: 4.2,
                recoil: 0.1,
                isTrapezoid: true,
                trapezoidDirection: Math.PI,
                addon: null,
                droneCount: 8,
                canControlDrones: true,
                bullet: {
                    type: "swarm",
                    sizeRatio: 0.7,
                    health: 1 * 1.3,
                    damage: 1 * 1.2,
                    speed: 1.45,
                    scatterRate: 1.5,
                    lifeLength: 1.7,
                    absorbtionFactor: 1
                }
            };
            barsss = new Barrel(this, GuardianSpawnerDefinition);
            let GuardianSpawnerDefinition2: BarrelDefinition = {
                angle: Math.PI,
                offset: 0,
                size: 130,
                width: 110,
                delay: 4294967295,
                reload: 4294967295,
                recoil: 0,
                isTrapezoid: true,
                trapezoidDirection: 0,
                addon: null,
                droneCount: 999999,
                canControlDrones: true,
                bullet: {
                    type: "bullet",
                    sizeRatio: 0,
                    health: 0,
                    damage: 0,
                    speed: 0,
                    scatterRate: 0,
                    lifeLength: 0,
                    absorbtionFactor: 0
                }
            };
            barsss = new Barrel(this, GuardianSpawnerDefinition);
            barsss = new Barrel(this, GuardianSpawnerDefinition2);
        }
        else if (rand < 0.8) {
            this.nameData.values.name = "Tactical Sentry";
            const atuo = new AutoTurret(this, {
                angle: 0,
                offset: 0,
                size: 164,
                width: 70,
                delay: 0.01,
                reload: 5.7,
                recoil: 0.3,
                isTrapezoid: true,
                trapezoidDirection: Math.PI,
                addon: null,
                bullet: {
                    type: "bullet",
                    health: 1 * 2.5,
                    damage: 1 * 2.5,
                    speed: 2,
                    scatterRate: 1,
                    lifeLength: 1,
                    sizeRatio: 1,
                    absorbtionFactor: 1
                }
            });
            atuo.baseSize *= 2.8;
            atuo.positionData.values.angle = this.positionData.values.angle;
            atuo.styleData.values.flags |= StyleFlags.showsAboveParent;
            atuo.ai.viewRange = this.ai.viewRange * 1;

            let barsss: Barrel;
            let GuardianSpawnerDefinition: BarrelDefinition = {
                angle: Math.PI,
                offset: 0,
                size: 150,
                width: 150,
                delay: 0,
                reload: 12,
                recoil: 0.3,
                isTrapezoid: true,
                trapezoidDirection: 0,
                addon: null,
                droneCount: 3,
                canControlDrones: true,
                bullet: {
                    type: "drone",
                    sizeRatio: 0.8,
                    health: 1 * 2,
                    damage: 1 * 3,
                    speed: 1.45,
                    scatterRate: 1,
                    lifeLength: -1,
                    absorbtionFactor: 1
                }
            };
            barsss = new Barrel(this, GuardianSpawnerDefinition);
        }
        else {
            this.nameData.values.name = "Destructive Sentry";
            const atuo = new AutoTurret(this, {
                angle: 0,
                offset: 0,
                size: 145,
                width: 100,
                delay: 0.01,
                reload: 16,
                recoil: 0.3,
                isTrapezoid: false,
                trapezoidDirection: 0,
                addon: null,
                bullet: {
                    type: "bullet",
                    health: 2 * 2.5,
                    damage: 2 * 2.5,
                    speed: 1.2,
                    scatterRate: 1,
                    lifeLength: 1,
                    sizeRatio: 1,
                    absorbtionFactor: 1
                }
            });
            atuo.baseSize *= 2.8;
            atuo.positionData.values.angle = this.positionData.values.angle;
            atuo.styleData.values.flags |= StyleFlags.showsAboveParent;
            atuo.ai.viewRange = this.ai.viewRange * 1;
        }
        this.positionData.values.flags |= PositionFlags.canMoveThroughWalls;
        this.healthData.values.health = this.healthData.values.maxHealth = 333;
        this.physicsData.values.size = 88 * Math.SQRT1_2;
        this.physicsData.values.sides = 3;
        this.physicsData.values.absorbtionFactor = 0.1;
        this.physicsData.values.pushFactor = 12;

        this.positionData.values.flags ^= PositionFlags.canMoveThroughWalls;

        this.targettingSpeed = 1;
        this.styleData.values.color = Color.EnemyCrasher;

        this.scoreReward = 500;
        this.damagePerTick = 12;
    }
    tick(tick: number) {

        super.tick(tick);
    }
}