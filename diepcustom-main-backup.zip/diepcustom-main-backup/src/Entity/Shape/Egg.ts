/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import ArenaEntity from "../../Native/Arena";

import Square from "./Square";
import AbstractShape from "./AbstractShape";
import { removeFast } from "../../util";

import { Color } from "../../Const/Enums";


export default class Egg extends AbstractShape {
    /** Current game server */
    public game: GameServer;
    /** Arena whose shapes are being managed */
    protected arena: ArenaEntity;


    protected static BASE_ORBIT = AbstractShape.BASE_ORBIT * 2.5;
    protected static BASE_VELOCITY = AbstractShape.BASE_VELOCITY * 2;
    protected static BASE_ROTATION = AbstractShape.BASE_ROTATION * 0.5;

    
    private timer = 0;
    private evolutionTime = ((Math.random() * 50 + 30) * 30); // A random number from 30 to 80 seconds
    private doEvolve?: boolean = true;
    public constructor(arena: ArenaEntity, game: GameServer, shiny = Math.random() < 0.000001) {
        super(game);

        this.arena = arena;
        this.game = arena.game;

        if (Math.random() > 0.65) this.doEvolve = false;

        this.nameData.values.name = "Egg";
        this.healthData.values.health = this.healthData.values.maxHealth = 0.0001 * 100;
        this.physicsData.values.size = 23 + (Math.random() * 4 - 2);
        this.physicsData.values.pushFactor = 0;
        this.physicsData.values.sides = 1;
        this.styleData.values.color = shiny ? Color.Shiny : Color.Egg;
        this.damagePerTick = 2.52;
        if (Math.random() > 0.5) this.scoreReward = 2;
        else this.scoreReward = 3;
        this.isShiny = shiny;

        if (shiny) {
            this.scoreReward = 100000;
            this.healthData.values.health = this.healthData.values.maxHealth *= 1;
        }

    }
    tick(tick: number) {

        if (this.game.gamemode == "dom2") {
            if (Math.abs(this.positionData.values.y - this.arena.arenaData.bottomY) < 625 * 4 || Math.abs(this.positionData.values.y - this.arena.arenaData.topY) < 625 * 4) {
                this.delete();
            }
        }

        this.timer += 1;
        if (this.timer > this.evolutionTime && this.doEvolve) {
            let shape: AbstractShape;
            shape = new Square(this.arena, this.game, true);

            shape.positionData.values.x = this.positionData.x;
            shape.positionData.values.y = this.positionData.y;
            shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;
            shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;
            this.delete();
        }
        super.tick(tick);
    }

}
