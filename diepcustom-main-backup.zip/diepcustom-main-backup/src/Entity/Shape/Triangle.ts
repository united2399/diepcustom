/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import ArenaEntity from "../../Native/Arena";

import Pentagon from "./Pentagon";
import AbstractShape from "./AbstractShape";
import { removeFast } from "../../util";

import { Color } from "../../Const/Enums";

export default class Triangle extends AbstractShape {
    /** Current game server */
    public game: GameServer;
    /** Arena whose shapes are being managed */
    protected arena: ArenaEntity;
    /** Stores all shapes */
    protected shapes: AbstractShape[] = [];


    private timer = 0;
    private evolutionTime = (Math.random() * 50 + 30) * 30 + 20; // A random number from 50 to 100 seconds
    private doEvolve?: boolean = true;
    public constructor(arena: ArenaEntity,game: GameServer, shiny=Math.random() < 0.000001) {
        super(game);

        this.arena = arena;
        this.game = arena.game;

        if (Math.random() > 0.33) this.doEvolve = false;

        this.nameData.values.name = "Triangle";
        this.healthData.values.health = this.healthData.values.maxHealth = 30;
        this.physicsData.values.size = 55 * Math.SQRT1_2 + (Math.random() * 6.76362956 - 6.76362956 / 2);
        this.physicsData.values.sides = 3;
        this.styleData.values.color = shiny ? Color.Shiny : Color.EnemyTriangle;

        this.damagePerTick = 8;
        this.scoreReward = 25;
        this.isShiny = shiny;

        if (shiny) {
            this.scoreReward *= 100;
            this.healthData.values.health = this.healthData.values.maxHealth *= 10;
        }
    }
    tick(tick: number) {

        if (this.game.gamemode == "dom2") {
            if (Math.abs(this.positionData.values.y - this.arena.arenaData.bottomY) < 625 * 4 || Math.abs(this.positionData.values.y - this.arena.arenaData.topY) < 625 * 4) {
                this.delete();
            }
        }

        this.timer += 1;
        if (this.timer > this.evolutionTime && this.doEvolve) {
            let shape: AbstractShape;
            shape = new Pentagon(this.game);

            shape.positionData.values.x = this.positionData.x;
            shape.positionData.values.y = this.positionData.y;
            shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;
            shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;
            this.delete();
        }
        super.tick(tick);
    }
}
