/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import GameServer from "../../Game";
import AbstractShape from "./AbstractShape";

import { Color } from "../../Const/Enums";

/**
 * Pentagon entity class.
 */
export default class Pentagon extends AbstractShape {
    /** If the pentagon is an alpha pentagon or not */

    protected static BASE_ROTATION = AbstractShape.BASE_ROTATION / 2;
    protected static BASE_ORBIT = AbstractShape.BASE_ORBIT / 2;
    protected static BASE_VELOCITY = AbstractShape.BASE_VELOCITY / 2;

    public constructor(game: GameServer, isAlpha = false, isBeta = false, isInNest = false, shiny=(Math.random() < 0.000001) && !isAlpha) {
        super(game);

        if ((!isAlpha && isBeta)) this.nameData.values.name = "Beta Pentagon"
        else this.nameData.values.name = isAlpha ? "Alpha Pentagon" : "Pentagon";
         
        if ((!isAlpha && isBeta)) this.healthData.values.health = this.healthData.values.maxHealth = 3000
        else this.healthData.values.health = this.healthData.values.maxHealth = (isAlpha ? 12000 : 100); // Was 3000 for alpha pentagons

        if ((!isAlpha && isBeta)) this.physicsData.values.size = 141;
        else this.physicsData.values.size = (isAlpha ? 350 : 75) * Math.SQRT1_2; // Was 200 for alpha pentagons

        this.physicsData.values.sides = 5;
        this.styleData.values.color = shiny ? Color.Shiny : Color.EnemyPentagon;

        if ((!isAlpha && isBeta)) this.physicsData.values.absorbtionFactor = 0.09;
        else this.physicsData.values.absorbtionFactor = isAlpha ? 0.03 : 0.5;

        this.physicsData.values.pushFactor = 11;

        this.isShiny = shiny;

        if ((!isAlpha && isBeta)) this.damagePerTick = 17;
        else this.damagePerTick = isAlpha ? 24 : 12; // Was 20 for alpha pentagons

        if ((!isAlpha && isBeta)) this.scoreReward = 3000;
        else this.scoreReward = isAlpha ? (Math.random() * 3000 + 9000) : 130; // Was 3000 for alpha pentagons // Now is 9000 - 12000
        
        if (shiny) {
            this.scoreReward *= 100;
            this.healthData.values.health = this.healthData.values.maxHealth *= 10;
        }
    }
    tick(tick: number) {
        if (this.game.gamemode == "dom2") {
            if (Math.abs(this.positionData.values.y - this.game.arena.arenaData.bottomY) < 625 * 4 || Math.abs(this.positionData.values.y - this.game.arena.arenaData.topY) < 625 * 4) {
                this.delete();
            }
        }
        super.tick(tick);
    }

}