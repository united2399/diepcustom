/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import ArenaEntity from "../../Native/Arena";
import GameServer from "../../Game";

import Crasher from "./Crasher";
import Pentagon from "./Pentagon";
import Triangle from "./Triangle";
import Square from "./Square";
import Egg from "./Egg";
import { Sentry } from "./Sentry";
import AbstractShape from "./AbstractShape";
import { removeFast } from "../../util";

/**
 * Used to balance out shape count in the arena, as well
 * as determines where each type of shape spawns around the arena.
 */

export default class CrasherManager {
    /** Current game server */
    protected game: GameServer;
    /** Arena whose shapes are being managed */
    protected arena: ArenaEntity;
    /** Stores all shapes */
    protected crashers: AbstractShape[] = [];

    public constructor(arena: ArenaEntity) {
        this.arena = arena;
        this.game = arena.game;
    }

    /**
     * Spawns a shape in a random location on the map.
     * Determines shape type by the random position chosen.
     */
    protected spawnCrasher(): AbstractShape {
        let shape: AbstractShape;
        const {x, y} = this.arena.findCrasherSpawnLocation();
        const rightX = this.arena.arenaData.values.rightX;
        const leftX = this.arena.arenaData.values.leftX;
        const isBig = Math.random() < .2;

        /*shape = new Crasher(this.arena, this.game, isBig);
            
        shape.positionData.values.x = x;
        shape.positionData.values.y = y;
        shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;*/
        if (Math.random() <= 0.025 || (this.game.gamemode == "dom2")) {
            shape = new Sentry(this.arena, this.game);

            shape.positionData.values.x = x;
            shape.positionData.values.y = y;
            shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;


            shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;

            return shape;
        }
        else {
            shape = new Crasher(this.arena, this.game, isBig);

            shape.positionData.values.x = x;
            shape.positionData.values.y = y;
            shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;


            shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;

            return shape;
        }
    }

    /** Kills all shapes in the arena */
    public killAll() {
        for(let i = 0; i < this.crashers.length; ++i) {
            this.crashers[i]?.delete();
        }
    }

    protected get wantedShapes() {
        if (this.game.gamemode == "sandbox") return 3;
        else if (this.game.gamemode == "dom2") return 3;
        else return 30;
    }

    public tick() {
        for (let i = this.wantedShapes; i-- > 0;) {
            const crasher = this.crashers[i];
            // Alternatively, Entity.exists(shape), though this is probably faster
            if (this.game.gamemode == "dom2") if (!crasher || crasher.hash === 0 && Math.random() < 0.00008) this.crashers[i] = this.spawnCrasher();
            else if (!crasher || crasher.hash === 0 && Math.random() < 0.0006) this.crashers[i] = this.spawnCrasher();
        }
    }
}
