/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import LivingEntity from "../../Live";
import Barrel from "../Barrel";

import { HealthFlags, PositionFlags, PhysicsFlags, Stat, StyleFlags, Color } from "../../../Const/Enums";
import { TankDefinition } from "../../../Const/TankDefinitions";
import { BarrelBase } from "../TankBody";
import { EntityStateFlags } from "../../../Native/Entity";
import Boulder from "../../Misc/Boulder";
import Pentagon from "../../Shape/Pentagon";
import * as util from "../../../util";
import Vector from "../../../Physics/Vector";
import { PI2 } from "../../../util";
import Drone from "./Drone";
import BoulderHitbox from "../../Misc/BoulderHitbox";
import Trap from "./Trap";
import AutoTrap from "./AutoTrap";

/**
 * The bullet class represents the bullet entity in diep.
 */
export default class Bullet extends LivingEntity {
    /** The barrel that the bullet is being shot from. */
    protected barrelEntity: Barrel;
    /** The tick this entity was created in. */
    protected spawnTick = 0;
    /** Speed the bullet will accelerate at. */
    protected baseAccel = 0;
    /** Starting velocity of the bullet. */
    protected baseSpeed = 0;
    /** Percent of accel applied when dying. */
    protected deathAccelFactor = 0.5;
    /** Life length in ticks before the bullet dies. */
    protected lifeLength = 0;
    /** Angle the projectile is shot at. */
    protected movementAngle = 0;
    /** Definition of the tank (if existant) shooting the bullet. */
    protected tankDefinition: TankDefinition | null = null;
    /** Whether or not to use .shootAngle or .position.angle. */
    protected usePosAngle = false;
    /** The tank who shot the bullet. */
    protected tank: BarrelBase;

    public constructor(barrel: Barrel, tank: BarrelBase, tankDefinition: TankDefinition | null, shootAngle: number) {
        super(barrel.game);

        this.tank = tank;

        this.tankDefinition = tankDefinition;

        // if (barrel.definition.bullet.type === "drone") throw new TypeError("Invalid bullet type for this class");
        this.movementAngle = shootAngle;
        this.barrelEntity = barrel;
        this.spawnTick = barrel.game.tick;

        this.relationsData.values.owner = tank;

        tank.rootParent.styleData.zIndex = barrel.game.entities.zIndex++;

        const bulletDefinition = barrel.definition.bullet;
        const sizeFactor = tank.sizeFactor;
        const statLevels = tank.cameraEntity.cameraData?.values.statLevels.values;

        this.relationsData.values.team = barrel.relationsData.values.team;
        this.relationsData.values.owner = tank;

        this.physicsData.values.sides = bulletDefinition.sides ?? 1;
        this.physicsData.values.flags |= PhysicsFlags.noOwnTeamCollision | PhysicsFlags.canEscapeArena;
        if (tank.positionData.values.flags & PositionFlags.canMoveThroughWalls) this.positionData.values.flags |= PositionFlags.canMoveThroughWalls
        this.physicsData.values.size = (barrel.physicsData.values.width / 2) * bulletDefinition.sizeRatio;
        this.styleData.values.color = bulletDefinition.color || tank.rootParent.styleData.values.color;
        this.styleData.values.flags |= StyleFlags.hasNoDmgIndicator;
        //this.healthData.values.flags = HealthFlags.hiddenHealthbar;
        const bulletDamage = statLevels ? statLevels[Stat.BulletDamage] : 0;
        const bulletPenetration = statLevels ? statLevels[Stat.BulletPenetration] : 0;

        this.physicsData.values.absorbtionFactor = bulletDefinition.absorbtionFactor;
        this.physicsData.values.pushFactor = ((7 / 3) + bulletDamage) * bulletDefinition.damage * bulletDefinition.absorbtionFactor;

        this.baseAccel = barrel.bulletAccel;
        this.baseSpeed = barrel.bulletAccel + 30 - Math.random() * bulletDefinition.scatterRate;

        this.healthData.values.health = this.healthData.values.maxHealth = (1.5 * bulletPenetration + 2) * bulletDefinition.health;
        this.damagePerTick = (7 + bulletDamage * 3) * bulletDefinition.damage;
        this.damageReduction = 0.25;

        this.lifeLength = bulletDefinition.lifeLength * 72;

        const { x, y } = tank.getWorldPosition();

        this.positionData.values.x = x + (Math.cos(shootAngle) * barrel.physicsData.values.size) - Math.sin(shootAngle) * barrel.definition.offset * sizeFactor;
        this.positionData.values.y = y + (Math.sin(shootAngle) * barrel.physicsData.values.size) + Math.cos(shootAngle) * barrel.definition.offset * sizeFactor;
        this.positionData.values.angle = shootAngle;
    }

    /** Extends LivingEntity.onKill - passes kill to the owner. */
    public onKill(killedEntity: LivingEntity) {
        // TODO(ABC):
        // Make this, work differently
        /** @ts-ignore */
        if (typeof this.tank.onKill === 'function') this.tank.onKill(killedEntity);
    }

    public tick(tick: number) {
        super.tick(tick);

        if (tick === this.spawnTick + 1) this.addAcceleration(this.movementAngle, this.baseSpeed);
        else this.maintainVelocity(this.usePosAngle ? this.positionData.values.angle : this.movementAngle, this.baseAccel);

        if (tick - this.spawnTick >= this.lifeLength) this.destroy(true);
        // TODO(ABC):
        // This code will be reimplemented in the update that allows for easy camera entity switches
        if ((this.relationsData.values.team?.entityState || 0) & EntityStateFlags.needsDelete) this.relationsData.values.team = null

        if (!(this instanceof Drone)) {

            let collidedEntities = this.findCollisions();

            for (let i = 0; i < collidedEntities.length; ++i) {

                if ((collidedEntities[i] instanceof BoulderHitbox)) {
                    /*this.movementAngle -= Math.PI * (Math.random() * 0.2 + 0.9);
                    this.addAcceleration(this.movementAngle, this.baseAccel * 1.2)*/
                    //const boulderRadius = collidedEntities[i].physicsData.values.size;
                    //const bulletRadius = this.physicsData.values.size;
                    //const distance = boulderRadius + bulletRadius;

                    //this.movementAngle = Math.acos((boulderRadius * boulderRadius + bulletRadius * bulletRadius - distance * distance) / (2 * boulderRadius * bulletRadius));
                    let dir = this.movementAngle;
                    if (dir > 180) {
                        dir = (360 - dir) * -1;
                    }

                    let a = Math.atan2(collidedEntities[i].positionData.values.y - this.positionData.values.y, collidedEntities[i].positionData.values.x - this.positionData.values.x) - dir;
                    a = (a + Math.PI) % PI2 - Math.PI;

                    this.movementAngle += (a * 2) - Math.PI;

                    this.accel.set(Vector.fromPolar(this.movementAngle, this.accel.magnitude));
                    if (!(this.physicsData.values.sides == 3 || this.physicsData.values.sides == 4 && this.baseAccel == 0)) { // Only functional way to detect if the projectile is an instance of a trap that I could find, other ones made it so that there were weird errors in lib
                        this.accel.set(Vector.fromPolar(this.movementAngle, this.accel.magnitude));
                        this.positionData.angle = this.movementAngle;
                    }
                    

                    this.positionData.x += Math.cos(this.accel.angle) * 3;
                    this.positionData.y += Math.sin(this.accel.angle) * 3;

                    for (let j = 0; j < 24; ++j) {
                        collidedEntities = this.findCollisions();

                        for (let k = 0; k < collidedEntities.length; ++k) {

                            if ((collidedEntities[k] instanceof BoulderHitbox)) {
                                this.positionData.x += Math.cos(this.accel.angle) * 3;
                                this.positionData.y += Math.sin(this.accel.angle) * 3;
                            }
                        }
                    }

                    /*while (true) {
                        let touchedBoulder: boolean = false;
                        const collidedEntities = this.findCollisions();

                        for (let i = 0; i < collidedEntities.length; ++i) {

                            if ((collidedEntities[i] instanceof BoulderHitbox)) {
                                this.positionData.x += Math.cos(this.accel.angle) * this.accel.magnitude * 0.5;
                                this.positionData.y += Math.sin(this.accel.angle) * this.accel.magnitude * 0.5;
                                touchedBoulder = true;
                            }
                        }
                        if (!touchedBoulder) break;
                    }*/

                    //this.movementAngle = Math.atan2(velX, velY);
                    //this.addAcceleration(this.movementAngle, this.baseAccel * 1);


                    //this.positionData.x += Math.cos(this.movementAngle * 180 / Math.PI) * this.baseAccel;
                    //this.positionData.y += Math.sin(this.movementAngle * 180 / Math.PI) * this.baseAccel;
                }
            }
        }
    }
}
