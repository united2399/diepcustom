/*
    DiepCustom - custom tank game server that shares diep.io's WebSocket protocol
    Copyright (C) 2022 ABCxFF (github.com/ABCxFF)

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published
    by the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program. If not, see <https://www.gnu.org/licenses/>
*/

import ObjectEntity from "../Object";
import Barrel from "./Barrel";

import { BarrelBase } from "./TankBody";
import { Color, InputFlags, PositionFlags, NameFlags, PhysicsFlags, Stat, StyleFlags } from "../../Const/Enums";
import { BarrelDefinition, TankDefinition } from "../../Const/TankDefinitions";
import { Inputs } from "../AI";
import { NameGroup } from "../../Native/FieldGroups";
import LivingEntity from "../Live";

/**
 * Auto Turret Barrel + Barrel Base
 */
export default class AutoTurret extends ObjectEntity {
    // TODO(ABC):
    // Maybe just remove this
    /** For mounted turret name to show up on Auto Turrets. */
    public nameData: NameGroup = new NameGroup(this);

    /** Barrel's owner (Tank-like object). */
    private owner: BarrelBase;
    
    public inputs = new Inputs();
    /** The size of the auto turret base */
    public baseSize: number;
    private diff = 0;

    public constructor(owner: BarrelBase, baseSize: number = 21.5) {
      super(owner.game);        

        this.owner = owner;
        
        this.setParent(owner);
        this.relationsData.values.owner = owner;

        this.relationsData.values.team = owner.relationsData.values.team;

        this.physicsData.values.sides = 4;
        this.baseSize = baseSize;
        this.physicsData.values.size = this.baseSize * this.sizeFactor;

        this.styleData.values.color = Color.Barrel;
        this.styleData.values.flags |= StyleFlags.showsAboveParent;

        this.positionData.values.flags |= PositionFlags.absoluteRotation;

    }
    
    /**
     * Size factor, used for calculation of the turret and base size.
     */
    public get sizeFactor() {
        return this.owner.sizeFactor;
    }

    /**
     * Called similarly to LivingEntity.onKill
     * Spreads onKill to owner
     */

    public tick(tick: number) {        
        this.diff = -((this.positionData.angle - this.owner.positionData.angle + Math.PI * 3) % (Math.PI * 2) - Math.PI);
        this.positionData.angle = this.positionData.angle + this.diff * 0.25
      /*function closer_angle(angle1, angle2) {
  const diff = -((angle1 - angle2 + Math.PI * 3) % (Math.PI * 2) - Math.PI);
  return angle1 + diff * 0.1; /* change this constant to ur liking */
    }

}
