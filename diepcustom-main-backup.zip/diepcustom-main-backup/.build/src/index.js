var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  bannedClients: () => bannedClients
});
var fs = __toModule(require("fs"));
var import_uWebSockets = __toModule(require("uWebSockets.js"));
var import_Client = __toModule(require("./Client"));
var config = __toModule(require("./config"));
var util = __toModule(require("./util"));
var import_Game = __toModule(require("./Game"));
var import_TankDefinitions = __toModule(require("./Const/TankDefinitions"));
var import_Commands = __toModule(require("./Const/Commands"));
var import_Enums = __toModule(require("./Const/Enums"));
const PORT = config.serverPort;
const ENABLE_API = config.enableApi && config.apiLocation;
const ENABLE_CLIENT = config.enableClient && config.clientLocation && fs.existsSync(config.clientLocation);
if (ENABLE_API)
  util.log(`Rest API hosting is enabled and is now being hosted at /${config.apiLocation}`);
if (ENABLE_CLIENT)
  util.log(`Client hosting is enabled and is now being hosted from ${config.clientLocation}`);
const bannedClients = new Set();
const connections = new Map();
const allClients = new Set();
const app = (0, import_uWebSockets.App)({});
const games = [];
app.ws("/*", {
  compression: import_uWebSockets.SHARED_COMPRESSOR,
  sendPingsAutomatically: true,
  maxPayloadLength: config.wssMaxMessageSize,
  idleTimeout: 10,
  upgrade: (res, req, context) => {
    res.upgrade({ client: null, ipAddress: "", gamemode: req.getUrl().slice(1) }, req.getHeader("sec-websocket-key"), req.getHeader("sec-websocket-protocol"), req.getHeader("sec-websocket-extensions"), context);
  },
  open: (ws) => {
    const ipAddress = Buffer.from(ws.getRemoteAddressAsText()).toString();
    let conns = 0;
    if (connections.has(ipAddress))
      conns = connections.get(ipAddress);
    if (conns >= config.connectionsPerIp || bannedClients.has(ipAddress)) {
      return ws.close();
    }
    connections.set(ipAddress, conns + 1);
    const game = games.find(({ gamemode }) => gamemode === ws.getUserData().gamemode);
    if (!game) {
      return ws.close();
    }
    const client = new import_Client.default(ws, game);
    allClients.add(client);
    ws.getUserData().ipAddress = ipAddress;
    ws.getUserData().client = client;
  },
  message: (ws, message, isBinary) => {
    const { client } = ws.getUserData();
    if (!client)
      throw new Error("Unexistant client for websocket");
    client.onMessage(message, isBinary);
  },
  close: (ws, code, message) => {
    const { client, ipAddress } = ws.getUserData();
    if (client) {
      connections.set(ipAddress, connections.get(ipAddress) - 1);
      client.onClose(code, message);
      allClients.delete(client);
    }
  }
});
app.get("/*", (res, req) => {
  util.saveToVLog("Incoming request to " + req.getUrl());
  res.onAborted(() => {
  });
  if (ENABLE_API && req.getUrl().startsWith(`/${config.apiLocation}`)) {
    switch (req.getUrl().slice(config.apiLocation.length + 1)) {
      case "/":
        res.writeStatus("200 OK");
        return res.end();
      case "/tanks":
        res.writeStatus("200 OK");
        return res.end(JSON.stringify(import_TankDefinitions.default));
      case "/servers":
        res.writeStatus("200 OK");
        return res.end(JSON.stringify(games.map(({ gamemode, name }) => ({ gamemode, name }))));
      case "/commands":
        res.writeStatus("200 OK");
        return res.end(JSON.stringify(config.enableCommands ? Object.values(import_Commands.commandDefinitions) : []));
      case "/colors":
        res.writeStatus("200 OK");
        return res.end(JSON.stringify(import_Enums.ColorsHexCode));
    }
  }
  if (ENABLE_CLIENT) {
    let file = null;
    let contentType = "text/html";
    switch (req.getUrl()) {
      case "/":
        file = config.clientLocation + "/index.html";
        contentType = "text/html";
        break;
      case "/loader.js":
        file = config.clientLocation + "/loader.js";
        contentType = "application/javascript";
        break;
      case "/input.js":
        file = config.clientLocation + "/input.js";
        contentType = "application/javascript";
        break;
      case "/dma.js":
        file = config.clientLocation + "/dma.js";
        contentType = "application/javascript";
        break;
      case "/config.js":
        file = config.clientLocation + "/config.js";
        contentType = "application/javascript";
        break;
    }
    res.writeHeader("Content-Type", contentType + "; charset=utf-8");
    if (file && fs.existsSync(file)) {
      res.writeStatus("200 OK");
      return res.end(fs.readFileSync(file));
    }
    res.writeStatus("404 Not Found");
    return res.end(fs.readFileSync(config.clientLocation + "/404.html"));
  }
});
app.listen(PORT, (success) => {
  if (!success)
    throw new Error("Server failed");
  util.log(`Listening on port ${PORT}`);
  const ffa = new import_Game.default("ffa", "FFA");
  const sbx = new import_Game.default("sandbox", "Sandbox");
  games.push(ffa, sbx);
  util.saveToLog("Servers up", "All servers booted up.", 3667284);
  util.log("Dumping endpoint -> gamemode routing table");
  for (const game of games)
    console.log("> " + `localhost:${config.serverPort}/${game.gamemode}`.padEnd(40, " ") + " -> " + game.name);
});
process.on("uncaughtException", (error) => {
  util.saveToLog("Uncaught Exception", "```\n" + error.stack + "\n```", 16711680);
  throw error;
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  bannedClients
});
//# sourceMappingURL=index.js.map
