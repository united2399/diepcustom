var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  PI2: () => PI2,
  constrain: () => constrain,
  inspectLog: () => inspectLog,
  log: () => log,
  normalizeAngle: () => normalizeAngle,
  removeFast: () => removeFast,
  saveToLog: () => saveToLog,
  saveToVLog: () => saveToVLog,
  warn: () => warn
});
var chalk = __toModule(require("chalk"));
var import_util = __toModule(require("util"));
var import_config = __toModule(require("./config"));
const log = (...args) => {
  console.log(`[${Date().split(" ")[4]}]`, ...args);
};
const warn = (...args) => {
  args = args.map((s) => typeof s === "string" ? chalk.yellow(s) : s);
  console.log(chalk.yellow(`[${Date().split(" ")[4]}] WARNING: `), ...args);
};
const inspectLog = (object, c = 14) => {
  console.log((0, import_util.inspect)(object, false, c, true));
};
const removeFast = (array, index) => {
  if (index < 0 || index >= array.length)
    throw new RangeError("Index out of range. In `removeFast`");
  if (index === array.length - 1)
    array.pop();
  else
    array[index] = array.pop();
};
const constrain = (value, min, max) => {
  return Math.max(min, Math.min(max, value));
};
const PI2 = Math.PI * 2;
const normalizeAngle = (angle) => {
  return (angle % PI2 + PI2) % PI2;
};
const saveToLog = (title, description, color) => {
  console.log("[!] " + title + " (#" + color.toString(16).padStart(6, "0") + ")\n :: " + description);
};
const saveToVLog = (text) => {
  if (import_config.doVerboseLogs)
    console.log("[v] " + text);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  PI2,
  constrain,
  inspectLog,
  log,
  normalizeAngle,
  removeFast,
  saveToLog,
  saveToVLog,
  warn
});
//# sourceMappingURL=util.js.map
