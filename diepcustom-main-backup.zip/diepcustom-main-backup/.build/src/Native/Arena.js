var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  ArenaState: () => ArenaState,
  default: () => ArenaEntity
});
var import_Manager = __toModule(require("../Entity/Shape/Manager"));
var import_CrasherManager = __toModule(require("../Entity/Shape/CrasherManager"));
var import_TankBody = __toModule(require("../Entity/Tank/TankBody"));
var import_ArenaCloser = __toModule(require("../Entity/Misc/ArenaCloser"));
var import_Camera = __toModule(require("./Camera"));
var import_FieldGroups = __toModule(require("./FieldGroups"));
var import_Entity = __toModule(require("./Entity"));
var import_Enums = __toModule(require("../Const/Enums"));
var import_util = __toModule(require("../util"));
var import_Guardian = __toModule(require("../Entity/Boss/Guardian"));
var import_Summoner = __toModule(require("../Entity/Boss/Summoner"));
var import_FallenOverlord = __toModule(require("../Entity/Boss/FallenOverlord"));
var import_FallenBooster = __toModule(require("../Entity/Boss/FallenBooster"));
var import_Defender = __toModule(require("../Entity/Boss/Defender"));
var import_config = __toModule(require("../config"));
var ArenaState;
(function(ArenaState2) {
  ArenaState2[ArenaState2["OPEN"] = 0] = "OPEN";
  ArenaState2[ArenaState2["OVER"] = 1] = "OVER";
  ArenaState2[ArenaState2["CLOSING"] = 2] = "CLOSING";
  ArenaState2[ArenaState2["CLOSED"] = 3] = "CLOSED";
})(ArenaState || (ArenaState = {}));
class ArenaEntity extends import_Entity.Entity {
  constructor(game) {
    super(game);
    this.arenaData = new import_FieldGroups.ArenaGroup(this);
    this.teamData = new import_FieldGroups.TeamGroup(this);
    this.state = 0;
    this.shapeScoreRewardMultiplier = 1;
    this.allowBoss = true;
    this.boss = null;
    this.shapes = new import_Manager.default(this);
    this.crashers = new import_CrasherManager.default(this);
    this.ARENA_PADDING = 200;
    this.updateBounds(this.width = 22300, this.height = 22300);
    this.arenaData.values.topY = -this.height / 2;
    this.arenaData.values.bottomY = this.height / 2;
    this.arenaData.values.leftX = -this.width / 2;
    this.arenaData.values.rightX = this.width / 2;
    this.arenaData.values.flags = import_Enums.ArenaFlags.gameReadyStart;
    this.teamData.values.teamColor = import_Enums.Color.Neutral;
  }
  findSpawnLocation() {
    const pos = {
      x: ~~(Math.random() * this.width - this.width / 2),
      y: ~~(Math.random() * this.height - this.height / 2)
    };
    findSpawn:
      for (let i = 0; i < 20; ++i) {
        const entities = this.game.entities.collisionManager.retrieve(pos.x, pos.y, 1e3, 1e3);
        for (let len = entities.length; --len >= 0; ) {
          if (entities[len] instanceof import_TankBody.default && (entities[len].positionData.values.x - pos.x) ** 2 + (entities[len].positionData.values.y - pos.y) ** 2 < 1e6) {
            pos.x = ~~(Math.random() * this.width - this.width / 2);
            pos.y = ~~(Math.random() * this.height - this.height / 2);
            continue findSpawn;
          }
        }
        break;
      }
    return pos;
  }
  findCrasherSpawnLocation() {
    const pos = {
      x: ~~(Math.random() * this.width - this.width / 2) / 6.5,
      y: ~~(Math.random() * this.height - this.height / 2) / 6.5
    };
    findCrasherSpawn:
      for (let i = 0; i < 20; ++i) {
        const entities = this.game.entities.collisionManager.retrieve(pos.x, pos.y, 1e3, 1e3);
        for (let len = entities.length; --len >= 0; ) {
          if (entities[len] instanceof import_TankBody.default && (entities[len].positionData.values.x - pos.x) ** 2 + (entities[len].positionData.values.y - pos.y) ** 2 < 1e6) {
            pos.x = ~~(Math.random() * this.width - this.width / 2);
            pos.y = ~~(Math.random() * this.height - this.height / 2);
            continue findCrasherSpawn;
          }
        }
        break;
      }
    return pos;
  }
  updateScoreboard(scoreboardPlayers) {
    const scoreboardCount = this.arenaData.scoreboardAmount = this.arenaData.values.flags & import_Enums.ArenaFlags.hiddenScores ? 0 : Math.min(scoreboardPlayers.length, 10);
    if (scoreboardCount) {
      scoreboardPlayers.sort((p1, p2) => p2.scoreData.values.score - p1.scoreData.values.score);
      const leader = scoreboardPlayers[0];
      this.arenaData.leaderX = leader.positionData.values.x;
      this.arenaData.leaderY = leader.positionData.values.y;
      this.arenaData.flags |= import_Enums.ArenaFlags.showsLeaderArrow;
      let i;
      for (i = 0; i < scoreboardCount; ++i) {
        const player = scoreboardPlayers[i];
        if (player.styleData.values.color === import_Enums.Color.Tank)
          this.arenaData.values.scoreboardColors[i] = import_Enums.Color.ScoreboardBar;
        else
          this.arenaData.values.scoreboardColors[i] = player.styleData.values.color;
        this.arenaData.values.scoreboardNames[i] = player.nameData.values.name;
        this.arenaData.values.scoreboardScores[i] = player.scoreData.values.score;
        this.arenaData.values.scoreboardTanks[i] = player["_currentTank"];
      }
    } else if (this.arenaData.values.flags & import_Enums.ArenaFlags.showsLeaderArrow)
      this.arenaData.flags ^= import_Enums.ArenaFlags.showsLeaderArrow;
  }
  updateBounds(arenaWidth, arenaHeight) {
    this.width = arenaWidth;
    this.height = arenaHeight;
    this.arenaData.topY = -arenaHeight / 2;
    this.arenaData.bottomY = arenaHeight / 2;
    this.arenaData.leftX = -arenaWidth / 2;
    this.arenaData.rightX = arenaWidth / 2;
  }
  spawnPlayer(tank, client) {
    const { x, y } = this.findSpawnLocation();
    tank.positionData.values.x = x;
    tank.positionData.values.y = y;
  }
  close() {
    for (const client of this.game.clients) {
      client.notify("Arena closed: No players can join", 16711680, -1);
    }
    this.state = 2;
    this.arenaData.flags |= import_Enums.ArenaFlags.noJoining;
    setTimeout(() => {
      const acCount = Math.floor(Math.sqrt(this.width) / 10);
      const radius = this.width * Math.SQRT1_2 + 500;
      for (let i = 0; i < acCount; ++i) {
        const ac = new import_ArenaCloser.default(this.game);
        const angle = i / acCount * import_util.PI2;
        ac.positionData.values.x = Math.cos(angle) * radius;
        ac.positionData.values.y = Math.sin(angle) * radius;
        ac.positionData.values.angle = angle + Math.PI;
      }
      (0, import_util.saveToLog)("Arena Closing", "Arena running at `" + this.game.gamemode + "` is now closing.", 16771177);
    }, 5e3);
  }
  spawnBoss() {
    const TBoss = [import_Guardian.default, import_Summoner.default, import_FallenOverlord.default, import_FallenBooster.default, import_Defender.default][~~(Math.random() * 5)];
    this.boss = new TBoss(this.game);
  }
  tick(tick) {
    this.shapes.tick();
    this.crashers.tick();
    if (this.allowBoss && this.game.tick >= 1 && this.game.tick % import_config.bossSpawningInterval === 0 && !this.boss) {
      this.spawnBoss();
    }
    if (this.state === 3)
      return;
    const players = [];
    for (let id = 0; id <= this.game.entities.lastId; ++id) {
      const entity = this.game.entities.inner[id];
      if (import_Entity.Entity.exists(entity) && entity instanceof import_TankBody.default && entity.cameraEntity instanceof import_Camera.default && entity.cameraEntity.cameraData.values.player === entity)
        players.push(entity);
    }
    this.updateScoreboard(players);
    if (players.length === 0 && this.state === 2) {
      this.state = 3;
      setTimeout(() => {
        this.game.end();
      }, 1e4);
      return;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ArenaState
});
//# sourceMappingURL=Arena.js.map
