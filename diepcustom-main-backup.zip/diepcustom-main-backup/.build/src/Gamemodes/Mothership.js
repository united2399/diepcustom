var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => MothershipArena
});
var import_Enums = __toModule(require("../Const/Enums"));
var import_Mothership = __toModule(require("../Entity/Misc/Mothership"));
var import_TeamEntity = __toModule(require("../Entity/Misc/TeamEntity"));
var import_Arena = __toModule(require("../Native/Arena"));
var import_Entity = __toModule(require("../Native/Entity"));
var import_util = __toModule(require("../util"));
const arenaSize = 11150;
const TEAM_COLORS = [import_Enums.Color.TeamBlue, import_Enums.Color.TeamRed];
class MothershipArena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.teams = [];
    this.motherships = [];
    this.playerTeamMotMap = new Map();
    this.shapeScoreRewardMultiplier = 3;
    this.arenaData.values.flags |= import_Enums.ArenaFlags.hiddenScores;
    let randAngle = Math.random() * import_util.PI2;
    for (const teamColor of TEAM_COLORS) {
      const team = new import_TeamEntity.TeamEntity(this.game, teamColor);
      this.teams.push(team);
      const mot = new import_Mothership.default(this.game);
      this.motherships.push(mot);
      mot.relationsData.values.team = team;
      mot.styleData.values.color = team.teamData.values.teamColor;
      mot.positionData.values.x = Math.cos(randAngle) * arenaSize * 0.75;
      mot.positionData.values.y = Math.sin(randAngle) * arenaSize * 0.75;
      randAngle += import_util.PI2 / TEAM_COLORS.length;
    }
    this.updateBounds(arenaSize * 2, arenaSize * 2);
  }
  spawnPlayer(tank, client) {
    if (!this.motherships.length && !this.playerTeamMotMap.has(client)) {
      const team = this.teams[~~(Math.random() * this.teams.length)];
      const { x, y } = this.findSpawnLocation();
      tank.positionData.values.x = x;
      tank.positionData.values.y = y;
      tank.relationsData.values.team = team;
      tank.styleData.values.color = team.teamData.teamColor;
      return;
    }
    const mothership = this.playerTeamMotMap.get(client) || this.motherships[~~(Math.random() * this.motherships.length)];
    this.playerTeamMotMap.set(client, mothership);
    tank.relationsData.values.team = mothership.relationsData.values.team;
    tank.styleData.values.color = mothership.styleData.values.color;
    if (import_Entity.Entity.exists(mothership)) {
      tank.positionData.values.x = mothership.positionData.values.x;
      tank.positionData.values.y = mothership.positionData.values.y;
    } else {
      const { x, y } = this.findSpawnLocation();
      tank.positionData.values.x = x;
      tank.positionData.values.y = y;
    }
    if (client.camera)
      client.camera.relationsData.team = tank.relationsData.values.team;
  }
  updateScoreboard(scoreboardPlayers) {
    this.motherships.sort((m1, m2) => m2.healthData.values.health - m1.healthData.values.health);
    const length = Math.min(10, this.motherships.length);
    for (let i = 0; i < length; ++i) {
      const mothership = this.motherships[i];
      const team = mothership.relationsData.values.team;
      const isTeamATeam = team instanceof import_TeamEntity.TeamEntity;
      if (isTeamATeam) {
        team.teamData.mothershipX = mothership.positionData.values.x;
        team.teamData.mothershipY = mothership.positionData.values.y;
        team.teamData.flags |= import_Enums.TeamFlags.hasMothership;
      }
      if (mothership.styleData.values.color === import_Enums.Color.Tank)
        this.arenaData.values.scoreboardColors[i] = import_Enums.Color.ScoreboardBar;
      else
        this.arenaData.values.scoreboardColors[i] = mothership.styleData.values.color;
      this.arenaData.values.scoreboardNames[i] = isTeamATeam ? team.teamName : `Mothership ${i + 1}`;
      this.arenaData.values.scoreboardTanks[i] = -1;
      this.arenaData.values.scoreboardScores[i] = mothership.healthData.values.health;
      this.arenaData.values.scoreboardSuffixes[i] = " HP";
    }
    this.arenaData.scoreboardAmount = length;
  }
  tick(tick) {
    for (let i = this.motherships.length; i-- > 0; ) {
      const mot = this.motherships[i];
      if (!import_Entity.Entity.exists(mot)) {
        const pop = this.motherships.pop();
        if (pop && i < this.motherships.length)
          this.motherships[i] = pop;
      }
    }
    if (this.motherships.length <= 1) {
      if (this.state === import_Arena.ArenaState.OPEN) {
        this.state = import_Arena.ArenaState.OVER;
        setTimeout(() => {
          this.close();
        }, 5e3);
      }
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Mothership.js.map
