var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => BallArena
});
var import_Arena = __toModule(require("../../Native/Arena"));
var import_Object = __toModule(require("../../Entity/Object"));
var import_Pentagon = __toModule(require("../../Entity/Shape/Pentagon"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
var import_Sandbox = __toModule(require("../Sandbox"));
class CustomShapeManager extends import_Sandbox.SandboxShapeManager {
  spawnShape() {
    const { x, y } = this.arena.findSpawnLocation();
    const penta = new import_Pentagon.default(this.game, Math.random() < 0.25, Math.random() < 0.1);
    penta.positionData.values.x = Math.sign(x) * (Math.abs(x) - 200);
    penta.positionData.values.y = Math.sign(y) * (Math.abs(y) - 200);
    penta.relationsData.values.owner = penta.relationsData.values.team = this.arena;
    return penta;
  }
}
class BallArena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.shapes = new CustomShapeManager(this);
    this.arenaData.values.flags |= import_Enums.ArenaFlags.canUseCheats;
    this.updateBounds(2500, 2500);
    const ball = new import_Object.default(game);
    ball.nameData = new import_FieldGroups.NameGroup(ball);
    ball.nameData.values.name = "im pacman";
    ball.physicsData.values.sides = 1;
    ball.styleData.values.color = import_Enums.Color.ScoreboardBar;
    ball.physicsData.values.size = 100;
    ball.physicsData.values.absorbtionFactor = 10;
    ball.physicsData.values.flags |= import_Enums.PhysicsFlags.isBase | import_Enums.PhysicsFlags.noOwnTeamCollision;
    ball.relationsData.values.team = ball;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Ball.js.map
