var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => TestingArena
});
var import_Arena = __toModule(require("../../Native/Arena"));
var import_Manager = __toModule(require("../../Entity/Shape/Manager"));
var import_TankBody = __toModule(require("../../Entity/Tank/TankBody"));
var import_Camera = __toModule(require("../../Native/Camera"));
var import_AI = __toModule(require("../../Entity/AI"));
var import_DevTankDefinitions = __toModule(require("../../Const/DevTankDefinitions"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_FallenSpike = __toModule(require("../../Entity/Misc/Boss/FallenSpike"));
var import_FallenOverlord = __toModule(require("../../Entity/Boss/FallenOverlord"));
class ZeroShapeManager extends import_Manager.default {
  get wantedShapes() {
    return 0;
  }
}
class TestingArena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.shapes = new ZeroShapeManager(this);
    this.updateBounds(4e3, 4e3);
    this.arenaData.values.flags |= import_Enums.ArenaFlags.canUseCheats;
    setTimeout(() => {
      new import_FallenOverlord.default(game);
      new import_FallenSpike.default(game);
    }, 5e3);
  }
  spawnPlayer(tank, client) {
    tank.setTank(import_DevTankDefinitions.DevTank.Spectator);
  }
  spawnTestTank(id) {
    const testTank = new import_TankBody.default(this.game, new import_Camera.CameraEntity(this.game), new import_AI.Inputs());
    testTank.cameraEntity.cameraData.player = testTank;
    testTank.setTank(id);
    testTank.cameraEntity.setLevel(45);
    return testTank;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Testing.js.map
