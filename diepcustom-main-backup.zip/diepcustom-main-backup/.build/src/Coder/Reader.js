var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
__export(exports, {
  default: () => Reader
});
const convo = new ArrayBuffer(4);
const u8 = new Uint8Array(convo);
const u16 = new Uint16Array(convo);
const i32 = new Int32Array(convo);
const u32 = new Uint32Array(convo);
const f32 = new Float32Array(convo);
const Decoder = new TextDecoder();
const endianSwap = (num) => (num & 255) << 24 | (num & 65280) << 8 | num >> 8 & 65280 | num >> 24 & 255;
class Reader {
  constructor(buf) {
    this.at = 0;
    this.buffer = new Uint8Array(buf instanceof ArrayBuffer ? buf : buf.buffer);
  }
  u8() {
    return this.buffer[this.at++];
  }
  u16() {
    u8.set(this.buffer.subarray(this.at, this.at += 2));
    return u16[0];
  }
  u32() {
    u8.set(this.buffer.subarray(this.at, this.at += 4));
    return u32[0];
  }
  vu() {
    let out = 0;
    let i = 0;
    while (this.buffer[this.at] & 128) {
      out |= (this.buffer[this.at++] & 127) << i;
      i += 7;
    }
    out |= (this.buffer[this.at++] & 127) << i;
    return out;
  }
  vi() {
    let out = this.vu();
    return 0 - (out & 1) ^ out >>> 1;
  }
  vf() {
    i32[0] = endianSwap(this.vi());
    return f32[0];
  }
  stringNT() {
    return Decoder.decode(this.buffer.subarray(this.at, (this.at = this.buffer.indexOf(0, this.at) + 1) - 1));
  }
  string(length = this.vu()) {
    return Decoder.decode(this.buffer.slice(this.at, this.at += length));
  }
  float() {
    u8.set(this.buffer.subarray(this.at, this.at += 4));
    return f32[0];
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Reader.js.map
