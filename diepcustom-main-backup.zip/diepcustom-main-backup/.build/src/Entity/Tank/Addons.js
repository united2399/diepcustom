var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  Addon: () => Addon,
  AddonById: () => AddonById,
  GuardObject: () => GuardObject
});
var import_Object = __toModule(require("../Object"));
var import_AutoTurret = __toModule(require("./AutoTurret"));
var import_NerfedAutoTurret = __toModule(require("./NerfedAutoTurret"));
var import_Square = __toModule(require("./Square"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_Live = __toModule(require("../Live"));
var import_util = __toModule(require("../../util"));
class Addon {
  constructor(owner) {
    this.owner = owner;
    this.game = owner.game;
  }
  createGuard(sides, sizeRatio, offsetAngle, radiansPerTick) {
    return new GuardObject(this.game, this.owner, sides, sizeRatio, offsetAngle, radiansPerTick);
  }
  createAutoTurrets(count) {
    const rotPerTick = import_AI.AI.PASSIVE_ROTATION;
    const MAX_ANGLE_RANGE = import_util.PI2 / 4;
    const rotator = this.createGuard(1, 0.1, 0, rotPerTick);
    rotator.turrets = [];
    const ROT_OFFSET = 0.8;
    if (rotator.styleData.values.flags & import_Enums.StyleFlags.isVisible)
      rotator.styleData.values.flags ^= import_Enums.StyleFlags.isVisible;
    for (let i = 0; i < count; ++i) {
      const base = new import_AutoTurret.default(rotator, AutoTurretMiniDefinition);
      base.influencedByOwnerInputs = true;
      const angle = base.ai.inputs.mouse.angle = import_util.PI2 * (i / count);
      base.ai.passiveRotation = rotPerTick;
      base.ai.targetFilter = (targetPos) => {
        const pos = base.getWorldPosition();
        const angleToTarget = Math.atan2(targetPos.y - pos.y, targetPos.x - pos.x);
        const deltaAngle = (0, import_util.normalizeAngle)(angleToTarget - (angle + rotator.positionData.values.angle));
        return deltaAngle < MAX_ANGLE_RANGE || deltaAngle > import_util.PI2 - MAX_ANGLE_RANGE;
      };
      base.positionData.values.y = this.owner.physicsData.values.size * Math.sin(angle) * ROT_OFFSET;
      base.positionData.values.x = this.owner.physicsData.values.size * Math.cos(angle) * ROT_OFFSET;
      if (base.styleData.values.flags & import_Enums.StyleFlags.showsAboveParent)
        base.styleData.values.flags ^= import_Enums.StyleFlags.showsAboveParent;
      base.physicsData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
      const tickBase = base.tick;
      base.tick = (tick) => {
        base.positionData.y = this.owner.physicsData.values.size * Math.sin(angle) * ROT_OFFSET;
        base.positionData.x = this.owner.physicsData.values.size * Math.cos(angle) * ROT_OFFSET;
        tickBase.call(base, tick);
        if (base.ai.state === import_AI.AIState.idle)
          base.positionData.angle = angle + rotator.positionData.values.angle;
      };
      rotator.turrets.push(base);
    }
    return rotator;
  }
  createBackTurret(count) {
    const rotPerTick = import_AI.AI.PASSIVE_ROTATION;
    const MAX_ANGLE_RANGE = import_util.PI2 / 4;
    const rotator = this.createGuard(1, 0.1, 0, rotPerTick);
    rotator.turrets = [];
    const ROT_OFFSET = 0.8;
    if (rotator.styleData.values.flags & import_Enums.StyleFlags.isVisible)
      rotator.styleData.values.flags ^= import_Enums.StyleFlags.isVisible;
    for (let i = 0; i < count; ++i) {
      const base = new import_AutoTurret.default(this.owner, AutoTurretMiniDefinition);
      base.influencedByOwnerInputs = true;
      const angle = base.ai.inputs.mouse.angle = import_util.PI2 * (i / count - 1 / (count * 2));
      base.ai.targetFilter = (targetPos) => {
        const pos = base.getWorldPosition();
        const angleToTarget = Math.atan2(targetPos.y - pos.y, targetPos.x - pos.x);
        const deltaAngle = (0, import_util.normalizeAngle)(angleToTarget - (angle + this.owner.positionData.values.angle));
        return deltaAngle < MAX_ANGLE_RANGE || deltaAngle > import_util.PI2 - MAX_ANGLE_RANGE;
      };
      base.positionData.values.y = this.owner.physicsData.values.size * Math.sin(angle) * ROT_OFFSET;
      base.positionData.values.x = this.owner.physicsData.values.size * Math.cos(angle) * ROT_OFFSET;
      if (base.styleData.values.flags & import_Enums.StyleFlags.showsAboveParent)
        base.styleData.values.flags ^= import_Enums.StyleFlags.showsAboveParent;
      base.physicsData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
      const tickBase = base.tick;
      base.tick = (tick) => {
        base.positionData.y = this.owner.physicsData.values.size * Math.sin(angle) * ROT_OFFSET;
        base.positionData.x = this.owner.physicsData.values.size * Math.cos(angle) * ROT_OFFSET;
        tickBase.call(base, tick);
        if (base.ai.state === import_AI.AIState.idle)
          base.positionData.angle = angle + this.owner.positionData.values.angle;
      };
      rotator.turrets.push(base);
    }
    return rotator;
  }
}
const AutoTurretMiniDefinition = {
  angle: 0,
  offset: 0,
  size: 55,
  width: 42 * 0.7,
  delay: 0.01,
  reload: 1,
  recoil: 0.3,
  isTrapezoid: false,
  trapezoidDirection: 0,
  addon: null,
  bullet: {
    type: "bullet",
    health: 1,
    damage: 0.4,
    speed: 1.2,
    scatterRate: 1,
    lifeLength: 1,
    sizeRatio: 1,
    absorbtionFactor: 1
  }
};
class GuardObject extends import_Object.default {
  constructor(game, owner, sides, sizeRatio, offsetAngle, radiansPerTick) {
    super(game);
    this.owner = owner;
    this.inputs = owner.inputs;
    this.cameraEntity = owner.cameraEntity;
    sizeRatio *= Math.SQRT1_2;
    this.sizeRatio = sizeRatio;
    this.radiansPerTick = radiansPerTick;
    this.setParent(owner);
    this.relationsData.values.owner = owner;
    this.relationsData.values.team = owner.relationsData.values.team;
    this.styleData.values.color = import_Enums.Color.Border;
    this.positionData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
    this.positionData.values.angle = offsetAngle;
    this.physicsData.values.sides = sides;
    this.reloadTime = owner.reloadTime;
    this.physicsData.values.size = owner.physicsData.values.size * sizeRatio;
  }
  get sizeFactor() {
    return this.owner.sizeFactor;
  }
  onKill(killedEntity) {
    if (!(this.owner instanceof import_Live.default))
      return;
    this.owner.onKill(killedEntity);
  }
  tick(tick) {
    this.reloadTime = this.owner.reloadTime;
    this.physicsData.size = this.sizeRatio * this.owner.physicsData.values.size;
    this.positionData.angle += this.radiansPerTick;
  }
}
class SpikeAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(3, 1.3, 0, 0.17);
    this.createGuard(3, 1.3, Math.PI / 3, 0.17);
    this.createGuard(3, 1.3, Math.PI / 6, 0.17);
    this.createGuard(3, 1.3, Math.PI / 2, 0.17);
  }
}
class DomBaseAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(6, 1.24, 0, 0);
  }
}
class SmasherAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(6, 1.15, 0, 0.1);
  }
}
class LandmineAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(6, 1.15, 0, 0.1);
    this.createGuard(6, 1.15, 0, 0.05);
  }
}
class LauncherAddon extends Addon {
  constructor(owner) {
    super(owner);
    const launcher = new import_Object.default(this.game);
    const sizeRatio = 65.5 * Math.SQRT2 / 50;
    const widthRatio = 33.6 / 50;
    const size = this.owner.physicsData.values.size;
    launcher.setParent(this.owner);
    launcher.relationsData.values.owner = this.owner;
    launcher.relationsData.values.team = this.owner.relationsData.values.team;
    launcher.physicsData.values.size = sizeRatio * size;
    launcher.physicsData.values.width = widthRatio * size;
    launcher.positionData.values.x = launcher.physicsData.values.size / 2;
    launcher.styleData.values.color = import_Enums.Color.Barrel;
    launcher.physicsData.values.flags |= import_Enums.PhysicsFlags.isTrapezoid;
    launcher.physicsData.values.sides = 2;
    launcher.tick = () => {
      const size2 = this.owner.physicsData.values.size;
      launcher.physicsData.size = sizeRatio * size2;
      launcher.physicsData.width = widthRatio * size2;
      launcher.positionData.x = launcher.physicsData.values.size / 2;
    };
  }
}
class AutoTurretAddon extends Addon {
  constructor(owner) {
    super(owner);
    new import_AutoTurret.default(owner);
  }
}
class NerfedAutoTurretAddon extends Addon {
  constructor(owner) {
    super(owner);
    new import_NerfedAutoTurret.default(owner);
  }
}
class AutoSmasherAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(6, 1.15, 0, 0.1);
    new import_AutoTurret.default(owner);
  }
}
class Auto5Addon extends Addon {
  constructor(owner) {
    super(owner);
    this.createAutoTurrets(5);
  }
}
class Auto3Addon extends Addon {
  constructor(owner) {
    super(owner);
    this.createAutoTurrets(3);
  }
}
class BackTurretAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createBackTurret(1);
  }
}
class SquareAddon extends Addon {
  constructor(owner) {
    super(owner);
    new import_Square.default(owner);
  }
}
class PronouncedAddon extends Addon {
  constructor(owner) {
    super(owner);
    const pronounce = new import_Object.default(this.game);
    const sizeRatio = 50 / 50;
    const widthRatio = 42 / 50;
    const offsetRatio = 40 / 50;
    const size = this.owner.physicsData.values.size;
    pronounce.setParent(this.owner);
    pronounce.relationsData.values.owner = this.owner;
    pronounce.relationsData.values.team = this.owner.relationsData.values.team;
    pronounce.physicsData.values.size = sizeRatio * size;
    pronounce.physicsData.values.width = widthRatio * size;
    pronounce.positionData.values.x = offsetRatio * size;
    pronounce.positionData.values.angle = Math.PI;
    pronounce.styleData.values.color = import_Enums.Color.Barrel;
    pronounce.physicsData.values.flags |= import_Enums.PhysicsFlags.isTrapezoid;
    pronounce.physicsData.values.sides = 2;
    pronounce.tick = () => {
      const size2 = this.owner.physicsData.values.size;
      pronounce.physicsData.size = sizeRatio * size2;
      pronounce.physicsData.width = widthRatio * size2;
      pronounce.positionData.x = offsetRatio * size2;
    };
  }
}
class PronouncedDomAddon extends Addon {
  constructor(owner) {
    super(owner);
    const pronounce = new import_Object.default(this.game);
    const sizeRatio = 22 / 50;
    const widthRatio = 35 / 50;
    const offsetRatio = 50 / 50;
    const size = this.owner.physicsData.values.size;
    pronounce.setParent(this.owner);
    pronounce.relationsData.values.owner = this.owner;
    pronounce.relationsData.values.team = this.owner.relationsData.values.team;
    pronounce.physicsData.values.size = sizeRatio * size;
    pronounce.physicsData.values.width = widthRatio * size;
    pronounce.positionData.values.x = offsetRatio * size;
    pronounce.positionData.values.angle = Math.PI;
    pronounce.styleData.values.color = import_Enums.Color.Barrel;
    pronounce.physicsData.values.flags |= import_Enums.PhysicsFlags.isTrapezoid;
    pronounce.physicsData.values.sides = 2;
    pronounce.tick = () => {
      const size2 = this.owner.physicsData.values.size;
      pronounce.physicsData.size = sizeRatio * size2;
      pronounce.physicsData.width = widthRatio * size2;
      pronounce.positionData.x = offsetRatio * size2;
    };
  }
}
class WeirdSpikeAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(3, 1.5, 0, 0.17);
    this.createGuard(3, 1.5, 0, -0.16);
  }
}
class Auto2Addon extends Addon {
  constructor(owner) {
    super(owner);
    this.createAutoTurrets(2);
  }
}
class Auto7Addon extends Addon {
  constructor(owner) {
    super(owner);
    this.createAutoTurrets(7);
  }
}
class AutoRocketAddon extends Addon {
  constructor(owner) {
    super(owner);
    const base = new import_AutoTurret.default(owner, {
      angle: 0,
      offset: 0,
      size: 40,
      width: 26.25,
      delay: 0,
      reload: 2,
      recoil: 0.75,
      isTrapezoid: true,
      trapezoidDirection: 3.141592653589793,
      addon: null,
      bullet: {
        type: "rocket",
        sizeRatio: 1,
        health: 2.5,
        damage: 0.5,
        speed: 0.3,
        scatterRate: 1,
        lifeLength: 0.75,
        absorbtionFactor: 0.1
      }
    });
    new LauncherAddon(base);
    base.turret.styleData.zIndex += 2;
  }
}
class SpieskAddon extends Addon {
  constructor(owner) {
    super(owner);
    this.createGuard(4, 1.3, 0, 0.17);
    this.createGuard(4, 1.3, Math.PI / 6, 0.17);
    this.createGuard(4, 1.3, 2 * Math.PI / 6, 0.17);
  }
}
const AddonById = {
  spike: SpikeAddon,
  dombase: DomBaseAddon,
  launcher: LauncherAddon,
  dompronounced: PronouncedDomAddon,
  auto5: Auto5Addon,
  auto3: Auto3Addon,
  autosmasher: AutoSmasherAddon,
  pronounced: PronouncedAddon,
  smasher: SmasherAddon,
  landmine: LandmineAddon,
  autoturret: AutoTurretAddon,
  weirdspike: WeirdSpikeAddon,
  auto7: Auto7Addon,
  auto2: Auto2Addon,
  autorocket: AutoRocketAddon,
  spiesk: SpieskAddon,
  backturret: BackTurretAddon,
  nerfedautoturret: NerfedAutoTurretAddon,
  square: SquareAddon
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  Addon,
  AddonById,
  GuardObject
});
//# sourceMappingURL=Addons.js.map
