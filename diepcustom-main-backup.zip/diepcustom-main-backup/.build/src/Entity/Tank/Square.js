var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => AutoTurret
});
var import_Object = __toModule(require("../Object"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
class AutoTurret extends import_Object.default {
  constructor(owner, baseSize = 21.5) {
    super(owner.game);
    this.nameData = new import_FieldGroups.NameGroup(this);
    this.inputs = new import_AI.Inputs();
    this.diff = 0;
    this.owner = owner;
    this.setParent(owner);
    this.relationsData.values.owner = owner;
    this.relationsData.values.team = owner.relationsData.values.team;
    this.physicsData.values.sides = 4;
    this.baseSize = baseSize;
    this.physicsData.values.size = this.baseSize * this.sizeFactor;
    this.styleData.values.color = import_Enums.Color.Barrel;
    this.styleData.values.flags |= import_Enums.StyleFlags.showsAboveParent;
    this.positionData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
  }
  get sizeFactor() {
    return this.owner.sizeFactor;
  }
  tick(tick) {
    this.diff = -((this.positionData.angle - this.owner.positionData.angle + Math.PI * 3) % (Math.PI * 2) - Math.PI);
    this.positionData.angle = this.positionData.angle + this.diff * 0.25;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Square.js.map
