var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Rocket
});
var import_Barrel = __toModule(require("../Barrel"));
var import_Bullet = __toModule(require("./Bullet"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_AI = __toModule(require("../../AI"));
const RocketBarrelDefinition = {
  angle: Math.PI,
  offset: 0,
  size: 70,
  width: 72,
  delay: 0,
  reload: 0.15,
  recoil: 3.3,
  isTrapezoid: true,
  trapezoidDirection: 0,
  addon: null,
  bullet: {
    type: "bullet",
    health: 0.3,
    damage: 3 / 5,
    speed: 1.5,
    scatterRate: 5,
    lifeLength: 0.1,
    sizeRatio: 1,
    absorbtionFactor: 1
  }
};
class Rocket extends import_Bullet.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel, tank, tankDefinition, shootAngle);
    this.reloadTime = 1;
    this.inputs = new import_AI.Inputs();
    this.cameraEntity = tank.cameraEntity;
    const rocketBarrel = this.rocketBarrel = new import_Barrel.default(this, __spreadValues({}, RocketBarrelDefinition));
    rocketBarrel.styleData.values.color = this.styleData.values.color;
  }
  get sizeFactor() {
    return this.physicsData.values.size / 50;
  }
  tick(tick) {
    this.reloadTime = this.tank.reloadTime;
    if (!this.deletionAnimation && this.rocketBarrel)
      this.rocketBarrel.definition.width = this.barrelEntity.definition.width / 2 * RocketBarrelDefinition.width / this.physicsData.values.size;
    super.tick(tick);
    if (this.deletionAnimation)
      return;
    if (tick - this.spawnTick >= this.tank.reloadTime)
      this.inputs.flags |= import_Enums.InputFlags.leftclick;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Rocket.js.map
