var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Trap
});
var import_Bullet = __toModule(require("./Bullet"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_DevTankDefinitions = __toModule(require("../../../Const/DevTankDefinitions"));
var import_util = __toModule(require("../../../util"));
class Trap extends import_Bullet.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel, tank, tankDefinition, shootAngle);
    this.collisionEnd = 0;
    const bulletDefinition = barrel.definition.bullet;
    this.baseSpeed = barrel.bulletAccel / 2 + 30 - Math.random() * barrel.definition.bullet.scatterRate;
    this.baseAccel = 0;
    this.physicsData.values.sides = bulletDefinition.sides ?? 3;
    if (this.physicsData.values.flags & import_Enums.PhysicsFlags.noOwnTeamCollision)
      this.physicsData.values.flags ^= import_Enums.PhysicsFlags.noOwnTeamCollision;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.onlySameOwnerCollision;
    this.styleData.values.flags |= import_Enums.StyleFlags.isTrap | import_Enums.StyleFlags.isStar;
    this.styleData.values.flags &= ~import_Enums.StyleFlags.hasNoDmgIndicator;
    this.collisionEnd = this.lifeLength >> 3;
    this.lifeLength = 600 * barrel.definition.bullet.lifeLength >> 3;
    if (tankDefinition && tankDefinition.id === import_DevTankDefinitions.DevTank.Bouncy)
      this.collisionEnd = this.lifeLength - 1;
    this.positionData.values.angle = Math.random() * import_util.PI2;
  }
  tick(tick) {
    super.tick(tick);
    if (tick - this.spawnTick === this.collisionEnd) {
      if (this.physicsData.values.flags & import_Enums.PhysicsFlags.onlySameOwnerCollision)
        this.physicsData.flags ^= import_Enums.PhysicsFlags.onlySameOwnerCollision;
      this.physicsData.values.flags |= import_Enums.PhysicsFlags.noOwnTeamCollision;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Trap.js.map
