var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Minion
});
var import_Barrel = __toModule(require("../Barrel"));
var import_Drone = __toModule(require("./Drone"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_AI = __toModule(require("../../AI"));
const MinionBarrelDefinition = {
  angle: 0,
  offset: 0,
  size: 80,
  width: 50.4,
  delay: 0,
  reload: 1,
  recoil: 1.35,
  isTrapezoid: false,
  trapezoidDirection: 0,
  addon: null,
  bullet: {
    type: "bullet",
    health: 0.4,
    damage: 0.4,
    speed: 0.8,
    scatterRate: 1,
    lifeLength: 1,
    sizeRatio: 1,
    absorbtionFactor: 1
  }
};
const _Minion = class extends import_Drone.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel, tank, tankDefinition, shootAngle);
    this.reloadTime = 1;
    this.inputs = new import_AI.Inputs();
    const bulletDefinition = barrel.definition.bullet;
    this.inputs = this.ai.inputs;
    this.ai.viewRange = 900;
    this.usePosAngle = false;
    this.physicsData.values.sides = bulletDefinition.sides ?? 1;
    this.physicsData.values.size *= 1.2;
    if (this.physicsData.values.flags & import_Enums.PhysicsFlags.noOwnTeamCollision)
      this.physicsData.values.flags ^= import_Enums.PhysicsFlags.noOwnTeamCollision;
    if (this.physicsData.values.flags & import_Enums.PhysicsFlags.canEscapeArena)
      this.physicsData.values.flags ^= import_Enums.PhysicsFlags.canEscapeArena;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.onlySameOwnerCollision;
    this.cameraEntity = tank.cameraEntity;
    this.minionBarrel = new import_Barrel.default(this, MinionBarrelDefinition);
    this.ai.movementSpeed = this.ai.aimSpeed = this.baseAccel;
  }
  get sizeFactor() {
    return this.physicsData.values.size / 50;
  }
  tickMixin(tick) {
    this.reloadTime = this.tank.reloadTime;
    const usingAI = !this.canControlDrones || !this.tank.inputs.attemptingShot() && !this.tank.inputs.attemptingRepel();
    const inputs = !usingAI ? this.tank.inputs : this.ai.inputs;
    if (usingAI && this.ai.state === import_AI.AIState.idle) {
      this.movementAngle = this.positionData.values.angle;
    } else {
      this.inputs.flags |= import_Enums.InputFlags.leftclick;
      const dist = inputs.mouse.distanceToSQ(this.positionData.values);
      if (dist < _Minion.FOCUS_RADIUS / 4) {
        this.movementAngle = this.positionData.values.angle + Math.PI;
      } else if (dist < _Minion.FOCUS_RADIUS) {
        this.movementAngle = this.positionData.values.angle + Math.PI / 2;
      } else
        this.movementAngle = this.positionData.values.angle;
    }
    super.tickMixin(tick);
  }
};
let Minion = _Minion;
Minion.FOCUS_RADIUS = 850 ** 2;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Minion.js.map
