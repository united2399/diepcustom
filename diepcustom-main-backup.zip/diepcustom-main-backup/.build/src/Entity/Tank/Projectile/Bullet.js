var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Bullet
});
var import_Live = __toModule(require("../../Live"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_Entity = __toModule(require("../../../Native/Entity"));
class Bullet extends import_Live.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel.game);
    this.spawnTick = 0;
    this.baseAccel = 0;
    this.baseSpeed = 0;
    this.deathAccelFactor = 0.5;
    this.lifeLength = 0;
    this.movementAngle = 0;
    this.tankDefinition = null;
    this.usePosAngle = false;
    var _a;
    this.tank = tank;
    this.tankDefinition = tankDefinition;
    this.movementAngle = shootAngle;
    this.barrelEntity = barrel;
    this.spawnTick = barrel.game.tick;
    this.relationsData.values.owner = tank;
    tank.rootParent.styleData.zIndex = barrel.game.entities.zIndex++;
    const bulletDefinition = barrel.definition.bullet;
    const sizeFactor = tank.sizeFactor;
    const statLevels = (_a = tank.cameraEntity.cameraData) == null ? void 0 : _a.values.statLevels.values;
    this.relationsData.values.team = barrel.relationsData.values.team;
    this.relationsData.values.owner = tank;
    this.physicsData.values.sides = bulletDefinition.sides ?? 1;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.noOwnTeamCollision | import_Enums.PhysicsFlags.canEscapeArena;
    if (tank.positionData.values.flags & import_Enums.PositionFlags.canMoveThroughWalls)
      this.positionData.values.flags |= import_Enums.PositionFlags.canMoveThroughWalls;
    this.physicsData.values.size = barrel.physicsData.values.width / 2 * bulletDefinition.sizeRatio;
    this.styleData.values.color = bulletDefinition.color || tank.rootParent.styleData.values.color;
    this.styleData.values.flags |= import_Enums.StyleFlags.hasNoDmgIndicator;
    const bulletDamage = statLevels ? statLevels[import_Enums.Stat.BulletDamage] : 0;
    const bulletPenetration = statLevels ? statLevels[import_Enums.Stat.BulletPenetration] : 0;
    this.physicsData.values.absorbtionFactor = bulletDefinition.absorbtionFactor;
    this.physicsData.values.pushFactor = (7 / 3 + bulletDamage) * bulletDefinition.damage * bulletDefinition.absorbtionFactor;
    this.baseAccel = barrel.bulletAccel;
    this.baseSpeed = barrel.bulletAccel + 30 - Math.random() * bulletDefinition.scatterRate;
    this.healthData.values.health = this.healthData.values.maxHealth = (1.5 * bulletPenetration + 2) * bulletDefinition.health;
    this.damagePerTick = (7 + bulletDamage * 3) * bulletDefinition.damage;
    this.damageReduction = 0.25;
    this.lifeLength = bulletDefinition.lifeLength * 72;
    const { x, y } = tank.getWorldPosition();
    this.positionData.values.x = x + Math.cos(shootAngle) * barrel.physicsData.values.size - Math.sin(shootAngle) * barrel.definition.offset * sizeFactor;
    this.positionData.values.y = y + Math.sin(shootAngle) * barrel.physicsData.values.size + Math.cos(shootAngle) * barrel.definition.offset * sizeFactor;
    this.positionData.values.angle = shootAngle;
  }
  onKill(killedEntity) {
    if (typeof this.tank.onKill === "function")
      this.tank.onKill(killedEntity);
  }
  tick(tick) {
    var _a;
    super.tick(tick);
    if (tick === this.spawnTick + 1)
      this.addAcceleration(this.movementAngle, this.baseSpeed);
    else
      this.maintainVelocity(this.usePosAngle ? this.positionData.values.angle : this.movementAngle, this.baseAccel);
    if (tick - this.spawnTick >= this.lifeLength)
      this.destroy(true);
    if ((((_a = this.relationsData.values.team) == null ? void 0 : _a.entityState) || 0) & import_Entity.EntityStateFlags.needsDelete)
      this.relationsData.values.team = null;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Bullet.js.map
