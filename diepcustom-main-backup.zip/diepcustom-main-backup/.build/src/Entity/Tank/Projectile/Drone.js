var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Drone
});
var import_Bullet = __toModule(require("./Bullet"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_Entity = __toModule(require("../../../Native/Entity"));
var import_AI = __toModule(require("../../AI"));
const _Drone = class extends import_Bullet.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel, tank, tankDefinition, shootAngle);
    this.restCycle = true;
    const bulletDefinition = barrel.definition.bullet;
    this.usePosAngle = true;
    this.ai = new import_AI.AI(this);
    this.ai.viewRange = 850 * tank.sizeFactor;
    this.ai.targetFilter = (targetPos) => (targetPos.x - this.tank.positionData.values.x) ** 2 + (targetPos.y - this.tank.positionData.values.y) ** 2 <= this.ai.viewRange ** 2;
    this.canControlDrones = typeof this.barrelEntity.definition.canControlDrones === "boolean" && this.barrelEntity.definition.canControlDrones;
    this.physicsData.values.sides = bulletDefinition.sides ?? 3;
    if (this.physicsData.values.flags & import_Enums.PhysicsFlags.noOwnTeamCollision)
      this.physicsData.values.flags ^= import_Enums.PhysicsFlags.noOwnTeamCollision;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.onlySameOwnerCollision;
    this.styleData.values.flags &= ~import_Enums.StyleFlags.hasNoDmgIndicator;
    if (barrel.definition.bullet.lifeLength !== -1) {
      this.lifeLength = 88 * barrel.definition.bullet.lifeLength;
    } else {
      this.lifeLength = Infinity;
      if (this.physicsData.values.flags & import_Enums.PhysicsFlags.canEscapeArena)
        this.physicsData.values.flags ^= import_Enums.PhysicsFlags.canEscapeArena;
    }
    this.deathAccelFactor = 1;
    this.physicsData.values.pushFactor = 4;
    this.physicsData.values.absorbtionFactor = bulletDefinition.absorbtionFactor;
    this.baseSpeed /= 3;
    barrel.droneCount += 1;
    this.ai.movementSpeed = this.ai.aimSpeed = this.baseAccel;
  }
  destroy(animate = true) {
    if (!animate)
      this.barrelEntity.droneCount -= 1;
    super.destroy(animate);
  }
  tickMixin(tick) {
    super.tick(tick);
  }
  tick(tick) {
    const usingAI = !this.canControlDrones || this.tank.inputs.deleted || !this.tank.inputs.attemptingShot() && !this.tank.inputs.attemptingRepel();
    const inputs = !usingAI ? this.tank.inputs : this.ai.inputs;
    if (usingAI && this.ai.state === import_AI.AIState.idle) {
      const delta = {
        x: this.positionData.values.x - this.tank.positionData.values.x,
        y: this.positionData.values.y - this.tank.positionData.values.y
      };
      const base = this.baseAccel;
      let unitDist = (delta.x ** 2 + delta.y ** 2) / _Drone.MAX_RESTING_RADIUS;
      if (unitDist <= 1 && this.restCycle) {
        this.baseAccel /= 6;
        this.positionData.angle += 0.01 + 0.012 * unitDist;
      } else {
        const offset = Math.atan2(delta.y, delta.x) + Math.PI / 2;
        delta.x = this.tank.positionData.values.x + Math.cos(offset) * this.tank.physicsData.values.size * 1.2 - this.positionData.values.x;
        delta.y = this.tank.positionData.values.y + Math.sin(offset) * this.tank.physicsData.values.size * 1.2 - this.positionData.values.y;
        this.positionData.angle = Math.atan2(delta.y, delta.x);
        if (unitDist < 0.5)
          this.baseAccel /= 3;
        this.restCycle = delta.x ** 2 + delta.y ** 2 <= 4 * this.tank.physicsData.values.size ** 2;
      }
      if (!import_Entity.Entity.exists(this.barrelEntity))
        this.destroy();
      this.tickMixin(tick);
      this.baseAccel = base;
      return;
    } else {
      this.positionData.angle = Math.atan2(inputs.mouse.y - this.positionData.values.y, inputs.mouse.x - this.positionData.values.x);
      this.restCycle = false;
    }
    if (this.canControlDrones && inputs.attemptingRepel()) {
      this.positionData.angle += Math.PI;
    }
    if (!import_Entity.Entity.exists(this.barrelEntity))
      this.destroy();
    this.tickMixin(tick);
  }
};
let Drone = _Drone;
Drone.MAX_RESTING_RADIUS = 400 ** 2;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Drone.js.map
