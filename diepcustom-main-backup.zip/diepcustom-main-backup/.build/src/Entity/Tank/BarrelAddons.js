var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  BarrelAddon: () => BarrelAddon,
  BarrelAddonById: () => BarrelAddonById,
  TrapLauncher: () => TrapLauncher,
  TrapLauncherAddon: () => TrapLauncherAddon
});
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Object = __toModule(require("../Object"));
class BarrelAddon {
  constructor(owner) {
    this.owner = owner;
    this.game = owner.game;
  }
}
class TrapLauncher extends import_Object.default {
  constructor(barrel) {
    super(barrel.game);
    this.barrelEntity = barrel;
    this.setParent(barrel);
    this.relationsData.values.team = barrel;
    this.physicsData.values.flags = import_Enums.PhysicsFlags.isTrapezoid | import_Enums.PhysicsFlags._unknown;
    this.styleData.values.color = import_Enums.Color.Barrel;
    this.physicsData.values.sides = 2;
    this.physicsData.values.width = barrel.physicsData.values.width;
    this.physicsData.values.size = barrel.physicsData.values.width * (20 / 42);
    this.positionData.values.x = (barrel.physicsData.values.size + this.physicsData.values.size) / 2;
  }
  resize() {
    this.physicsData.sides = 2;
    this.physicsData.width = this.barrelEntity.physicsData.values.width;
    this.physicsData.size = this.barrelEntity.physicsData.values.width * (20 / 42);
    this.positionData.x = (this.barrelEntity.physicsData.values.size + this.physicsData.values.size) / 2;
  }
  tick(tick) {
    super.tick(tick);
    this.resize();
  }
}
class TrapLauncherAddon extends BarrelAddon {
  constructor(owner) {
    super(owner);
    this.launcherEntity = new TrapLauncher(owner);
  }
}
const BarrelAddonById = {
  trapLauncher: TrapLauncherAddon
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BarrelAddon,
  BarrelAddonById,
  TrapLauncher,
  TrapLauncherAddon
});
//# sourceMappingURL=BarrelAddons.js.map
