var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  ShootCycle: () => ShootCycle,
  default: () => Barrel
});
var util = __toModule(require("../../util"));
var import_Bullet = __toModule(require("./Projectile/Bullet"));
var import_Trap = __toModule(require("./Projectile/Trap"));
var import_Drone = __toModule(require("./Projectile/Drone"));
var import_Rocket = __toModule(require("./Projectile/Rocket"));
var import_Skimmer = __toModule(require("./Projectile/Skimmer"));
var import_Minion = __toModule(require("./Projectile/Minion"));
var import_Object = __toModule(require("../Object"));
var import_TankBody = __toModule(require("./TankBody"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
var import_DevTankDefinitions = __toModule(require("../../Const/DevTankDefinitions"));
var import_Flame = __toModule(require("./Projectile/Flame"));
var import_MazeWall = __toModule(require("../Misc/MazeWall"));
var import_CrocSkimmer = __toModule(require("./Projectile/CrocSkimmer"));
var import_BarrelAddons = __toModule(require("./BarrelAddons"));
var import_Swarm = __toModule(require("./Projectile/Swarm"));
var import_NecromancerSquare = __toModule(require("./Projectile/NecromancerSquare"));
var import_NecromancerEgg = __toModule(require("./Projectile/NecromancerEgg"));
class ShootCycle {
  constructor(barrel) {
    this.barrelEntity = barrel;
    this.barrelEntity.barrelData.reloadTime = this.barrelEntity.tank.reloadTime * this.barrelEntity.definition.reload;
    this.reloadTime = this.pos = barrel.barrelData.values.reloadTime;
  }
  tick() {
    const reloadTime = this.barrelEntity.tank.reloadTime * this.barrelEntity.definition.reload;
    if (reloadTime !== this.reloadTime) {
      this.pos *= reloadTime / this.reloadTime;
      this.reloadTime = reloadTime;
    }
    const alwaysShoot = this.barrelEntity.definition.forceFire || this.barrelEntity.definition.bullet.type === "drone" || this.barrelEntity.definition.bullet.type === "minion";
    if (this.pos >= reloadTime) {
      if (!this.barrelEntity.attemptingShot && !alwaysShoot) {
        this.pos = reloadTime;
        return;
      }
      if (typeof this.barrelEntity.definition.droneCount === "number" && this.barrelEntity.droneCount >= this.barrelEntity.definition.droneCount) {
        this.pos = reloadTime;
        return;
      }
    }
    if (this.pos >= reloadTime * (1 + this.barrelEntity.definition.delay)) {
      this.barrelEntity.barrelData.reloadTime = reloadTime;
      this.barrelEntity.shoot();
      this.pos = reloadTime * this.barrelEntity.definition.delay;
    }
    this.pos += 1;
  }
}
class Barrel extends import_Object.default {
  constructor(owner, barrelDefinition) {
    super(owner.game);
    this.attemptingShot = false;
    this.bulletAccel = 20;
    this.droneCount = 0;
    this.addons = [];
    this.barrelData = new import_FieldGroups.BarrelGroup(this);
    var _a;
    this.tank = owner;
    this.definition = barrelDefinition;
    this.styleData.values.color = import_Enums.Color.Barrel;
    this.physicsData.values.sides = 2;
    if (barrelDefinition.isTrapezoid)
      this.physicsData.values.flags |= import_Enums.PhysicsFlags.isTrapezoid;
    this.setParent(owner);
    this.relationsData.values.owner = owner;
    this.relationsData.values.team = owner.relationsData.values.team;
    const sizeFactor = this.tank.sizeFactor;
    const size = this.physicsData.values.size = this.definition.size * sizeFactor;
    this.physicsData.values.width = this.definition.width * sizeFactor;
    this.positionData.values.angle = this.definition.angle + this.definition.trapezoidDirection;
    this.positionData.values.x = Math.cos(this.definition.angle) * size / 2 - Math.sin(this.definition.angle) * this.definition.offset * sizeFactor;
    this.positionData.values.y = Math.sin(this.definition.angle) * size / 2 + Math.cos(this.definition.angle) * this.definition.offset * sizeFactor;
    if (barrelDefinition.addon) {
      const AddonConstructor = import_BarrelAddons.BarrelAddonById[barrelDefinition.addon];
      if (AddonConstructor)
        this.addons.push(new AddonConstructor(this));
    }
    this.barrelData.values.trapezoidDirection = barrelDefinition.trapezoidDirection;
    this.shootCycle = new ShootCycle(this);
    this.bulletAccel = (20 + (((_a = owner.cameraEntity.cameraData) == null ? void 0 : _a.values.statLevels.values[import_Enums.Stat.BulletSpeed]) || 0) * 3) * barrelDefinition.bullet.speed;
  }
  shoot() {
    this.barrelData.flags ^= import_Enums.BarrelFlags.hasShot;
    const scatterAngle = Math.PI / 180 * this.definition.bullet.scatterRate * (Math.random() - 0.5) * 10;
    let angle = this.definition.angle + scatterAngle + this.tank.positionData.values.angle;
    this.rootParent.addAcceleration(angle + Math.PI, this.definition.recoil * 2);
    let tankDefinition = null;
    if (this.rootParent instanceof import_TankBody.default)
      tankDefinition = this.rootParent.definition;
    switch (this.definition.bullet.type) {
      case "skimmer":
        new import_Skimmer.default(this, this.tank, tankDefinition, angle, this.tank.inputs.attemptingRepel() ? -import_Skimmer.default.BASE_ROTATION : import_Skimmer.default.BASE_ROTATION);
        break;
      case "rocket":
        new import_Rocket.default(this, this.tank, tankDefinition, angle);
        break;
      case "bullet": {
        const bullet = new import_Bullet.default(this, this.tank, tankDefinition, angle);
        if (tankDefinition && (tankDefinition.id === import_Enums.Tank.ArenaCloser || tankDefinition.id === import_DevTankDefinitions.DevTank.Squirrel))
          bullet.positionData.flags |= import_Enums.PositionFlags.canMoveThroughWalls;
        break;
      }
      case "trap":
        new import_Trap.default(this, this.tank, tankDefinition, angle);
        break;
      case "drone":
        new import_Drone.default(this, this.tank, tankDefinition, angle);
        break;
      case "necrodrone":
        new import_NecromancerSquare.default(this, this.tank, tankDefinition, angle);
        break;
      case "infestordrone":
        new import_NecromancerEgg.default(this, this.tank, tankDefinition, angle);
        break;
      case "swarm":
        new import_Swarm.Swarm(this, this.tank, tankDefinition, angle);
        break;
      case "minion":
        new import_Minion.default(this, this.tank, tankDefinition, angle);
        break;
      case "flame":
        new import_Flame.default(this, this.tank, tankDefinition, angle);
        break;
      case "wall": {
        let w = new import_MazeWall.default(this.game, Math.round(this.tank.inputs.mouse.x / 50) * 50, Math.round(this.tank.inputs.mouse.y / 50) * 50, 250, 250);
        setTimeout(() => {
          w.destroy();
        }, 60 * 1e3);
        break;
      }
      case "croc":
        new import_CrocSkimmer.default(this, this.tank, tankDefinition, angle);
        break;
      default:
        util.log("Ignoring attempt to spawn projectile of type " + this.definition.bullet.type);
        break;
    }
  }
  resize() {
    var _a;
    const sizeFactor = this.tank.sizeFactor;
    const size = this.physicsData.size = this.definition.size * sizeFactor;
    this.physicsData.width = this.definition.width * sizeFactor;
    this.positionData.angle = this.definition.angle + this.definition.trapezoidDirection;
    this.positionData.x = Math.cos(this.definition.angle) * size / 2 - Math.sin(this.definition.angle) * this.definition.offset * sizeFactor;
    this.positionData.y = Math.sin(this.definition.angle) * size / 2 + Math.cos(this.definition.angle) * this.definition.offset * sizeFactor;
    this.bulletAccel = (20 + (((_a = this.tank.cameraEntity.cameraData) == null ? void 0 : _a.values.statLevels.values[import_Enums.Stat.BulletSpeed]) || 0) * 3) * this.definition.bullet.speed;
  }
  tick(tick) {
    this.resize();
    this.relationsData.values.team = this.tank.relationsData.values.team;
    if (!this.tank.rootParent.deletionAnimation) {
      this.attemptingShot = this.tank.inputs.attemptingShot();
      this.shootCycle.tick();
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ShootCycle
});
//# sourceMappingURL=Barrel.js.map
