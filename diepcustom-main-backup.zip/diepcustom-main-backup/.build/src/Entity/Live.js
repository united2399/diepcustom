var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => LivingEntity
});
var util = __toModule(require("../util"));
var import_Object = __toModule(require("./Object"));
var import_TankBody = __toModule(require("./Tank/TankBody"));
var import_TankDefinitions = __toModule(require("../Const/TankDefinitions"));
var import_Enums = __toModule(require("../Const/Enums"));
var import_FieldGroups = __toModule(require("../Native/FieldGroups"));
class LivingEntity extends import_Object.default {
  constructor() {
    super(...arguments);
    this.healthData = new import_FieldGroups.HealthGroup(this);
    this.scoreReward = 0;
    this.regenPerTick = 0;
    this.damagePerTick = 8;
    this.damagedEntities = [];
    this.lastDamageTick = -1;
    this.lastDamageAnimationTick = -1;
    this.damageReduction = 1;
  }
  destroy(animate = true) {
    if (this.hash === 0)
      return;
    if (animate)
      this.healthData.health = 0;
    super.destroy(animate);
  }
  static applyDamage(entity1, entity2) {
    if (entity1.healthData.values.health <= 0 || entity2.healthData.values.health <= 0)
      return;
    if (entity1.damagedEntities.includes(entity2) || entity2.damagedEntities.includes(entity1))
      return;
    if (entity1.damageReduction === 0 && entity2.damageReduction === 0)
      return;
    if (entity1.damagePerTick === 0 && entity1.physicsData.values.pushFactor === 0 || entity2.damagePerTick === 0 && entity2.physicsData.values.pushFactor === 0)
      return;
    const game = entity1.game;
    let dF1 = entity1.damagePerTick * entity2.damageReduction;
    let dF2 = entity2.damagePerTick * entity1.damageReduction;
    if (entity1 instanceof import_TankBody.default && entity2 instanceof import_TankBody.default) {
      dF1 *= 1.5;
      dF2 *= 1.5;
    }
    const ratio = Math.max(1 - entity1.healthData.values.health / dF2, 1 - entity2.healthData.values.health / dF1);
    if (ratio > 0) {
      dF1 *= 1 - ratio;
      dF2 *= 1 - ratio;
    }
    if (entity2.lastDamageAnimationTick !== game.tick && !(entity2.styleData.values.flags & import_Enums.StyleFlags.hasNoDmgIndicator)) {
      entity2.styleData.flags ^= import_Enums.StyleFlags.hasBeenDamaged;
      entity2.lastDamageAnimationTick = game.tick;
    }
    if (dF1 !== 0) {
      if (entity2.lastDamageTick !== game.tick && entity2 instanceof import_TankBody.default && entity2.definition.flags.invisibility && entity2.styleData.values.opacity < import_TankDefinitions.visibilityRateDamage)
        entity2.styleData.opacity += import_TankDefinitions.visibilityRateDamage;
      entity2.lastDamageTick = game.tick;
      entity2.healthData.health -= dF1;
    }
    if (entity1.lastDamageAnimationTick !== game.tick && !(entity1.styleData.values.flags & import_Enums.StyleFlags.hasNoDmgIndicator)) {
      entity1.styleData.flags ^= import_Enums.StyleFlags.hasBeenDamaged;
      entity1.lastDamageAnimationTick = game.tick;
    }
    if (dF2 !== 0) {
      if (entity1.lastDamageTick !== game.tick && entity1 instanceof import_TankBody.default && entity1.definition.flags.invisibility && entity1.styleData.values.opacity < import_TankDefinitions.visibilityRateDamage)
        entity1.styleData.opacity += import_TankDefinitions.visibilityRateDamage;
      entity1.lastDamageTick = game.tick;
      entity1.healthData.health -= dF2;
    }
    entity1.damagedEntities.push(entity2);
    entity2.damagedEntities.push(entity1);
    if (entity1.healthData.values.health < -1e-4) {
      util.warn("Health is below 0. Something in damage messed up]: ", entity1.healthData.health, entity2.healthData.health, ratio, dF1, dF2);
    }
    if (entity2.healthData.values.health < -1e-4) {
      util.warn("Health is below 0. Something in damage messed up]: ", entity1.healthData.health, entity2.healthData.health, ratio, dF1, dF2);
    }
    if (entity1.healthData.values.health < 1e-4)
      entity1.healthData.health = 0;
    if (entity2.healthData.values.health < 1e-4)
      entity2.healthData.health = 0;
    if (entity1.healthData.values.health === 0) {
      let killer = entity2;
      while (killer.relationsData.values.owner instanceof import_Object.default && killer.relationsData.values.owner.hash !== 0)
        killer = killer.relationsData.values.owner;
      if (killer instanceof LivingEntity)
        entity1.onDeath(killer);
      entity2.onKill(entity1);
    }
    if (entity2.healthData.values.health === 0) {
      let killer = entity1;
      while (killer.relationsData.values.owner instanceof import_Object.default && killer.relationsData.values.owner.hash !== 0)
        killer = killer.relationsData.values.owner;
      if (killer instanceof LivingEntity)
        entity2.onDeath(killer);
      entity1.onKill(entity2);
    }
  }
  onKill(entity) {
  }
  onDeath(killer) {
  }
  applyPhysics() {
    super.applyPhysics();
    if (this.healthData.values.health <= 0) {
      this.destroy(true);
      this.damagedEntities = [];
      return;
    }
    if (this.healthData.values.health < this.healthData.values.maxHealth) {
      this.healthData.health += this.regenPerTick;
      if (this.game.tick - this.lastDamageTick >= 750) {
        this.healthData.health += this.healthData.values.maxHealth / 250;
      }
    }
    if (this.healthData.values.health > this.healthData.values.maxHealth) {
      this.healthData.health = this.healthData.values.maxHealth;
    }
    this.damagedEntities = [];
  }
  tick(tick) {
    super.tick(tick);
    const collidedEntities = this.findCollisions();
    for (let i = 0; i < collidedEntities.length; ++i) {
      if (!(collidedEntities[i] instanceof LivingEntity))
        continue;
      if (collidedEntities[i].relationsData.values.team !== this.relationsData.values.team) {
        LivingEntity.applyDamage(collidedEntities[i], this);
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Live.js.map
