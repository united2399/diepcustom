var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Defender
});
var import_Barrel = __toModule(require("../Tank/Barrel"));
var import_AutoTurret = __toModule(require("../Tank/AutoTurret"));
var import_AbstractBoss = __toModule(require("./AbstractBoss"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_util = __toModule(require("../../util"));
const MountedTurretDefinition = __spreadProps(__spreadValues({}, import_AutoTurret.AutoTurretDefinition), {
  bullet: __spreadProps(__spreadValues({}, import_AutoTurret.AutoTurretDefinition.bullet), {
    speed: 2.3,
    damage: 0.75,
    health: 5.75,
    color: import_Enums.Color.Neutral
  })
});
const DefenderDefinition = {
  angle: 0,
  offset: 0,
  size: 120,
  width: 71.4,
  delay: 0,
  reload: 4,
  recoil: 2,
  isTrapezoid: false,
  trapezoidDirection: 0,
  addon: "trapLauncher",
  forceFire: true,
  bullet: {
    type: "trap",
    sizeRatio: 0.8,
    health: 12.5,
    damage: 4,
    speed: 5,
    scatterRate: 1,
    lifeLength: 8,
    absorbtionFactor: 1,
    color: import_Enums.Color.Neutral
  }
};
const DEFENDER_SIZE = 150;
class Defender extends import_AbstractBoss.default {
  constructor(game) {
    super(game);
    this.trappers = [];
    this.movementSpeed = 0.35;
    this.nameData.values.name = "Defender";
    this.styleData.values.color = import_Enums.Color.EnemyTriangle;
    this.relationsData.values.team = this.game.arena;
    this.physicsData.values.size = DEFENDER_SIZE * Math.SQRT1_2;
    this.ai.viewRange = 0;
    this.physicsData.values.sides = 3;
    for (let i = 0; i < 3; ++i) {
      this.trappers.push(new import_Barrel.default(this, __spreadProps(__spreadValues({}, DefenderDefinition), {
        angle: import_util.PI2 * (i / 3 - 1 / 6)
      })));
      const base = new import_AutoTurret.default(this, MountedTurretDefinition);
      base.influencedByOwnerInputs = true;
      const angle = base.ai.inputs.mouse.angle = import_util.PI2 * (i / 3);
      base.positionData.values.y = this.physicsData.values.size * Math.sin(angle) * 0.6;
      base.positionData.values.x = this.physicsData.values.size * Math.cos(angle) * 0.6;
      base.physicsData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
      const tickBase = base.tick;
      base.tick = (tick) => {
        base.positionData.y = this.physicsData.values.size * Math.sin(angle) * 0.6;
        base.positionData.x = this.physicsData.values.size * Math.cos(angle) * 0.6;
        tickBase.call(base, tick);
      };
    }
  }
  get sizeFactor() {
    return this.physicsData.values.size / Math.SQRT1_2 / DEFENDER_SIZE;
  }
  tick(tick) {
    super.tick(tick);
    if (this.ai.state !== import_AI.AIState.possessed) {
      this.positionData.angle += this.ai.passiveRotation * Math.PI * Math.SQRT1_2;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Defender.js.map
