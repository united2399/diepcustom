var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => AbstractBoss
});
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
var import_Live = __toModule(require("../Live"));
var import_TankBody = __toModule(require("../Tank/TankBody"));
var Target;
(function(Target2) {
  Target2[Target2["None"] = -1] = "None";
  Target2[Target2["BottomRight"] = 0] = "BottomRight";
  Target2[Target2["TopRight"] = 1] = "TopRight";
  Target2[Target2["TopLeft"] = 2] = "TopLeft";
  Target2[Target2["BottomLeft"] = 3] = "BottomLeft";
})(Target || (Target = {}));
class BossMovementControl {
  constructor(boss) {
    this.target = -1;
    this.boss = boss;
  }
  moveBoss() {
    const { x, y } = this.boss.positionData.values;
    if (this.target === -1) {
      if (x >= 0 && y >= 0) {
        this.target = 0;
      } else if (x <= 0 && y >= 0) {
        this.target = 3;
      } else if (x <= 0 && y <= 0) {
        this.target = 2;
      } else {
        this.target = 1;
      }
    }
    const target = this.target === 0 ? { x: 3 * this.boss.game.arena.arenaData.values.rightX / 4, y: 3 * this.boss.game.arena.arenaData.values.bottomY / 4 } : this.target === 3 ? { x: 3 * this.boss.game.arena.arenaData.values.leftX / 4, y: 3 * this.boss.game.arena.arenaData.values.bottomY / 4 } : this.target === 2 ? { x: 3 * this.boss.game.arena.arenaData.values.leftX / 4, y: 3 * this.boss.game.arena.arenaData.values.topY / 4 } : { x: 3 * this.boss.game.arena.arenaData.values.rightX / 4, y: 3 * this.boss.game.arena.arenaData.values.topY / 4 };
    target.x = target.x - x;
    target.y = target.y - y;
    const dist = target.x ** 2 + target.y ** 2;
    if (dist < 9e4)
      this.target = (this.target + 1) % 4;
    else {
      const angle = Math.atan2(target.y, target.x);
      this.boss.inputs.movement.x = Math.cos(angle);
      this.boss.inputs.movement.y = Math.sin(angle);
    }
  }
}
class AbstractBoss extends import_Live.default {
  constructor(game) {
    super(game);
    this.nameData = new import_FieldGroups.NameGroup(this);
    this.altName = null;
    this.reloadTime = 15;
    this.cameraEntity = this;
    this.hasBeenWelcomed = false;
    this.barrels = [];
    this.movementSpeed = 0.5;
    this.movementControl = new BossMovementControl(this);
    const { x, y } = this.game.arena.findSpawnLocation();
    this.positionData.values.x = x;
    this.positionData.values.y = y;
    this.relationsData.values.team = this.cameraEntity;
    this.physicsData.values.absorbtionFactor = 0.05;
    this.positionData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
    this.scoreReward = 3e4 * this.game.arena.shapeScoreRewardMultiplier;
    this.damagePerTick = 60;
    this.ai = new import_AI.AI(this);
    this.ai.viewRange = 2e3;
    this.ai["_findTargetInterval"] = 0;
    this.inputs = this.ai.inputs;
    this.styleData.values.color = import_Enums.Color.Fallen;
    this.physicsData.values.sides = 1;
    this.physicsData.values.size = 50 * Math.pow(1.01, 75 - 1);
    this.reloadTime = 15 * Math.pow(0.914, 7);
    this.healthData.values.health = this.healthData.values.maxHealth = 3e3;
  }
  get sizeFactor() {
    return this.physicsData.values.size / 50;
  }
  moveAroundMap() {
    this.movementControl.moveBoss();
  }
  onDeath(killer) {
    if (this.game.arena.boss === this)
      this.game.arena.boss = null;
    const killerName = killer instanceof import_TankBody.default && killer.nameData.values.name || "an unnamed tank";
    this.game.broadcast().u8(import_Enums.ClientBound.Notification).stringNT(`The ${this.altName || this.nameData.values.name} has been defeated by ${killerName}!`).u32(0).float(1e4).stringNT("").send();
  }
  tick(tick) {
    if (this.inputs !== this.ai.inputs)
      this.inputs = this.ai.inputs;
    this.ai.movementSpeed = this.movementSpeed;
    if (this.ai.state !== import_AI.AIState.possessed)
      this.moveAroundMap();
    else {
      const x = this.positionData.values.x, y = this.positionData.values.y;
      this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - y, this.ai.inputs.mouse.x - x);
    }
    this.accel.add({
      x: this.inputs.movement.x * this.movementSpeed,
      y: this.inputs.movement.y * this.movementSpeed
    });
    this.inputs.movement.set({
      x: 0,
      y: 0
    });
    this.regenPerTick = this.healthData.values.maxHealth / 25e3;
    if (!this.hasBeenWelcomed) {
      let message = "An unnamed boss has spawned!";
      if (this.nameData.values.name) {
        message = `The ${this.altName || this.nameData.values.name} has spawned!`;
      }
      this.game.broadcast().u8(import_Enums.ClientBound.Notification).stringNT(message).u32(0).float(1e4).stringNT("").send();
      this.hasBeenWelcomed = true;
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=AbstractBoss.js.map
