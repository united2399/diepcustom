var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Mothership
});
var import_Client = __toModule(require("../../Client"));
var import_config = __toModule(require("../../config"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Camera = __toModule(require("../../Native/Camera"));
var import_AI = __toModule(require("../AI"));
var import_TankBody = __toModule(require("../Tank/TankBody"));
var import_TeamEntity = __toModule(require("./TeamEntity"));
const POSSESSION_TIMER = import_config.tps * 60 * 5;
class Mothership extends import_TankBody.default {
  constructor(game) {
    const inputs = new import_AI.Inputs();
    const camera = new import_Camera.CameraEntity(game);
    camera.setLevel(140);
    super(game, camera, inputs);
    this.possessionStartTick = -1;
    this.relationsData.values.team = game.arena;
    this.styleData.values.color = import_Enums.Color.Neutral;
    this.ai = new import_AI.AI(this, true);
    this.ai.inputs = inputs;
    this.ai.viewRange = 2e3;
    this.positionData.values.x = 0;
    this.positionData.values.y = 0;
    this.setTank(import_Enums.Tank.Mothership);
    this.nameData.values.name = "Mothership";
    this.scoreReward = 0;
    camera.cameraData.values.player = this;
    for (let i = import_Enums.Stat.MovementSpeed; i < import_Enums.Stat.HealthRegen; ++i)
      camera.cameraData.values.statLevels.values[i] = 7;
    camera.cameraData.values.statLevels.values[import_Enums.Stat.HealthRegen] = 1;
    const def = this.definition = Object.assign({}, this.definition);
    def.maxHealth = 7008 - 418;
  }
  onDeath(killer) {
    var _a;
    const team = this.relationsData.values.team;
    const teamIsATeam = team instanceof import_TeamEntity.TeamEntity;
    const killerTeam = killer.relationsData.values.team;
    const killerTeamIsATeam = killerTeam instanceof import_TeamEntity.TeamEntity;
    this.game.broadcast().u8(import_Enums.ClientBound.Notification).stringNT(`${killerTeamIsATeam ? killerTeam.teamName : ((_a = killer.nameData) == null ? void 0 : _a.values.name) || "an unnamed tank"} has destroyed ${teamIsATeam ? team.teamName + "'s" : "a"} Mothership!`).u32(killerTeamIsATeam ? import_Enums.ColorsHexCode[killerTeam.teamData.values.teamColor] : 0).float(-1).stringNT("").send();
  }
  delete() {
    var _a;
    if ((_a = this.relationsData.values.team) == null ? void 0 : _a.teamData)
      this.relationsData.values.team.teamData.flags &= ~import_Enums.TeamFlags.hasMothership;
    this.ai.inputs.deleted = true;
    super.delete();
  }
  tick(tick) {
    if (!this.barrels.length)
      return super.tick(tick);
    this.inputs = this.ai.inputs;
    if (this.ai.state === import_AI.AIState.idle) {
      const angle = this.positionData.values.angle + this.ai.passiveRotation;
      const mag = Math.sqrt((this.inputs.mouse.x - this.positionData.values.x) ** 2 + (this.inputs.mouse.y - this.positionData.values.y) ** 2);
      this.inputs.mouse.set({
        x: this.positionData.values.x + Math.cos(angle) * mag,
        y: this.positionData.values.y + Math.sin(angle) * mag
      });
    } else if (this.ai.state === import_AI.AIState.possessed && this.possessionStartTick === -1) {
      this.possessionStartTick = tick;
    }
    if (this.possessionStartTick !== -1 && this.ai.state !== import_AI.AIState.possessed) {
      this.possessionStartTick = -1;
    }
    if (this.possessionStartTick !== -1) {
      if (this.possessionStartTick !== -1 && this.ai.state !== import_AI.AIState.possessed) {
        this.possessionStartTick = -1;
      } else if (this.inputs instanceof import_Client.ClientInputs) {
        if (tick - this.possessionStartTick >= POSSESSION_TIMER) {
          this.inputs.deleted = true;
        } else if (tick - this.possessionStartTick === Math.floor(POSSESSION_TIMER - 10 * import_config.tps)) {
          this.inputs.client.notify("You only have 10 seconds left in control of the Mothership", import_Enums.ColorsHexCode[this.styleData.values.color], 5e3, "");
        }
      }
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Mothership.js.map
