var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => TeamBase
});
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Live = __toModule(require("../Live"));
class TeamBase extends import_Live.default {
  constructor(game, team, x, y, width, height, painful = true) {
    super(game);
    this.relationsData.values.team = team;
    this.positionData.values.x = x;
    this.positionData.values.y = y;
    this.physicsData.values.width = width;
    this.physicsData.values.size = height;
    this.physicsData.values.sides = 2;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.showsOnMap | import_Enums.PhysicsFlags.noOwnTeamCollision | import_Enums.PhysicsFlags.isBase;
    this.physicsData.values.pushFactor = 2;
    this.damagePerTick = 5;
    if (!painful) {
      this.physicsData.values.pushFactor = 0;
      this.damagePerTick = 0;
    }
    this.damageReduction = 0;
    this.physicsData.values.absorbtionFactor = 0;
    this.styleData.values.opacity = 0.1;
    this.styleData.values.borderWidth = 0;
    this.styleData.values.color = team.teamData.teamColor;
    this.styleData.values.flags |= import_Enums.StyleFlags._minimap | import_Enums.StyleFlags.hasNoDmgIndicator;
    this.healthData.flags |= import_Enums.HealthFlags.hiddenHealthbar;
    this.healthData.health = this.healthData.values.maxHealth = 703743;
  }
  tick(tick) {
    this.lastDamageTick = tick;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=TeamBase.js.map
