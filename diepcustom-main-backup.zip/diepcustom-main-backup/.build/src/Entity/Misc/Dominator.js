var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Dominator
});
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Camera = __toModule(require("../../Native/Camera"));
var import_AI = __toModule(require("../AI"));
var import_Bullet = __toModule(require("../Tank/Projectile/Bullet"));
var import_TankBody = __toModule(require("../Tank/TankBody"));
const _Dominator = class extends import_TankBody.default {
  constructor(arena, base, pTankId = null) {
    let tankId;
    if (pTankId === null) {
      const r = Math.random() * 3;
      if (r < 1)
        tankId = import_Enums.Tank.DominatorD;
      else if (r < 2)
        tankId = import_Enums.Tank.DominatorG;
      else
        tankId = import_Enums.Tank.DominatorT;
    } else
      tankId = pTankId;
    const inputs = new import_AI.Inputs();
    const camera = new import_Camera.CameraEntity(arena.game);
    camera.setLevel(75);
    camera.sizeFactor = _Dominator.SIZE / 50;
    super(arena.game, camera, inputs);
    this.relationsData.values.team = arena;
    this.physicsData.values.size = _Dominator.SIZE;
    this.styleData.values.color = import_Enums.Color.Neutral;
    this.ai = new import_AI.AI(this, true);
    this.ai.inputs = inputs;
    this.ai.movementSpeed = 0;
    this.ai.viewRange = 2e3;
    this.ai.doAimPrediction = true;
    this.setTank(tankId);
    const def = this.definition = Object.assign({}, this.definition);
    def.speed = camera.cameraData.values.movementSpeed = 0;
    this.nameData.values.name = "Dominator";
    this.nameData.values.flags |= import_Enums.NameFlags.hiddenName;
    this.physicsData.values.absorbtionFactor = 0;
    this.positionData.values.x = base.positionData.values.x;
    this.positionData.values.y = base.positionData.values.y;
    this.scoreReward = 0;
    camera.cameraData.values.player = this;
    this.base = base;
  }
  onDeath(killer) {
    var _a;
    if (this.relationsData.values.team === this.game.arena && killer instanceof import_TankBody.default) {
      this.relationsData.team = killer.relationsData.values.team || this.game.arena;
      this.styleData.color = ((_a = this.relationsData.team.teamData) == null ? void 0 : _a.teamColor) || killer.styleData.values.color;
    } else {
      this.relationsData.team = this.game.arena;
      this.styleData.color = this.game.arena.teamData.teamColor;
    }
    this.base.styleData.color = this.styleData.values.color;
    this.base.relationsData.team = this.relationsData.values.team;
    ;
    this.healthData.health = this.healthData.values.maxHealth;
    for (let i = 1; i <= this.game.entities.lastId; ++i) {
      const entity = this.game.entities.inner[i];
      if (entity instanceof import_Bullet.default && entity.relationsData.values.owner === this)
        entity.destroy();
    }
    if (this.ai.state === import_AI.AIState.possessed) {
      this.ai.inputs.deleted = true;
      this.ai.inputs = this.inputs = new import_AI.Inputs();
      this.ai.state = import_AI.AIState.idle;
    }
  }
  tick(tick) {
    if (!this.barrels.length)
      return super.tick(tick);
    this.ai.aimSpeed = this.barrels[0].bulletAccel;
    this.inputs = this.ai.inputs;
    if (this.ai.state === import_AI.AIState.idle) {
      const angle = this.positionData.values.angle + this.ai.passiveRotation;
      const mag = Math.sqrt((this.inputs.mouse.x - this.positionData.values.x) ** 2 + (this.inputs.mouse.y - this.positionData.values.y) ** 2);
      this.inputs.mouse.set({
        x: this.positionData.values.x + Math.cos(angle) * mag,
        y: this.positionData.values.y + Math.sin(angle) * mag
      });
    }
    super.tick(tick);
  }
};
let Dominator = _Dominator;
Dominator.SIZE = 160;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Dominator.js.map
