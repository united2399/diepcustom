var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Egg
});
var import_Square = __toModule(require("./Square"));
var import_AbstractShape = __toModule(require("./AbstractShape"));
var import_Enums = __toModule(require("../../Const/Enums"));
class Egg extends import_AbstractShape.default {
  constructor(arena, game, shiny = Math.random() < 1e-6) {
    super(game);
    this.timer = 0;
    this.evolutionTime = (Math.random() * 50 + 30) * 30;
    this.doEvolve = true;
    this.arena = arena;
    this.game = arena.game;
    if (Math.random() > 0.65)
      this.doEvolve = false;
    this.nameData.values.name = "Egg";
    this.healthData.values.health = this.healthData.values.maxHealth = 1e-4 * 100;
    this.physicsData.values.size = 23 + (Math.random() * 4 - 2);
    this.physicsData.values.pushFactor = 0;
    this.physicsData.values.sides = 1;
    this.styleData.values.color = shiny ? import_Enums.Color.Shiny : import_Enums.Color.Egg;
    this.damagePerTick = 2.46;
    if (Math.random() > 0.5)
      this.scoreReward = 2;
    else
      this.scoreReward = 3;
    this.isShiny = shiny;
    if (shiny) {
      this.scoreReward = 1e5;
      this.healthData.values.health = this.healthData.values.maxHealth *= 1;
    }
  }
  tick(tick) {
    this.timer += 1;
    if (this.timer > this.evolutionTime && this.doEvolve) {
      let shape;
      shape = new import_Square.default(this.arena, this.game, true);
      shape.positionData.values.x = this.positionData.x;
      shape.positionData.values.y = this.positionData.y;
      shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;
      shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;
      this.delete();
    }
    super.tick(tick);
  }
}
Egg.BASE_ORBIT = import_AbstractShape.default.BASE_ORBIT * 2.5;
Egg.BASE_VELOCITY = import_AbstractShape.default.BASE_VELOCITY * 2;
Egg.BASE_ROTATION = import_AbstractShape.default.BASE_ROTATION * 0.5;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Egg.js.map
