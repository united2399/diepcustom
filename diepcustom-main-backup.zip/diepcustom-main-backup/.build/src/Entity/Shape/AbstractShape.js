var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => AbstractShape
});
var import_Live = __toModule(require("../Live"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
var import_AI = __toModule(require("../AI"));
var import_util = __toModule(require("../../util"));
const TURN_TIMEOUT = 300;
class AbstractShape extends import_Live.default {
  constructor(game) {
    super(game);
    this.nameData = new import_FieldGroups.NameGroup(this);
    this.isShiny = false;
    this.doIdleRotate = true;
    this.orbitRate = (Math.random() < 0.5 ? -1 : 1) * this.constructor.BASE_ORBIT;
    this.rotationRate = (Math.random() < 0.5 ? -1 : 1) * this.constructor.BASE_ROTATION;
    this.shapeVelocity = this.constructor.BASE_VELOCITY;
    this.isTurning = 0;
    this.targetTurningAngle = 0;
    this.relationsData.values.team = game.arena;
    this.nameData.values.flags = import_Enums.NameFlags.hiddenName;
    this.positionData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
    this.orbitAngle = this.positionData.values.angle = Math.random() * import_util.PI2;
  }
  turnTo(angle) {
    if ((0, import_util.normalizeAngle)(this.orbitAngle - angle) < 0.2)
      return;
    this.targetTurningAngle = angle;
    this.isTurning = TURN_TIMEOUT;
  }
  tick(tick) {
    if (!this.doIdleRotate) {
      return super.tick(tick);
    }
    const y = this.positionData.values.y;
    const x = this.positionData.values.x;
    if (this.isTurning === 0) {
      if (x > this.game.arena.arenaData.values.rightX - 400 || x < this.game.arena.arenaData.values.leftX + 400 || y < this.game.arena.arenaData.values.topY + 400 || y > this.game.arena.arenaData.values.bottomY - 400) {
        this.turnTo(Math.PI + Math.atan2(y, x));
      } else if (x > this.game.arena.arenaData.values.rightX - 500) {
        this.turnTo(Math.sign(this.orbitRate) * Math.PI / 2);
      } else if (x < this.game.arena.arenaData.values.leftX + 500) {
        this.turnTo(-1 * Math.sign(this.orbitRate) * Math.PI / 2);
      } else if (y < this.game.arena.arenaData.values.topY + 500) {
        this.turnTo(this.orbitRate > 0 ? 0 : Math.PI);
      } else if (y > this.game.arena.arenaData.values.bottomY - 500) {
        this.turnTo(this.orbitRate > 0 ? Math.PI : 0);
      }
    }
    this.positionData.angle += this.rotationRate;
    this.orbitAngle += this.orbitRate + (this.isTurning === TURN_TIMEOUT ? this.orbitRate * 10 : 0);
    if (this.isTurning === TURN_TIMEOUT && ((this.orbitAngle - this.targetTurningAngle) % import_util.PI2 + import_util.PI2) % import_util.PI2 < 0.2) {
      this.isTurning -= 1;
    } else if (this.isTurning !== TURN_TIMEOUT && this.isTurning !== 0)
      this.isTurning -= 1;
    this.maintainVelocity(this.orbitAngle, this.shapeVelocity);
    super.tick(tick);
  }
}
AbstractShape.BASE_ROTATION = import_AI.AI.PASSIVE_ROTATION;
AbstractShape.BASE_ORBIT = 5e-3;
AbstractShape.BASE_VELOCITY = 1;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=AbstractShape.js.map
