var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Pentagon
});
var import_AbstractShape = __toModule(require("./AbstractShape"));
var import_Enums = __toModule(require("../../Const/Enums"));
class Pentagon extends import_AbstractShape.default {
  constructor(game, isAlpha = false, isInNest = false, shiny = Math.random() < 1e-6 && !isAlpha) {
    super(game);
    this.isBeta = false;
    if (Math.random() <= 0.2 && !isAlpha && isInNest)
      this.isBeta = true;
    if (this.isBeta)
      this.nameData.values.name = "Beta Pentagon";
    else
      this.nameData.values.name = isAlpha ? "Alpha Pentagon" : "Pentagon";
    if (this.isBeta)
      this.healthData.values.health = this.healthData.values.maxHealth = 3e3;
    else
      this.healthData.values.health = this.healthData.values.maxHealth = isAlpha ? 12e3 : 100;
    if (this.isBeta)
      this.physicsData.values.size = 141;
    else
      this.physicsData.values.size = (isAlpha ? 350 : 75) * Math.SQRT1_2;
    this.physicsData.values.sides = 5;
    this.styleData.values.color = shiny ? import_Enums.Color.Shiny : import_Enums.Color.EnemyPentagon;
    if (this.isBeta)
      this.physicsData.values.absorbtionFactor = 0.09;
    else
      this.physicsData.values.absorbtionFactor = isAlpha ? 0.03 : 0.5;
    this.physicsData.values.pushFactor = 11;
    this.isAlpha = isAlpha;
    this.isShiny = shiny;
    if (this.isBeta)
      this.damagePerTick = 17;
    else
      this.damagePerTick = isAlpha ? 32 : 12;
    if (this.isBeta)
      this.scoreReward = 3e3;
    else
      this.scoreReward = isAlpha ? Math.random() * 3e3 + 9e3 : 130;
    if (shiny) {
      this.scoreReward *= 100;
      this.healthData.values.health = this.healthData.values.maxHealth *= 10;
    }
  }
}
Pentagon.BASE_ROTATION = import_AbstractShape.default.BASE_ROTATION / 2;
Pentagon.BASE_ORBIT = import_AbstractShape.default.BASE_ORBIT / 2;
Pentagon.BASE_VELOCITY = import_AbstractShape.default.BASE_VELOCITY / 2;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Pentagon.js.map
