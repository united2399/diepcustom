var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
__export(exports, {
  AccessLevel: () => AccessLevel,
  apiLocation: () => apiLocation,
  bossSpawningInterval: () => bossSpawningInterval,
  buildHash: () => buildHash,
  clientLocation: () => clientLocation,
  connectionsPerIp: () => connectionsPerIp,
  defaultAccessLevel: () => defaultAccessLevel,
  devPasswordHash: () => devPasswordHash,
  doVerboseLogs: () => doVerboseLogs,
  enableApi: () => enableApi,
  enableClient: () => enableClient,
  enableCommands: () => enableCommands,
  host: () => host,
  magicNum: () => magicNum,
  maxPlayerLevel: () => maxPlayerLevel,
  mode: () => mode,
  mspt: () => mspt,
  serverPort: () => serverPort,
  spatialHashingCellSize: () => spatialHashingCellSize,
  tps: () => tps,
  unbannableLevelMinimum: () => unbannableLevelMinimum,
  writtenBufferChunkSize: () => writtenBufferChunkSize,
  wssMaxMessageSize: () => wssMaxMessageSize
});
const buildHash = "6f59094d60f98fafc14371671d3ff31ef4d75d9e";
const serverPort = parseInt(process.env.PORT || "8080");
const mspt = 40;
const tps = 1e3 / mspt;
const connectionsPerIp = Infinity;
const wssMaxMessageSize = 4096;
const writtenBufferChunkSize = Buffer.poolSize || 2048;
const host = process.env.SERVER_INFO || (process.env.NODE_ENV === "development" ? "localhost" : "");
const mode = process.env.NODE_ENV || "development";
const enableApi = true;
const apiLocation = "api";
const enableCommands = true;
const enableClient = true;
const clientLocation = "./client";
const magicNum = function magicNum2(build) {
  let char;
  for (var i = 0, seed = 1, res = 0, timer = 0; i < 40; i++) {
    char = parseInt(build[i], 16);
    res ^= char << ((seed & 1) << 2) << (timer << 3);
    timer = timer + 1 & 3;
    seed ^= +!timer;
  }
  ;
  return res >>> 0;
}(buildHash);
const spatialHashingCellSize = 7;
const bossSpawningInterval = 45 * 60 * tps;
const devPasswordHash = process.env.DEV_PASSWORD_HASH;
const doVerboseLogs = false;
var AccessLevel;
(function(AccessLevel2) {
  AccessLevel2[AccessLevel2["FullAccess"] = 3] = "FullAccess";
  AccessLevel2[AccessLevel2["BetaAccess"] = 2] = "BetaAccess";
  AccessLevel2[AccessLevel2["kReserved"] = 1] = "kReserved";
  AccessLevel2[AccessLevel2["PublicAccess"] = 0] = "PublicAccess";
  AccessLevel2[AccessLevel2["NoAccess"] = -1] = "NoAccess";
})(AccessLevel || (AccessLevel = {}));
const unbannableLevelMinimum = 3;
const defaultAccessLevel = 2;
const maxPlayerLevel = 45;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AccessLevel,
  apiLocation,
  bossSpawningInterval,
  buildHash,
  clientLocation,
  connectionsPerIp,
  defaultAccessLevel,
  devPasswordHash,
  doVerboseLogs,
  enableApi,
  enableClient,
  enableCommands,
  host,
  magicNum,
  maxPlayerLevel,
  mode,
  mspt,
  serverPort,
  spatialHashingCellSize,
  tps,
  unbannableLevelMinimum,
  writtenBufferChunkSize,
  wssMaxMessageSize
});
//# sourceMappingURL=config.js.map
