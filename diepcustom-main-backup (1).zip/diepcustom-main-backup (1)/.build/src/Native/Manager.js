var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => EntityManager
});
var config = __toModule(require("../config"));
var import_Object = __toModule(require("../Entity/Object"));
var import_SpatialHashing = __toModule(require("../Physics/SpatialHashing"));
var import_QuadTree = __toModule(require("../Physics/QuadTree"));
var import_Camera = __toModule(require("./Camera"));
var import_Entity = __toModule(require("./Entity"));
var import_util = __toModule(require("../util"));
class EntityManager {
  constructor(game) {
    this.zIndex = 0;
    this.cameras = [];
    this.otherEntities = [];
    this.inner = Array(16384);
    this.AIs = [];
    this.hashTable = new Uint8Array(16384);
    this.lastId = -1;
    this.game = game;
    this.collisionManager = config.spatialHashingCellSize ? new import_SpatialHashing.default(config.spatialHashingCellSize) : new import_QuadTree.default(0, 0);
  }
  add(entity) {
    const lastId = this.lastId + 1;
    for (let id = 0; id <= lastId; ++id) {
      if (this.inner[id])
        continue;
      entity.id = id;
      entity.hash = entity.preservedHash = this.hashTable[id] += 1;
      this.inner[id] = entity;
      if (this.collisionManager && entity instanceof import_Object.default) {
      } else if (entity instanceof import_Camera.CameraEntity)
        this.cameras.push(id);
      else
        this.otherEntities.push(id);
      if (this.lastId < id)
        this.lastId = entity.id;
      return entity;
    }
    throw new Error("OOEI: Out Of Entity IDs");
  }
  delete(id) {
    const entity = this.inner[id];
    if (!entity)
      throw new RangeError("Deleting entity that isn't in the game?");
    entity.hash = 0;
    if (this.collisionManager && entity instanceof import_Object.default) {
    } else if (entity instanceof import_Camera.CameraEntity)
      (0, import_util.removeFast)(this.cameras, this.cameras.indexOf(id));
    else
      (0, import_util.removeFast)(this.otherEntities, this.otherEntities.indexOf(id));
    this.inner[id] = null;
  }
  clear() {
    this.lastId = -1;
    this.collisionManager.reset(0, 0);
    this.hashTable.fill(0);
    this.AIs.length = 0;
    this.otherEntities.length = 0;
    this.cameras.length = 0;
    for (let i = 0; i < this.inner.length; ++i) {
      const entity = this.inner[i];
      if (entity) {
        entity.hash = 0;
        this.inner[i] = null;
      }
    }
  }
  tick(tick) {
    this.collisionManager.reset(this.game.arena.arenaData.values.rightX, this.game.arena.arenaData.values.bottomY);
    while (!this.inner[this.lastId] && this.lastId >= 0) {
      this.lastId -= 1;
    }
    scanner:
      for (let id = 0; id <= this.lastId; ++id) {
        const entity = this.inner[id];
        if (!import_Entity.Entity.exists(entity))
          continue;
        if (entity instanceof import_Object.default && !entity.isChild) {
          this.collisionManager.insertEntity(entity);
          entity.isViewed = true;
        }
      }
    for (let id = 0; id <= this.lastId; ++id) {
      const entity = this.inner[id];
      if (entity && entity instanceof import_Object.default && entity.isPhysical) {
        entity.applyPhysics();
      }
    }
    for (let id = 0; id <= this.lastId; ++id) {
      const entity = this.inner[id];
      if (!import_Entity.Entity.exists(entity))
        continue;
      if (!(entity instanceof import_Camera.CameraEntity)) {
        if (!(entity instanceof import_Object.default) || !entity.isChild)
          entity.tick(tick);
      }
    }
    for (let i = this.AIs.length; --i >= 0; ) {
      if (!import_Entity.Entity.exists(this.AIs[i].owner)) {
        (0, import_util.removeFast)(this.game.entities.AIs, i);
        continue;
      }
      this.AIs[i].tick(tick);
    }
    for (let i = 0; i < this.cameras.length; ++i) {
      this.inner[this.cameras[i]].tick(tick);
    }
    for (let id = 0; id <= this.lastId; ++id) {
      const entity = this.inner[id];
      if (entity) {
        entity.wipeState();
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Manager.js.map
