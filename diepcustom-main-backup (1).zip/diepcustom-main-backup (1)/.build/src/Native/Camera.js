var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  CameraEntity: () => CameraEntity,
  default: () => ClientCamera
});
var import_TankBody = __toModule(require("../Entity/Tank/TankBody"));
var import_Object = __toModule(require("../Entity/Object"));
var import_Entity = __toModule(require("./Entity"));
var import_FieldGroups = __toModule(require("./FieldGroups"));
var import_Enums = __toModule(require("../Const/Enums"));
var import_TankDefinitions = __toModule(require("../Const/TankDefinitions"));
var import_util = __toModule(require("../util"));
var import_UpcreateCompiler = __toModule(require("./UpcreateCompiler"));
var import_config = __toModule(require("../config"));
class CameraEntity extends import_Entity.Entity {
  constructor() {
    super(...arguments);
    this.cameraData = new import_FieldGroups.CameraGroup(this);
    this.sizeFactor = 1;
  }
  setLevel(level) {
    var _a;
    const previousLevel = this.cameraData.values.level;
    this.cameraData.level = level;
    this.sizeFactor = Math.pow(1.01, level - 1);
    this.cameraData.levelbarMax = level < import_config.maxPlayerLevel ? 1 : 0;
    if (level <= import_config.maxPlayerLevel) {
      this.cameraData.score = (0, import_Enums.levelToScore)(level);
      const player = this.cameraData.values.player;
      if (import_Entity.Entity.exists(player) && player instanceof import_TankBody.default) {
        player.scoreData.score = this.cameraData.values.score;
        player.scoreReward = this.cameraData.values.score;
      }
    }
    const statIncrease = ClientCamera.calculateStatCount(level) - ClientCamera.calculateStatCount(previousLevel);
    this.cameraData.statsAvailable += statIncrease;
    this.setFieldFactor(((_a = (0, import_TankDefinitions.getTankById)(this.cameraData.values.tank)) == null ? void 0 : _a.fieldFactor) || 1);
  }
  setFieldFactor(fieldFactor) {
    this.cameraData.FOV = 0.55 * fieldFactor / Math.pow(1.01, (this.cameraData.values.level - 1) / 2);
  }
  tick(tick) {
    if (import_Entity.Entity.exists(this.cameraData.values.player)) {
      const focus = this.cameraData.values.player;
      if (!(this.cameraData.values.flags & import_Enums.CameraFlags.usesCameraCoords) && focus instanceof import_Object.default) {
        this.cameraData.cameraX = focus.rootParent.positionData.values.x;
        this.cameraData.cameraY = focus.rootParent.positionData.values.y;
      }
      if (this.cameraData.values.player instanceof import_TankBody.default) {
        const player = this.cameraData.values.player;
        const score = this.cameraData.values.score;
        let newLevel = this.cameraData.values.level;
        while (newLevel < import_Enums.levelToScoreTable.length && score - (0, import_Enums.levelToScore)(newLevel + 1) >= 0)
          newLevel += 1;
        if (newLevel !== this.cameraData.values.level) {
          this.setLevel(newLevel);
          this.cameraData.score = score;
        }
        if (newLevel < import_Enums.levelToScoreTable.length) {
          const levelScore = (0, import_Enums.levelToScore)(this.cameraData.values.level);
          this.cameraData.levelbarMax = (0, import_Enums.levelToScore)(this.cameraData.values.level + 1) - levelScore;
          this.cameraData.levelbarProgress = score - levelScore;
        }
        this.cameraData.movementSpeed = player.definition.speed * 2.55 * Math.pow(1.07, this.cameraData.values.statLevels.values[import_Enums.Stat.MovementSpeed]) / Math.pow(1.015, this.cameraData.values.level - 1);
      }
    } else {
      this.cameraData.flags |= import_Enums.CameraFlags.usesCameraCoords;
    }
  }
}
class ClientCamera extends CameraEntity {
  constructor(game, client) {
    super(game);
    this.view = [];
    this.relationsData = new import_FieldGroups.RelationsGroup(this);
    this.spectatee = null;
    this.client = client;
    this.cameraData.values.respawnLevel = this.cameraData.values.level = this.cameraData.values.score = 1;
    this.cameraData.values.FOV = 0.35;
    this.relationsData.values.team = this;
  }
  static calculateStatCount(level) {
    if (level <= 0)
      return 0;
    if (level <= 28)
      return level - 1;
    return Math.floor(level / 3) + 18;
  }
  addToView(entity) {
    let c = this.view.find((r) => r.id === entity.id);
    if (c) {
      console.log(c.toString(), entity.toString(), c === entity);
    }
    this.view.push(entity);
  }
  removeFromView(id) {
    const index = this.view.findIndex((r) => r.id === id);
    if (index === -1)
      return;
    (0, import_util.removeFast)(this.view, index);
  }
  updateView(tick) {
    const w = this.client.write().u8(import_Enums.ClientBound.Update).vu(tick);
    const deletes = [];
    const updates = [];
    const creations = [];
    const fov = this.cameraData.values.FOV;
    const width = 1920 / fov / 1.5;
    const height = 1080 / fov / 1.5;
    const entitiesNearRange = this.game.entities.collisionManager.retrieve(this.cameraData.values.cameraX, this.cameraData.values.cameraY, width, height);
    const entitiesInRange = [];
    const l = this.cameraData.values.cameraX - width;
    const r = this.cameraData.values.cameraX + width;
    const t = this.cameraData.values.cameraY - height;
    const b = this.cameraData.values.cameraY + height;
    for (let i = 0; i < entitiesNearRange.length; ++i) {
      const entity = entitiesNearRange[i];
      const width2 = entity.physicsData.values.sides === 2 ? entity.physicsData.values.size / 2 : entity.physicsData.values.size;
      const size = entity.physicsData.values.sides === 2 ? entity.physicsData.values.width / 2 : entity.physicsData.values.size;
      if (entity.positionData.values.x - width2 < r && entity.positionData.values.y + size > t && entity.positionData.values.x + width2 > l && entity.positionData.values.y - size < b) {
        if (entity !== this.cameraData.values.player && !(entity.styleData.values.opacity === 0 && !entity.deletionAnimation)) {
          entitiesInRange.push(entity);
        }
      }
    }
    for (let id = 0; id <= this.game.entities.lastId; ++id) {
      const entity = this.game.entities.inner[id];
      if (entity instanceof import_Object.default && !entitiesInRange.includes(entity) && entity.physicsData.values.flags & import_Enums.PhysicsFlags.showsOnMap)
        entitiesInRange.push(entity);
    }
    if (import_Entity.Entity.exists(this.cameraData.values.player) && this.cameraData.values.player instanceof import_Object.default)
      entitiesInRange.push(this.cameraData.values.player);
    for (let i = 0; i < this.view.length; ++i) {
      const entity = this.view[i];
      if (entity instanceof import_Object.default) {
        if (!entitiesInRange.includes(entity.rootParent)) {
          deletes.push({ id: entity.id, hash: entity.preservedHash });
          continue;
        }
      }
      if (entity.hash === 0) {
        deletes.push({ id: entity.id, hash: entity.preservedHash });
      } else if (entity.entityState & import_Entity.EntityStateFlags.needsCreate) {
        if (entity.entityState & import_Entity.EntityStateFlags.needsDelete)
          deletes.push({ hash: entity.hash, id: entity.id, noDelete: true });
        creations.push(entity);
      } else if (entity.entityState & import_Entity.EntityStateFlags.needsUpdate) {
        updates.push(entity);
      }
    }
    w.vu(deletes.length);
    for (let i = 0; i < deletes.length; ++i) {
      w.entid(deletes[i]);
      if (!deletes[i].noDelete)
        this.removeFromView(deletes[i].id);
    }
    if (this.view.length === 0) {
      creations.push(this.game.arena, this);
      this.view.push(this.game.arena, this);
    }
    const entities = this.game.entities;
    for (const id of this.game.entities.otherEntities) {
      if (this.view.findIndex((r2) => r2.id === id) === -1) {
        const entity = entities.inner[id];
        if (!entity)
          continue;
        if (entity instanceof CameraEntity)
          continue;
        creations.push(entity);
        this.addToView(entity);
      }
    }
    for (const entity of entitiesInRange) {
      if (this.view.indexOf(entity) === -1) {
        creations.push(entity);
        this.addToView(entity);
        if (entity instanceof import_Object.default) {
          if (entity.children.length && !entity.isChild) {
            this.view.push.apply(this.view, entity.children);
            creations.push.apply(creations, entity.children);
          }
        }
      } else {
        if (!import_Entity.Entity.exists(entity))
          throw new Error("wtf");
        if (entity.children.length && !entity.isChild) {
          for (let child of entity.children) {
            if (this.view.findIndex((r2) => r2.id === child.id) === -1) {
              this.view.push.apply(this.view, entity.children);
              creations.push.apply(creations, entity.children);
            }
          }
        }
      }
    }
    w.vu(creations.length + updates.length);
    for (let i = 0; i < updates.length; ++i) {
      this.compileUpdate(w, updates[i]);
    }
    for (let i = 0; i < creations.length; ++i) {
      this.compileCreation(w, creations[i]);
    }
    w.send();
  }
  compileCreation(w, entity) {
    (0, import_UpcreateCompiler.compileCreation)(this, w, entity);
  }
  compileUpdate(w, entity) {
    (0, import_UpcreateCompiler.compileUpdate)(this, w, entity);
  }
  tick(tick) {
    super.tick(tick);
    if (!import_Entity.Entity.exists(this.cameraData.values.player) || !(this.cameraData.values.player instanceof import_TankBody.default)) {
      if (import_Entity.Entity.exists(this.spectatee)) {
        const pos = this.spectatee.rootParent.positionData.values;
        this.cameraData.cameraX = pos.x;
        this.cameraData.cameraY = pos.y;
        this.cameraData.flags |= import_Enums.CameraFlags.usesCameraCoords;
      }
    }
    this.updateView(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CameraEntity
});
//# sourceMappingURL=Camera.js.map
