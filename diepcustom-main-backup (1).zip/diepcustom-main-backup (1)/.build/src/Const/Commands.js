var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  CommandID: () => CommandID,
  commandCallbacks: () => commandCallbacks,
  commandDefinitions: () => commandDefinitions,
  executeCommand: () => executeCommand
});
var import_config = __toModule(require("../config"));
var import_AbstractBoss = __toModule(require("../Entity/Boss/AbstractBoss"));
var import_Defender = __toModule(require("../Entity/Boss/Defender"));
var import_FallenBooster = __toModule(require("../Entity/Boss/FallenBooster"));
var import_FallenOverlord = __toModule(require("../Entity/Boss/FallenOverlord"));
var import_Guardian = __toModule(require("../Entity/Boss/Guardian"));
var import_Summoner = __toModule(require("../Entity/Boss/Summoner"));
var import_Live = __toModule(require("../Entity/Live"));
var import_ArenaCloser = __toModule(require("../Entity/Misc/ArenaCloser"));
var import_FallenAC = __toModule(require("../Entity/Misc/Boss/FallenAC"));
var import_FallenSpike = __toModule(require("../Entity/Misc/Boss/FallenSpike"));
var import_Dominator = __toModule(require("../Entity/Misc/Dominator"));
var import_Object = __toModule(require("../Entity/Object"));
var import_AbstractShape = __toModule(require("../Entity/Shape/AbstractShape"));
var import_Crasher = __toModule(require("../Entity/Shape/Crasher"));
var import_Pentagon = __toModule(require("../Entity/Shape/Pentagon"));
var import_Square = __toModule(require("../Entity/Shape/Square"));
var import_Triangle = __toModule(require("../Entity/Shape/Triangle"));
var import_AutoTurret = __toModule(require("../Entity/Tank/AutoTurret"));
var import_Bullet = __toModule(require("../Entity/Tank/Projectile/Bullet"));
var import_TankBody = __toModule(require("../Entity/Tank/TankBody"));
var import_Entity = __toModule(require("../Native/Entity"));
var import_util = __toModule(require("../util"));
var import_Enums = __toModule(require("./Enums"));
var import_TankDefinitions = __toModule(require("./TankDefinitions"));
const RELATIVE_POS_REGEX = new RegExp(/~(-?\d+)?/);
var CommandID;
(function(CommandID2) {
  CommandID2["gameSetTank"] = "game_set_tank";
  CommandID2["gameSetLevel"] = "game_set_level";
  CommandID2["gameSetScore"] = "game_set_score";
  CommandID2["gameSetStat"] = "game_set_stat";
  CommandID2["gameSetStatMax"] = "game_set_stat_max";
  CommandID2["gameAddUpgradePoints"] = "game_add_upgrade_points";
  CommandID2["gameTeleport"] = "game_teleport";
  CommandID2["gameClaim"] = "game_claim";
  CommandID2["gameGodmode"] = "game_godmode";
  CommandID2["adminSummon"] = "admin_summon";
  CommandID2["adminKillAll"] = "admin_kill_all";
  CommandID2["adminKillEntity"] = "admin_kill_entity";
  CommandID2["adminCloseArena"] = "admin_close_arena";
})(CommandID || (CommandID = {}));
const commandDefinitions = {
  game_set_tank: {
    id: CommandID.gameSetTank,
    usage: "[tank]",
    description: "Changes your tank to the given class",
    permissionLevel: import_config.AccessLevel.BetaAccess,
    isCheat: true
  },
  game_set_level: {
    id: CommandID.gameSetLevel,
    usage: "[level]",
    description: "Changes your level to the given whole number",
    permissionLevel: import_config.AccessLevel.BetaAccess,
    isCheat: true
  },
  game_set_score: {
    id: CommandID.gameSetScore,
    usage: "[score]",
    description: "Changes your score to the given whole number",
    permissionLevel: import_config.AccessLevel.BetaAccess,
    isCheat: true
  },
  game_set_stat: {
    id: CommandID.gameSetStat,
    usage: "[stat num] [points]",
    description: "Set the value of one of your statuses. Values can be greater than the capacity. [stat num] is equivalent to the number that appears in the UI",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: true
  },
  game_set_stat_max: {
    id: CommandID.gameSetStatMax,
    usage: "[stat num] [max]",
    description: "Set the max value of one of your statuses. [stat num] is equivalent to the number that appears in the UI",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: true
  },
  game_add_upgrade_points: {
    id: CommandID.gameAddUpgradePoints,
    usage: "[points]",
    description: "Add upgrade points",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: true
  },
  game_teleport: {
    id: CommandID.gameTeleport,
    usage: "[x] [y]",
    description: "Teleports you to the given position",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: true
  },
  game_claim: {
    id: CommandID.gameClaim,
    usage: "[entityName]",
    description: "Attempts claiming an entity of the given type",
    permissionLevel: import_config.AccessLevel.BetaAccess,
    isCheat: false
  },
  game_godmode: {
    id: CommandID.gameGodmode,
    usage: "[?value]",
    description: "Set the godemode. Toggles if [value] is not specified",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: true
  },
  admin_summon: {
    id: CommandID.adminSummon,
    usage: "[entityName] [?count] [?x] [?y]",
    description: "Spawns entities at a certain location",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: false
  },
  admin_kill_all: {
    id: CommandID.adminKillAll,
    description: "Kills all entities in the arena",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: false
  },
  admin_kill_entity: {
    id: CommandID.adminKillEntity,
    usage: "[entityName]",
    description: "Kills all entities of the given type (might include self)",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: false
  },
  admin_close_arena: {
    id: CommandID.adminCloseArena,
    description: "Closes the current arena",
    permissionLevel: import_config.AccessLevel.FullAccess,
    isCheat: false
  }
};
const commandCallbacks = {
  game_set_tank: (client, tankNameArg) => {
    var _a;
    const tankDef = (0, import_TankDefinitions.getTankByName)(tankNameArg);
    const player = (_a = client.camera) == null ? void 0 : _a.cameraData.player;
    if (!tankDef || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
      return;
    if (tankDef.flags.devOnly && client.accessLevel !== import_config.AccessLevel.FullAccess)
      return;
    player.setTank(tankDef.id);
  },
  game_set_level: (client, levelArg) => {
    var _a, _b;
    const level = parseInt(levelArg);
    const player = (_a = client.camera) == null ? void 0 : _a.cameraData.player;
    if (isNaN(level) || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
      return;
    const finalLevel = client.accessLevel == import_config.AccessLevel.FullAccess ? level : Math.min(import_config.maxPlayerLevel, level);
    (_b = client.camera) == null ? void 0 : _b.setLevel(finalLevel);
  },
  game_set_score: (client, scoreArg) => {
    var _a, _b;
    const score = parseInt(scoreArg);
    const camera = (_a = client.camera) == null ? void 0 : _a.cameraData;
    const player = (_b = client.camera) == null ? void 0 : _b.cameraData.player;
    if (isNaN(score) || score > Number.MAX_SAFE_INTEGER || score < Number.MIN_SAFE_INTEGER || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default) || !camera)
      return;
    camera.score = score;
  },
  game_set_stat_max: (client, statIdArg, statMaxArg) => {
    var _a, _b;
    const statId = import_Enums.StatCount - parseInt(statIdArg);
    const statMax = parseInt(statMaxArg);
    const camera = (_a = client.camera) == null ? void 0 : _a.cameraData;
    const player = (_b = client.camera) == null ? void 0 : _b.cameraData.player;
    if (statId < 0 || statId >= import_Enums.StatCount || isNaN(statId) || isNaN(statMax) || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default) || !camera)
      return;
    const clampedStatMax = Math.max(statMax, 0);
    camera.statLimits[statId] = clampedStatMax;
    camera.statLevels[statId] = Math.min(camera.statLevels[statId], clampedStatMax);
  },
  game_set_stat: (client, statIdArg, statPointsArg) => {
    var _a, _b;
    const statId = import_Enums.StatCount - parseInt(statIdArg);
    const statPoints = parseInt(statPointsArg);
    const camera = (_a = client.camera) == null ? void 0 : _a.cameraData;
    const player = (_b = client.camera) == null ? void 0 : _b.cameraData.player;
    if (statId < 0 || statId >= import_Enums.StatCount || isNaN(statId) || isNaN(statPoints) || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default) || !camera)
      return;
    camera.statLevels[statId] = statPoints;
  },
  game_add_upgrade_points: (client, pointsArg) => {
    var _a, _b;
    const points = parseInt(pointsArg);
    const camera = (_a = client.camera) == null ? void 0 : _a.cameraData;
    const player = (_b = client.camera) == null ? void 0 : _b.cameraData.player;
    if (isNaN(points) || points > Number.MAX_SAFE_INTEGER || points < Number.MIN_SAFE_INTEGER || !import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default) || !camera)
      return;
    camera.statsAvailable += points;
  },
  game_teleport: (client, xArg, yArg) => {
    var _a;
    const player = (_a = client.camera) == null ? void 0 : _a.cameraData.player;
    if (!import_Entity.Entity.exists(player) || !(player instanceof import_Object.default))
      return;
    const x = xArg.match(RELATIVE_POS_REGEX) ? player.positionData.x + parseInt(xArg.slice(1) || "0", 10) : parseInt(xArg, 10);
    const y = yArg.match(RELATIVE_POS_REGEX) ? player.positionData.y + parseInt(yArg.slice(1) || "0", 10) : parseInt(yArg, 10);
    if (isNaN(x) || isNaN(y))
      return;
    player.positionData.x = x;
    player.positionData.y = y;
    player.setVelocity(0, 0);
    player.entityState |= import_Entity.EntityStateFlags.needsCreate | import_Entity.EntityStateFlags.needsDelete;
  },
  game_claim: (client, entityArg) => {
    var _a;
    const TEntity = new Map([
      ["ArenaCloser", import_ArenaCloser.default],
      ["Dominator", import_Dominator.default],
      ["Shape", import_AbstractShape.default],
      ["Boss", import_AbstractBoss.default],
      ["AutoTurret", import_AutoTurret.default]
    ]).get(entityArg);
    if (!TEntity || !((_a = client.camera) == null ? void 0 : _a.game.entities.AIs.length))
      return;
    const AIs = Array.from(client.camera.game.entities.AIs);
    for (let i = 0; i < AIs.length; ++i) {
      if (!(AIs[i].owner instanceof TEntity))
        continue;
      client.possess(AIs[i]);
      return;
    }
  },
  game_godmode: (client, activeArg) => {
    var _a;
    const player = (_a = client.camera) == null ? void 0 : _a.cameraData.player;
    if (!import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
      return;
    switch (activeArg) {
      case "on":
        player.setInvulnerability(true);
        break;
      case "off":
        player.setInvulnerability(false);
        break;
      default:
        player.setInvulnerability(!player.isInvulnerable);
        break;
    }
    const godmodeState = player.isInvulnerable ? "ON" : "OFF";
    return `God mode: ${godmodeState}`;
  },
  admin_summon: (client, entityArg, countArg, xArg, yArg) => {
    var _a, _b;
    const count = countArg ? parseInt(countArg) : 1;
    let x = parseInt(xArg || "0", 10);
    let y = parseInt(yArg || "0", 10);
    const player = (_a = client.camera) == null ? void 0 : _a.cameraData.player;
    if (import_Entity.Entity.exists(player) && player instanceof import_Object.default) {
      if (xArg && xArg.match(RELATIVE_POS_REGEX)) {
        x = player.positionData.x + parseInt(xArg.slice(1) || "0", 10);
      }
      if (yArg && yArg.match(RELATIVE_POS_REGEX)) {
        y = player.positionData.y + parseInt(yArg.slice(1) || "0", 10);
      }
    }
    const game = (_b = client.camera) == null ? void 0 : _b.game;
    const TEntity = new Map([
      ["Defender", import_Defender.default],
      ["Summoner", import_Summoner.default],
      ["Guardian", import_Guardian.default],
      ["FallenOverlord", import_FallenOverlord.default],
      ["FallenBooster", import_FallenBooster.default],
      ["FallenAC", import_FallenAC.default],
      ["FallenSpike", import_FallenSpike.default],
      ["ArenaCloser", import_ArenaCloser.default],
      ["Crasher", import_Crasher.default],
      ["Pentagon", import_Pentagon.default],
      ["Square", import_Square.default],
      ["Triangle", import_Triangle.default]
    ]).get(entityArg);
    if (isNaN(count) || count < 0 || !game || !TEntity)
      return;
    for (let i = 0; i < count; ++i) {
      const boss = new TEntity(game);
      if (!isNaN(x) && !isNaN(y)) {
        boss.positionData.x = x;
        boss.positionData.y = y;
      }
    }
  },
  admin_kill_all: (client) => {
    var _a, _b;
    const game = (_a = client.camera) == null ? void 0 : _a.game;
    if (!game)
      return;
    for (let id = 0; id <= game.entities.lastId; ++id) {
      const entity = game.entities.inner[id];
      if (import_Entity.Entity.exists(entity) && entity instanceof import_Live.default && entity !== ((_b = client.camera) == null ? void 0 : _b.cameraData.player))
        entity.healthData.health = 0;
    }
  },
  admin_close_arena: (client) => {
    var _a;
    (_a = client == null ? void 0 : client.camera) == null ? void 0 : _a.game.arena.close();
  },
  admin_kill_entity: (client, entityArg) => {
    var _a;
    const TEntity = new Map([
      ["ArenaCloser", import_ArenaCloser.default],
      ["Dominator", import_Dominator.default],
      ["Bullet", import_Bullet.default],
      ["Tank", import_TankBody.default],
      ["Shape", import_AbstractShape.default],
      ["Boss", import_AbstractBoss.default]
    ]).get(entityArg);
    const game = (_a = client.camera) == null ? void 0 : _a.game;
    if (!TEntity || !game)
      return;
    for (let id = 0; id <= game.entities.lastId; ++id) {
      const entity = game.entities.inner[id];
      if (import_Entity.Entity.exists(entity) && entity instanceof TEntity)
        entity.healthData.health = 0;
    }
  }
};
const executeCommand = (client, cmd, args) => {
  if (!commandDefinitions.hasOwnProperty(cmd) || !commandCallbacks.hasOwnProperty(cmd)) {
    return (0, import_util.saveToVLog)(`${client.toString()} tried to run the invalid command ${cmd}`);
  }
  if (client.accessLevel < commandDefinitions[cmd].permissionLevel) {
    return (0, import_util.saveToVLog)(`${client.toString()} tried to run the command ${cmd} with a permission that was too low`);
  }
  const commandDefinition = commandDefinitions[cmd];
  if (commandDefinition.isCheat)
    client.setHasCheated(true);
  const response = commandCallbacks[cmd](client, ...args);
  if (response) {
    client.notify(response, 65280, 5e3, `cmd-callback${commandDefinition.id}`);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  CommandID,
  commandCallbacks,
  commandDefinitions,
  executeCommand
});
//# sourceMappingURL=Commands.js.map
