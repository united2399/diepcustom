var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  ArenaFlags: () => ArenaFlags,
  BarrelFlags: () => BarrelFlags,
  CameraFlags: () => CameraFlags,
  ClientBound: () => ClientBound,
  Color: () => Color,
  ColorsHexCode: () => ColorsHexCode,
  HealthFlags: () => HealthFlags,
  InputFlags: () => InputFlags,
  NameFlags: () => NameFlags,
  PhysicsFlags: () => PhysicsFlags,
  PositionFlags: () => PositionFlags,
  ServerBound: () => ServerBound,
  Stat: () => Stat,
  StatCount: () => StatCount,
  StyleFlags: () => StyleFlags,
  Tank: () => Tank,
  TeamFlags: () => TeamFlags,
  levelToScore: () => levelToScore,
  levelToScoreTable: () => levelToScoreTable
});
var import_config = __toModule(require("../config"));
var Color;
(function(Color2) {
  Color2[Color2["Border"] = 0] = "Border";
  Color2[Color2["Barrel"] = 1] = "Barrel";
  Color2[Color2["Tank"] = 2] = "Tank";
  Color2[Color2["TeamBlue"] = 3] = "TeamBlue";
  Color2[Color2["TeamRed"] = 4] = "TeamRed";
  Color2[Color2["TeamPurple"] = 5] = "TeamPurple";
  Color2[Color2["TeamGreen"] = 6] = "TeamGreen";
  Color2[Color2["Shiny"] = 7] = "Shiny";
  Color2[Color2["EnemySquare"] = 8] = "EnemySquare";
  Color2[Color2["EnemyTriangle"] = 9] = "EnemyTriangle";
  Color2[Color2["EnemyPentagon"] = 10] = "EnemyPentagon";
  Color2[Color2["EnemyCrasher"] = 11] = "EnemyCrasher";
  Color2[Color2["Neutral"] = 12] = "Neutral";
  Color2[Color2["ScoreboardBar"] = 13] = "ScoreboardBar";
  Color2[Color2["Box"] = 14] = "Box";
  Color2[Color2["EnemyTank"] = 15] = "EnemyTank";
  Color2[Color2["NecromancerSquare"] = 16] = "NecromancerSquare";
  Color2[Color2["Fallen"] = 17] = "Fallen";
  Color2[Color2["Egg"] = 18] = "Egg";
  Color2[Color2["kMaxColors"] = 19] = "kMaxColors";
})(Color || (Color = {}));
const ColorsHexCode = {
  [0]: 5592405,
  [1]: 10066329,
  [2]: 45793,
  [3]: 45793,
  [4]: 15814228,
  [5]: 12550133,
  [6]: 57710,
  [7]: 9109353,
  [8]: 16771177,
  [9]: 16545399,
  [10]: 7769596,
  [11]: 15824861,
  [12]: 16771177,
  [13]: 4456337,
  [14]: 12303291,
  [15]: 15814228,
  [16]: 16565110,
  [17]: 12632256,
  [18]: 15264759,
  [19]: 0
};
var Tank;
(function(Tank2) {
  Tank2[Tank2["Basic"] = 0] = "Basic";
  Tank2[Tank2["Twin"] = 1] = "Twin";
  Tank2[Tank2["Triplet"] = 2] = "Triplet";
  Tank2[Tank2["TripleShot"] = 3] = "TripleShot";
  Tank2[Tank2["QuadTank"] = 4] = "QuadTank";
  Tank2[Tank2["OctoTank"] = 5] = "OctoTank";
  Tank2[Tank2["Sniper"] = 6] = "Sniper";
  Tank2[Tank2["MachineGun"] = 7] = "MachineGun";
  Tank2[Tank2["FlankGuard"] = 8] = "FlankGuard";
  Tank2[Tank2["TriAngle"] = 9] = "TriAngle";
  Tank2[Tank2["Destroyer"] = 10] = "Destroyer";
  Tank2[Tank2["Overseer"] = 11] = "Overseer";
  Tank2[Tank2["Overlord"] = 12] = "Overlord";
  Tank2[Tank2["TwinFlank"] = 13] = "TwinFlank";
  Tank2[Tank2["PentaShot"] = 14] = "PentaShot";
  Tank2[Tank2["Assassin"] = 15] = "Assassin";
  Tank2[Tank2["ArenaCloser"] = 16] = "ArenaCloser";
  Tank2[Tank2["Necromancer"] = 17] = "Necromancer";
  Tank2[Tank2["TripleTwin"] = 18] = "TripleTwin";
  Tank2[Tank2["Hunter"] = 19] = "Hunter";
  Tank2[Tank2["Gunner"] = 20] = "Gunner";
  Tank2[Tank2["Stalker"] = 21] = "Stalker";
  Tank2[Tank2["Ranger"] = 22] = "Ranger";
  Tank2[Tank2["Booster"] = 23] = "Booster";
  Tank2[Tank2["Fighter"] = 24] = "Fighter";
  Tank2[Tank2["Hybrid"] = 25] = "Hybrid";
  Tank2[Tank2["Manager"] = 26] = "Manager";
  Tank2[Tank2["Mothership"] = 27] = "Mothership";
  Tank2[Tank2["Predator"] = 28] = "Predator";
  Tank2[Tank2["Sprayer"] = 29] = "Sprayer";
  Tank2[Tank2["Trapper"] = 30] = "Trapper";
  Tank2[Tank2["GunnerTrapper"] = 32] = "GunnerTrapper";
  Tank2[Tank2["Overtrapper"] = 33] = "Overtrapper";
  Tank2[Tank2["MegaTrapper"] = 34] = "MegaTrapper";
  Tank2[Tank2["TriTrapper"] = 35] = "TriTrapper";
  Tank2[Tank2["Smasher"] = 36] = "Smasher";
  Tank2[Tank2["Landmine"] = 37] = "Landmine";
  Tank2[Tank2["AutoGunner"] = 39] = "AutoGunner";
  Tank2[Tank2["Auto5"] = 40] = "Auto5";
  Tank2[Tank2["Auto3"] = 41] = "Auto3";
  Tank2[Tank2["SpreadShot"] = 42] = "SpreadShot";
  Tank2[Tank2["Streamliner"] = 43] = "Streamliner";
  Tank2[Tank2["AutoTrapper"] = 44] = "AutoTrapper";
  Tank2[Tank2["DominatorD"] = 45] = "DominatorD";
  Tank2[Tank2["DominatorG"] = 46] = "DominatorG";
  Tank2[Tank2["DominatorT"] = 47] = "DominatorT";
  Tank2[Tank2["Battleship"] = 48] = "Battleship";
  Tank2[Tank2["Annihilator"] = 49] = "Annihilator";
  Tank2[Tank2["AutoSmasher"] = 50] = "AutoSmasher";
  Tank2[Tank2["Spike"] = 51] = "Spike";
  Tank2[Tank2["Factory"] = 52] = "Factory";
  Tank2[Tank2["Skimmer"] = 54] = "Skimmer";
  Tank2[Tank2["Rocketeer"] = 55] = "Rocketeer";
  Tank2[Tank2["Wark"] = 56] = "Wark";
  Tank2[Tank2["Warkwark"] = 57] = "Warkwark";
  Tank2[Tank2["Bulwark"] = 58] = "Bulwark";
  Tank2[Tank2["TetraTrapper"] = 59] = "TetraTrapper";
  Tank2[Tank2["Tankwark"] = 60] = "Tankwark";
  Tank2[Tank2["Hindwark"] = 61] = "Hindwark";
  Tank2[Tank2["Blazer"] = 62] = "Blazer";
  Tank2[Tank2["TrapGuard"] = 63] = "TrapGuard";
  Tank2[Tank2["SniperTrapper"] = 64] = "SniperTrapper";
  Tank2[Tank2["Synthtrapper"] = 65] = "Synthtrapper";
  Tank2[Tank2["Intertrapper"] = 66] = "Intertrapper";
  Tank2[Tank2["Director"] = 67] = "Director";
  Tank2[Tank2["Underseer"] = 68] = "Underseer";
  Tank2[Tank2["Spawner"] = 69] = "Spawner";
  Tank2[Tank2["Infestor"] = 70] = "Infestor";
  Tank2[Tank2["Maleficitor"] = 71] = "Maleficitor";
})(Tank || (Tank = {}));
var Stat;
(function(Stat2) {
  Stat2[Stat2["MovementSpeed"] = 0] = "MovementSpeed";
  Stat2[Stat2["Reload"] = 1] = "Reload";
  Stat2[Stat2["BulletDamage"] = 2] = "BulletDamage";
  Stat2[Stat2["BulletPenetration"] = 3] = "BulletPenetration";
  Stat2[Stat2["BulletSpeed"] = 4] = "BulletSpeed";
  Stat2[Stat2["BodyDamage"] = 5] = "BodyDamage";
  Stat2[Stat2["MaxHealth"] = 6] = "MaxHealth";
  Stat2[Stat2["HealthRegen"] = 7] = "HealthRegen";
})(Stat || (Stat = {}));
const StatCount = 8;
var ServerBound;
(function(ServerBound2) {
  ServerBound2[ServerBound2["Init"] = 0] = "Init";
  ServerBound2[ServerBound2["Input"] = 1] = "Input";
  ServerBound2[ServerBound2["Spawn"] = 2] = "Spawn";
  ServerBound2[ServerBound2["StatUpgrade"] = 3] = "StatUpgrade";
  ServerBound2[ServerBound2["TankUpgrade"] = 4] = "TankUpgrade";
  ServerBound2[ServerBound2["Ping"] = 5] = "Ping";
  ServerBound2[ServerBound2["TCPInit"] = 6] = "TCPInit";
  ServerBound2[ServerBound2["ExtensionFound"] = 7] = "ExtensionFound";
  ServerBound2[ServerBound2["ToRespawn"] = 8] = "ToRespawn";
  ServerBound2[ServerBound2["TakeTank"] = 9] = "TakeTank";
})(ServerBound || (ServerBound = {}));
var ClientBound;
(function(ClientBound2) {
  ClientBound2[ClientBound2["Update"] = 0] = "Update";
  ClientBound2[ClientBound2["OutdatedClient"] = 1] = "OutdatedClient";
  ClientBound2[ClientBound2["Compressed"] = 2] = "Compressed";
  ClientBound2[ClientBound2["Notification"] = 3] = "Notification";
  ClientBound2[ClientBound2["ServerInfo"] = 4] = "ServerInfo";
  ClientBound2[ClientBound2["Ping"] = 5] = "Ping";
  ClientBound2[ClientBound2["PartyCode"] = 6] = "PartyCode";
  ClientBound2[ClientBound2["Accept"] = 7] = "Accept";
  ClientBound2[ClientBound2["Achievement"] = 8] = "Achievement";
  ClientBound2[ClientBound2["InvalidParty"] = 9] = "InvalidParty";
  ClientBound2[ClientBound2["PlayerCount"] = 10] = "PlayerCount";
  ClientBound2[ClientBound2["ProofOfWork"] = 11] = "ProofOfWork";
})(ClientBound || (ClientBound = {}));
var InputFlags;
(function(InputFlags2) {
  InputFlags2[InputFlags2["leftclick"] = 1] = "leftclick";
  InputFlags2[InputFlags2["up"] = 2] = "up";
  InputFlags2[InputFlags2["left"] = 4] = "left";
  InputFlags2[InputFlags2["down"] = 8] = "down";
  InputFlags2[InputFlags2["right"] = 16] = "right";
  InputFlags2[InputFlags2["godmode"] = 32] = "godmode";
  InputFlags2[InputFlags2["suicide"] = 64] = "suicide";
  InputFlags2[InputFlags2["rightclick"] = 128] = "rightclick";
  InputFlags2[InputFlags2["levelup"] = 256] = "levelup";
  InputFlags2[InputFlags2["gamepad"] = 512] = "gamepad";
  InputFlags2[InputFlags2["switchtank"] = 1024] = "switchtank";
  InputFlags2[InputFlags2["adblock"] = 2048] = "adblock";
})(InputFlags || (InputFlags = {}));
var ArenaFlags;
(function(ArenaFlags2) {
  ArenaFlags2[ArenaFlags2["noJoining"] = 1] = "noJoining";
  ArenaFlags2[ArenaFlags2["showsLeaderArrow"] = 2] = "showsLeaderArrow";
  ArenaFlags2[ArenaFlags2["hiddenScores"] = 4] = "hiddenScores";
  ArenaFlags2[ArenaFlags2["gameReadyStart"] = 8] = "gameReadyStart";
  ArenaFlags2[ArenaFlags2["canUseCheats"] = 16] = "canUseCheats";
})(ArenaFlags || (ArenaFlags = {}));
var TeamFlags;
(function(TeamFlags2) {
  TeamFlags2[TeamFlags2["hasMothership"] = 1] = "hasMothership";
})(TeamFlags || (TeamFlags = {}));
var CameraFlags;
(function(CameraFlags2) {
  CameraFlags2[CameraFlags2["usesCameraCoords"] = 1] = "usesCameraCoords";
  CameraFlags2[CameraFlags2["showingDeathStats"] = 2] = "showingDeathStats";
  CameraFlags2[CameraFlags2["gameWaitingStart"] = 4] = "gameWaitingStart";
})(CameraFlags || (CameraFlags = {}));
var StyleFlags;
(function(StyleFlags2) {
  StyleFlags2[StyleFlags2["isVisible"] = 1] = "isVisible";
  StyleFlags2[StyleFlags2["hasBeenDamaged"] = 2] = "hasBeenDamaged";
  StyleFlags2[StyleFlags2["isFlashing"] = 4] = "isFlashing";
  StyleFlags2[StyleFlags2["_minimap"] = 8] = "_minimap";
  StyleFlags2[StyleFlags2["isStar"] = 16] = "isStar";
  StyleFlags2[StyleFlags2["isTrap"] = 32] = "isTrap";
  StyleFlags2[StyleFlags2["showsAboveParent"] = 64] = "showsAboveParent";
  StyleFlags2[StyleFlags2["hasNoDmgIndicator"] = 128] = "hasNoDmgIndicator";
})(StyleFlags || (StyleFlags = {}));
var PositionFlags;
(function(PositionFlags2) {
  PositionFlags2[PositionFlags2["absoluteRotation"] = 1] = "absoluteRotation";
  PositionFlags2[PositionFlags2["canMoveThroughWalls"] = 2] = "canMoveThroughWalls";
})(PositionFlags || (PositionFlags = {}));
var PhysicsFlags;
(function(PhysicsFlags2) {
  PhysicsFlags2[PhysicsFlags2["isTrapezoid"] = 1] = "isTrapezoid";
  PhysicsFlags2[PhysicsFlags2["showsOnMap"] = 2] = "showsOnMap";
  PhysicsFlags2[PhysicsFlags2["_unknown"] = 4] = "_unknown";
  PhysicsFlags2[PhysicsFlags2["noOwnTeamCollision"] = 8] = "noOwnTeamCollision";
  PhysicsFlags2[PhysicsFlags2["isSolidWall"] = 16] = "isSolidWall";
  PhysicsFlags2[PhysicsFlags2["onlySameOwnerCollision"] = 32] = "onlySameOwnerCollision";
  PhysicsFlags2[PhysicsFlags2["isBase"] = 64] = "isBase";
  PhysicsFlags2[PhysicsFlags2["_unknown1"] = 128] = "_unknown1";
  PhysicsFlags2[PhysicsFlags2["canEscapeArena"] = 256] = "canEscapeArena";
})(PhysicsFlags || (PhysicsFlags = {}));
var BarrelFlags;
(function(BarrelFlags2) {
  BarrelFlags2[BarrelFlags2["hasShot"] = 1] = "hasShot";
})(BarrelFlags || (BarrelFlags = {}));
var HealthFlags;
(function(HealthFlags2) {
  HealthFlags2[HealthFlags2["hiddenHealthbar"] = 1] = "hiddenHealthbar";
})(HealthFlags || (HealthFlags = {}));
var NameFlags;
(function(NameFlags2) {
  NameFlags2[NameFlags2["hiddenName"] = 1] = "hiddenName";
  NameFlags2[NameFlags2["highlightedName"] = 2] = "highlightedName";
})(NameFlags || (NameFlags = {}));
const levelToScoreTable = Array(import_config.maxPlayerLevel).fill(0);
for (let i = 1; i < import_config.maxPlayerLevel; ++i) {
  levelToScoreTable[i] = levelToScoreTable[i - 1] + 40 / 9 * 1.06 ** (i - 1) * Math.min(31, i);
}
function levelToScore(level) {
  if (level >= import_config.maxPlayerLevel)
    return levelToScoreTable[import_config.maxPlayerLevel - 1];
  if (level <= 0)
    return 0;
  return levelToScoreTable[level - 1];
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ArenaFlags,
  BarrelFlags,
  CameraFlags,
  ClientBound,
  Color,
  ColorsHexCode,
  HealthFlags,
  InputFlags,
  NameFlags,
  PhysicsFlags,
  PositionFlags,
  ServerBound,
  Stat,
  StatCount,
  StyleFlags,
  Tank,
  TeamFlags,
  levelToScore,
  levelToScoreTable
});
//# sourceMappingURL=Enums.js.map
