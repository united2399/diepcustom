var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => FactoryTestArena
});
var import_Arena = __toModule(require("../../Native/Arena"));
var import_AI = __toModule(require("../../Entity/AI"));
var import_Camera = __toModule(require("../../Native/Camera"));
var import_TankBody = __toModule(require("../../Entity/Tank/TankBody"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Sandbox = __toModule(require("../Sandbox"));
class FactoryTestArena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.shapes = new import_Sandbox.SandboxShapeManager(this);
    this.updateBounds(2500, 2500);
    const nimdac = this.nimdac = new import_TankBody.default(this.game, new import_Camera.CameraEntity(this.game), new import_AI.Inputs());
    nimdac.cameraEntity.cameraData.player = nimdac;
    nimdac.setTank(import_Enums.Tank.Factory);
    nimdac.barrels[0].droneCount = 6;
    nimdac.styleData.flags &= ~import_Enums.StyleFlags.isFlashing;
    nimdac.physicsData.flags |= import_Enums.PhysicsFlags.isBase;
    nimdac.damageReduction = 0;
    nimdac.damagePerTick = 0;
    Object.defineProperty(nimdac, "damagePerTick", {
      get() {
        return 0;
      },
      set() {
      }
    });
    nimdac.physicsData.values.pushFactor = 50;
    nimdac.physicsData.absorbtionFactor = 0;
    nimdac.cameraEntity.setLevel(150);
    nimdac.styleData.color = import_Enums.Color.Neutral;
    nimdac.nameData.name = "The Factory";
  }
  spawnPlayer(tank, client) {
    if (!this.nimdac || !this.nimdac.barrels[0]) {
      return super.spawnPlayer(tank, client);
    }
    const { x, y } = this.nimdac.getWorldPosition();
    const barrel = this.nimdac.barrels[0];
    const shootAngle = barrel.definition.angle + this.nimdac.positionData.values.angle;
    tank.positionData.values.x = x + Math.cos(shootAngle) * barrel.physicsData.values.size * 0.5 - Math.sin(shootAngle) * barrel.definition.offset * this.nimdac.sizeFactor;
    tank.positionData.values.y = y + Math.sin(shootAngle) * barrel.physicsData.values.size * 0.5 + Math.cos(shootAngle) * barrel.definition.offset * this.nimdac.sizeFactor;
    tank.addAcceleration(shootAngle, 40);
  }
  tick(tick) {
    const arenaSize = Math.floor(25 * Math.sqrt(Math.max(this.game.clients.size, 1))) * 100;
    if (this.width !== arenaSize || this.height !== arenaSize)
      this.updateBounds(arenaSize, arenaSize);
    if (this.nimdac && this.nimdac.inputs) {
      this.nimdac.inputs.mouse.magnitude = 5;
      this.nimdac.inputs.mouse.angle += 0.03;
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=FactoryTest.js.map
