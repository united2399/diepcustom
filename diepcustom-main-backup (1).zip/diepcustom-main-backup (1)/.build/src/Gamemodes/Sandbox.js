var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  SandboxShapeManager: () => SandboxShapeManager,
  default: () => SandboxArena
});
var import_Arena = __toModule(require("../Native/Arena"));
var import_Manager = __toModule(require("../Entity/Shape/Manager"));
var import_Enums = __toModule(require("../Const/Enums"));
class SandboxShapeManager extends import_Manager.default {
  get wantedShapes() {
    let i = 0;
    for (const client of this.game.clients) {
      if (client.camera)
        i += 1;
    }
    return Math.floor(i * 12.5);
  }
}
class SandboxArena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.shapes = new SandboxShapeManager(this);
    this.updateBounds(2500, 2500);
    this.arenaData.values.flags |= import_Enums.ArenaFlags.canUseCheats;
  }
  tick(tick) {
    const arenaSize = Math.floor(25 * Math.sqrt(Math.max(this.game.clients.size, 1))) * 100;
    if (this.width !== arenaSize || this.height !== arenaSize)
      this.updateBounds(arenaSize, arenaSize);
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  SandboxShapeManager
});
//# sourceMappingURL=Sandbox.js.map
