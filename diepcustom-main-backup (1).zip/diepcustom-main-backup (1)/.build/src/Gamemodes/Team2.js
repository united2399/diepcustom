var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Teams2Arena
});
var import_Arena = __toModule(require("../Native/Arena"));
var import_TeamBase = __toModule(require("../Entity/Misc/TeamBase"));
var import_TeamEntity = __toModule(require("../Entity/Misc/TeamEntity"));
var import_Enums = __toModule(require("../Const/Enums"));
const arenaSize = 11150;
const baseWidth = 2007;
class Teams2Arena extends import_Arena.default {
  constructor(game) {
    super(game);
    this.playerTeamMap = new Map();
    this.updateBounds(arenaSize * 2, arenaSize * 2);
    this.blueTeamBase = new import_TeamBase.default(game, new import_TeamEntity.TeamEntity(this.game, import_Enums.Color.TeamBlue), -arenaSize + baseWidth / 2, 0, arenaSize * 2, baseWidth);
    this.redTeamBase = new import_TeamBase.default(game, new import_TeamEntity.TeamEntity(this.game, import_Enums.Color.TeamRed), arenaSize - baseWidth / 2, 0, arenaSize * 2, baseWidth);
  }
  spawnPlayer(tank, client) {
    tank.positionData.values.y = 2 * arenaSize * Math.random() - arenaSize;
    const xOffset = (Math.random() - 0.5) * baseWidth;
    const base = this.playerTeamMap.get(client) || [this.blueTeamBase, this.redTeamBase][0 | Math.random() * 2];
    tank.relationsData.values.team = base.relationsData.values.team;
    tank.styleData.values.color = base.styleData.values.color;
    tank.positionData.values.x = base.positionData.values.x + xOffset;
    this.playerTeamMap.set(client, base);
    if (client.camera)
      client.camera.relationsData.team = tank.relationsData.values.team;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Team2.js.map
