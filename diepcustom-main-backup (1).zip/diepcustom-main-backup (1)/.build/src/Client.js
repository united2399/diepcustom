var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  ClientInputs: () => ClientInputs,
  default: () => Client
});
var config = __toModule(require("./config"));
var util = __toModule(require("./util"));
var import_crypto = __toModule(require("crypto"));
var import_Reader = __toModule(require("./Coder/Reader"));
var import_Writer = __toModule(require("./Coder/Writer"));
var import_Game = __toModule(require("./Game"));
var import_Camera = __toModule(require("./Native/Camera"));
var import_Arena = __toModule(require("./Native/Arena"));
var import_Object = __toModule(require("./Entity/Object"));
var import_TankDefinitions = __toModule(require("./Const/TankDefinitions"));
var import_DevTankDefinitions = __toModule(require("./Const/DevTankDefinitions"));
var import_TankBody = __toModule(require("./Entity/Tank/TankBody"));
var import_Vector = __toModule(require("./Physics/Vector"));
var import_Entity = __toModule(require("./Native/Entity"));
var import_Enums = __toModule(require("./Const/Enums"));
var import_AI = __toModule(require("./Entity/AI"));
var import_AbstractBoss = __toModule(require("./Entity/Boss/AbstractBoss"));
var import_Commands = __toModule(require("./Const/Commands"));
var import__ = __toModule(require("."));
const TANK_XOR = config.magicNum % import_TankDefinitions.TankCount;
const STAT_XOR = config.magicNum % import_Enums.StatCount;
const PING_PACKET = new Uint8Array([import_Enums.ClientBound.Ping]);
class WSWriterStream extends import_Writer.default {
  constructor(client) {
    super();
    this.client = client;
  }
  send() {
    this.client.send(this.write());
  }
}
class ClientInputs extends import_AI.Inputs {
  constructor(client) {
    super();
    this.cachedFlags = 0;
    this.isPossessing = false;
    this.client = client;
  }
}
class Client {
  constructor(ws, game) {
    this.terminated = false;
    this.accessLevel = config.AccessLevel.NoAccess;
    this.incomingCache = [];
    this.inputs = new ClientInputs(this);
    this.camera = null;
    this.devCheatsUsed = false;
    this.isInvulnerable = false;
    this.damageReductionCache = 1;
    this.game = game;
    this.game.clients.add(this);
    this.ws = ws;
    this.lastPingTick = this.connectTick = game.tick;
  }
  write() {
    return new WSWriterStream(this);
  }
  acceptClient() {
    this.write().u8(import_Enums.ClientBound.ServerInfo).stringNT(this.game.gamemode).stringNT(config.host).send();
    this.write().u8(import_Enums.ClientBound.PlayerCount).vu(import_Game.default.globalPlayerCount).send();
    this.write().u8(import_Enums.ClientBound.Accept).vi(this.accessLevel).send();
    this.camera = new import_Camera.default(this.game, this);
  }
  send(data) {
    const ws = this.ws;
    if (!ws)
      throw new Error("Can't write to a closed websocket - shouldn't be referencing a closed client");
    ws.send(data, true);
  }
  onClose(code, message) {
    this.ws = null;
    this.terminate();
  }
  terminate() {
    if (this.terminated)
      return;
    if (this.ws)
      return this.ws.close();
    this.terminated = true;
    this.game.clients.delete(this);
    this.inputs.deleted = true;
    this.inputs.movement.magnitude = 0;
    if (import_Entity.Entity.exists(this.camera))
      this.camera.delete();
  }
  onMessage(buffer, isBinary) {
    if (!isBinary)
      return this.terminate();
    const data = new Uint8Array(buffer).slice();
    if (data[0] === 0 && data.byteLength === 1)
      return this.terminate();
    const header = data[0];
    if (header === import_Enums.ServerBound.Ping) {
      this.lastPingTick = this.game.tick;
      this.send(PING_PACKET);
    } else {
      if (!this.incomingCache[header])
        this.incomingCache[header] = [];
      if (this.incomingCache[header].length) {
        if (header === import_Enums.ServerBound.Input) {
          const r = new import_Reader.default(data);
          r.at = 1;
          const flags = r.vu();
          this.inputs.cachedFlags |= flags & 3553;
        } else if (header === import_Enums.ServerBound.StatUpgrade) {
          this.incomingCache[header].push(data);
        }
        return;
      }
      this.incomingCache[header][0] = data;
    }
  }
  handleIncoming(header, data) {
    var _a, _b, _c;
    if (this.terminated)
      return;
    const r = new import_Reader.default(data);
    r.at = 1;
    const camera = this.camera;
    if (header === import_Enums.ServerBound.Init) {
      if (camera)
        return this.terminate();
      const buildHash = r.stringNT();
      const pw = r.stringNT();
      if (buildHash !== config.buildHash) {
        util.log("Kicking client. Invalid build hash " + JSON.stringify(buildHash));
        util.saveToVLog(this.toString() + " being kicked, wrong version hash " + JSON.stringify(buildHash));
        this.write().u8(import_Enums.ClientBound.OutdatedClient).stringNT(config.buildHash).send();
        setTimeout(() => this.terminate(), 100);
        return;
      }
      if (config.devPasswordHash && (0, import_crypto.createHash)("sha256").update(pw).digest("hex") === config.devPasswordHash) {
        this.accessLevel = config.AccessLevel.FullAccess;
        util.saveToLog("Developer Connected", "A client connected to the server (`" + this.game.gamemode + "`) with `full` access.", 5924330);
      } else {
        this.accessLevel = config.defaultAccessLevel;
      }
      if (this.accessLevel === config.AccessLevel.NoAccess) {
        util.saveToVLog("Possibly unknown, client terminated due to lack of authentication:: " + this.toString());
        return this.terminate();
      }
      this.acceptClient();
      return;
    }
    if (!import_Entity.Entity.exists(camera))
      return;
    switch (header) {
      case import_Enums.ServerBound.Input: {
        const previousFlags = this.inputs.flags;
        const flags = this.inputs.flags = r.vu() | this.inputs.cachedFlags;
        this.inputs.cachedFlags = 0;
        this.inputs.mouse.x = r.vf();
        this.inputs.mouse.y = r.vf();
        if (!import_Vector.default.isFinite(this.inputs.mouse))
          break;
        const movement = {
          x: 0,
          y: 0
        };
        if (flags & import_Enums.InputFlags.up)
          movement.y -= 1;
        if (flags & import_Enums.InputFlags.down)
          movement.y += 1;
        if (flags & import_Enums.InputFlags.right)
          movement.x += 1;
        if (flags & import_Enums.InputFlags.left)
          movement.x -= 1;
        if (movement.x || movement.y) {
          const angle = Math.atan2(movement.y, movement.x);
          const magnitude = util.constrain(Math.sqrt(movement.x ** 2 + movement.y ** 2), -1, 1);
          this.inputs.movement.magnitude = magnitude;
          this.inputs.movement.angle = angle;
        }
        const player = camera.cameraData.values.player;
        if (!import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
          return;
        if (this.inputs.isPossessing && this.accessLevel !== config.AccessLevel.FullAccess)
          return;
        if (flags & import_Enums.InputFlags.godmode) {
          if (this.accessLevel >= config.AccessLevel.BetaAccess) {
            this.setHasCheated(true);
            player.setTank(player.currentTank < 0 ? import_Enums.Tank.Basic : import_DevTankDefinitions.DevTank.Developer);
          } else if (this.game.arena.arenaData.values.flags & import_Enums.ArenaFlags.canUseCheats) {
            if (this.game.clients.size === 1 && this.game.arena.state === import_Arena.ArenaState.OPEN) {
              this.setHasCheated(true);
              player.setInvulnerability(!player.isInvulnerable);
              this.notify(`God mode: ${player.isInvulnerable ? "ON" : "OFF"}`, 0, 1e3, "godmode");
            }
          }
        }
        if (flags & import_Enums.InputFlags.rightclick && !(previousFlags & import_Enums.InputFlags.rightclick) && (player.currentTank === import_DevTankDefinitions.DevTank.Developer || player.currentTank === import_DevTankDefinitions.DevTank.Spectator)) {
          player.positionData.x = this.inputs.mouse.x;
          player.positionData.y = this.inputs.mouse.y;
          player.setVelocity(0, 0);
          player.entityState |= import_Entity.EntityStateFlags.needsCreate | import_Entity.EntityStateFlags.needsDelete;
        }
        if (flags & import_Enums.InputFlags.switchtank && !(previousFlags & import_Enums.InputFlags.switchtank)) {
          if (this.accessLevel >= config.AccessLevel.BetaAccess || this.game.arena.arenaData.values.flags & import_Enums.ArenaFlags.canUseCheats) {
            this.setHasCheated(true);
            let tank = player.currentTank;
            if (tank >= 0) {
              tank = (tank + import_TankDefinitions.default.length - 1) % import_TankDefinitions.default.length;
              while (!import_TankDefinitions.default[tank] || ((_a = import_TankDefinitions.default[tank]) == null ? void 0 : _a.flags.devOnly) && this.accessLevel < config.AccessLevel.FullAccess) {
                tank = (tank + import_TankDefinitions.default.length - 1) % import_TankDefinitions.default.length;
              }
            } else {
              const isDeveloper = this.accessLevel === config.AccessLevel.FullAccess;
              tank = ~tank;
              tank = (tank + 1) % import_DevTankDefinitions.default.length;
              while (!import_DevTankDefinitions.default[tank] || import_DevTankDefinitions.default[tank].flags.devOnly === true && !isDeveloper) {
                tank = (tank + 1) % import_DevTankDefinitions.default.length;
              }
              tank = ~tank;
            }
            player.setTank(tank);
          }
        }
        if (flags & import_Enums.InputFlags.levelup) {
          if (this.accessLevel === config.AccessLevel.FullAccess || camera.cameraData.values.level < config.maxPlayerLevel && (this.game.arena.arenaData.values.flags & import_Enums.ArenaFlags.canUseCheats || this.accessLevel === config.AccessLevel.BetaAccess)) {
            this.setHasCheated(true);
            camera.setLevel(camera.cameraData.values.level + 1);
          }
        }
        if (flags & import_Enums.InputFlags.suicide && (!player.deletionAnimation || !player.deletionAnimation) && !this.inputs.isPossessing) {
          if (this.accessLevel >= config.AccessLevel.BetaAccess || this.game.arena.arenaData.values.flags & import_Enums.ArenaFlags.canUseCheats) {
            this.setHasCheated(true);
            this.notify("You've killed " + (player.nameData.values.name === "" ? "an unnamed tank" : player.nameData.values.name));
            camera.cameraData.killedBy = player.nameData.values.name;
            player.destroy();
          }
        }
        return;
      }
      case import_Enums.ServerBound.Spawn: {
        util.log("Client wants to spawn");
        if (this.game.arena.state >= import_Arena.ArenaState.CLOSING)
          return;
        if (import_Entity.Entity.exists(camera.cameraData.values.player))
          return this.terminate();
        camera.cameraData.values.statsAvailable = 0;
        camera.cameraData.values.level = 1;
        for (let i = 0; i < import_Enums.StatCount; ++i) {
          camera.cameraData.values.statLevels.values[i] = 0;
        }
        const name = r.stringNT().slice(0, 16);
        const tank = camera.cameraData.player = camera.relationsData.owner = camera.relationsData.parent = new import_TankBody.default(this.game, camera, this.inputs);
        tank.setTank(import_Enums.Tank.Basic);
        this.game.arena.spawnPlayer(tank, this);
        camera.setLevel(camera.cameraData.values.respawnLevel);
        tank.nameData.values.name = name;
        if (this.hasCheated())
          this.setHasCheated(true);
        camera.entityState = import_Entity.EntityStateFlags.needsCreate | import_Entity.EntityStateFlags.needsDelete;
        camera.spectatee = null;
        this.inputs.isPossessing = false;
        return;
      }
      case import_Enums.ServerBound.StatUpgrade: {
        if (camera.cameraData.statsAvailable <= 0)
          return;
        const player = camera.cameraData.values.player;
        if (!import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
          return;
        if (this.inputs.isPossessing)
          return;
        const definition = (0, import_TankDefinitions.getTankById)(player.currentTank);
        if (!definition || !definition.stats.length)
          return;
        const statId = r.vi() ^ STAT_XOR;
        if (statId < 0 || statId >= import_Enums.StatCount)
          return;
        const statLimit = camera.cameraData.values.statLimits.values[statId];
        if (camera.cameraData.values.statLevels.values[statId] >= statLimit)
          return;
        camera.cameraData.statLevels[statId] += 1;
        camera.cameraData.statsAvailable -= 1;
        return;
      }
      case import_Enums.ServerBound.TankUpgrade: {
        const player = camera.cameraData.values.player;
        if (this.inputs.isPossessing)
          return;
        if (!import_Entity.Entity.exists(player) || !(player instanceof import_TankBody.default))
          return;
        const definition = (0, import_TankDefinitions.getTankById)(player.currentTank);
        const tankId = r.vi() ^ TANK_XOR;
        const tankDefinition = (0, import_TankDefinitions.getTankById)(tankId);
        if (!definition || !definition.upgrades.includes(tankId) || !tankDefinition || tankDefinition.levelRequirement > camera.cameraData.values.level)
          return;
        player.setTank(tankId);
        return;
      }
      case import_Enums.ServerBound.ExtensionFound: {
        util.log("Someone is cheating");
        this.ban();
        return;
      }
      case import_Enums.ServerBound.ToRespawn: {
        camera.cameraData.flags &= ~import_Enums.CameraFlags.showingDeathStats;
        return;
      }
      case import_Enums.ServerBound.TakeTank: {
        if (!import_Entity.Entity.exists(camera.cameraData.player))
          return;
        if (!this.game.entities.AIs.length)
          return this.notify("Someone has already taken that tank", 0, 5e3, "cant_claim_info");
        if (!this.inputs.isPossessing) {
          const x = ((_b = camera.cameraData.player.positionData) == null ? void 0 : _b.values.x) || 0;
          const y = ((_c = camera.cameraData.player.positionData) == null ? void 0 : _c.values.y) || 0;
          const AIs = Array.from(this.game.entities.AIs);
          AIs.sort((a, b) => {
            const { x: x1, y: y1 } = a.owner.getWorldPosition();
            const { x: x2, y: y2 } = b.owner.getWorldPosition();
            return (x1 - x) ** 2 + (y1 - y) ** 2 - ((x2 - x) ** 2 + (y2 - y) ** 2);
          });
          for (let i = 0; i < AIs.length; ++i) {
            if (AIs[i].state !== import_AI.AIState.possessed && (AIs[i].owner.relationsData.values.team === camera.relationsData.values.team && AIs[i].isClaimable || this.accessLevel === config.AccessLevel.FullAccess)) {
              if (!this.possess(AIs[i]))
                continue;
              this.notify("Press H to surrender control of your tank", 0, 5e3);
              return;
            }
          }
          this.notify("Someone has already taken that tank", 0, 5e3, "cant_claim_info");
        } else {
          this.inputs.deleted = true;
        }
        return;
      }
      case import_Enums.ServerBound.TCPInit:
        if (!config.enableCommands)
          return;
        const cmd = r.stringNT();
        const argsLength = r.u8();
        const args = [];
        for (let i = 0; i < argsLength; ++i) {
          args.push(r.stringNT());
        }
        (0, import_Commands.executeCommand)(this, cmd, args);
        return;
      default:
        util.log("Suspicious activies have been evaded");
        return this.ban();
    }
  }
  setHasCheated(value) {
    this.devCheatsUsed = value;
  }
  hasCheated() {
    return this.devCheatsUsed;
  }
  possess(ai) {
    var _a, _b, _c;
    if (!((_a = this.camera) == null ? void 0 : _a.cameraData) || ai.state === import_AI.AIState.possessed)
      return false;
    this.inputs.deleted = true;
    ai.inputs = this.inputs = new ClientInputs(this);
    this.inputs.isPossessing = true;
    ai.state = import_AI.AIState.possessed;
    if (((_b = this.camera) == null ? void 0 : _b.cameraData.values.player) instanceof import_Object.default) {
      const color = this.camera.cameraData.values.player.styleData.values.color;
      this.camera.cameraData.values.player.styleData.values.color = -1;
      this.camera.cameraData.values.player.styleData.color = color;
    }
    this.camera.cameraData.tankOverride = ((_c = ai.owner.nameData) == null ? void 0 : _c.values.name) || "";
    this.camera.cameraData.tank = 53;
    for (let i = 0; i < import_Enums.StatCount; ++i)
      this.camera.cameraData.statLevels[i] = 0;
    for (let i = 0; i < import_Enums.StatCount; ++i)
      this.camera.cameraData.statLimits[i] = 7;
    for (let i = 0; i < import_Enums.StatCount; ++i)
      this.camera.cameraData.statNames[i] = "";
    this.camera.cameraData.killedBy = "";
    this.camera.cameraData.player = ai.owner;
    this.camera.cameraData.movementSpeed = ai.movementSpeed;
    if (ai.owner instanceof import_TankBody.default) {
      this.camera.cameraData.tank = ai.owner.cameraEntity.cameraData.values.tank;
      this.camera.setLevel(ai.owner.cameraEntity.cameraData.values.level);
      for (let i = 0; i < import_Enums.StatCount; ++i)
        this.camera.cameraData.statLevels[i] = ai.owner.cameraEntity.cameraData.statLevels.values[i];
      for (let i = 0; i < import_Enums.StatCount; ++i)
        this.camera.cameraData.statLimits[i] = ai.owner.cameraEntity.cameraData.statLimits.values[i];
      for (let i = 0; i < import_Enums.StatCount; ++i)
        this.camera.cameraData.statNames[i] = ai.owner.cameraEntity.cameraData.statNames.values[i];
      this.camera.cameraData.FOV = ai.owner.cameraEntity.cameraData.FOV;
    } else if (ai.owner instanceof import_AbstractBoss.default) {
      this.camera.setLevel(75);
      this.camera.cameraData.FOV = 0.35;
    } else {
      this.camera.setLevel(30);
    }
    this.camera.cameraData.statsAvailable = 0;
    this.camera.cameraData.score = 0;
    return true;
  }
  notify(text, color = 0, time = 4e3, id = "") {
    this.write().u8(import_Enums.ClientBound.Notification).stringNT(text).u32(color).float(time).stringNT(id).send();
  }
  ban() {
    var _a;
    if (!this.ws)
      return;
    util.saveToLog("IP Banned", "Banned " + this.ws.getUserData().ipAddress + this.toString(true), 15610474);
    if (this.accessLevel >= config.unbannableLevelMinimum) {
      util.saveToLog("IP Ban Cancelled", "Cancelled ban on " + this.ws.getUserData().ipAddress + this.toString(true), 6959854);
      return;
    }
    import__.bannedClients.add(this.ws.getUserData().ipAddress);
    for (const client of this.game.clients) {
      if (((_a = client.ws) == null ? void 0 : _a.getUserData().ipAddress) === this.ws.getUserData().ipAddress)
        client.terminate();
    }
  }
  tick(tick) {
    var _a, _b;
    for (let header = 0; header <= this.incomingCache.length; ++header) {
      if (header === import_Enums.ServerBound.Ping)
        continue;
      if (((_a = this.incomingCache[header]) == null ? void 0 : _a.length) === 1)
        this.handleIncoming(header, this.incomingCache[header][0]);
      else if (((_b = this.incomingCache[header]) == null ? void 0 : _b.length) > 1) {
        for (let i = 0, len = this.incomingCache[header].length; i < len; ++i)
          this.handleIncoming(header, this.incomingCache[header][i]);
      } else
        continue;
      this.incomingCache[header] = [];
    }
    if (!this.camera) {
      if (tick === this.connectTick + 300) {
        return this.terminate();
      }
    } else if (this.inputs.deleted) {
      this.inputs = new ClientInputs(this);
      this.camera.cameraData.player = null;
      this.camera.cameraData.respawnLevel = 0;
      this.camera.cameraData.cameraX = this.camera.cameraData.cameraY = 0;
      this.camera.cameraData.flags &= ~import_Enums.CameraFlags.showingDeathStats;
    }
    if (tick >= this.lastPingTick + 60 * config.tps) {
      return this.terminate();
    }
  }
  toString(verbose = false) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const tokens = [];
    if ((_d = (_c = (_b = (_a = this.camera) == null ? void 0 : _a.cameraData) == null ? void 0 : _b.player) == null ? void 0 : _c.nameData) == null ? void 0 : _d.name)
      tokens.push("name=" + JSON.stringify((_h = (_g = (_f = (_e = this.camera) == null ? void 0 : _e.cameraData) == null ? void 0 : _f.player) == null ? void 0 : _g.nameData) == null ? void 0 : _h.name));
    if (verbose) {
      if (this.ws)
        tokens.push("ip=" + this.ws.getUserData().ipAddress);
      if (this.game.gamemode)
        tokens.push("game.gamemode=" + this.game.gamemode);
    }
    if (this.terminated)
      tokens.push("(terminated)");
    if (!tokens.length)
      return `Client(${this.accessLevel}) {}`;
    return `Client(${this.accessLevel}) { ${tokens.join(", ")} }`;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ClientInputs
});
//# sourceMappingURL=Client.js.map
