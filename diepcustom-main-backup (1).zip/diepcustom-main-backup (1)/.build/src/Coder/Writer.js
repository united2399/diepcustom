var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Writer
});
var import_config = __toModule(require("../config"));
const convo = new ArrayBuffer(4);
const i32 = new Int32Array(convo);
const f32 = new Float32Array(convo);
const Encoder = new TextEncoder();
const endianSwap = (num) => (num & 255) << 24 | (num & 65280) << 8 | num >> 8 & 65280 | num >> 24 & 255;
const _Writer = class {
  constructor() {
    this._at = 0;
  }
  get at() {
    return this._at;
  }
  set at(v) {
    this._at = v;
    if (_Writer.OUTPUT_BUFFER.length <= this._at + 5) {
      const newBuffer = Buffer.alloc(_Writer.OUTPUT_BUFFER.length + import_config.writtenBufferChunkSize);
      newBuffer.set(_Writer.OUTPUT_BUFFER, 0);
      _Writer.OUTPUT_BUFFER = newBuffer;
    }
  }
  u8(val) {
    _Writer.OUTPUT_BUFFER.writeUInt8(val >>> 0 & 255, this.at);
    this.at += 1;
    return this;
  }
  u16(val) {
    _Writer.OUTPUT_BUFFER.writeUint16LE(val >>> 0 & 65535, this.at);
    this.at += 2;
    return this;
  }
  u32(val) {
    _Writer.OUTPUT_BUFFER.writeUint32LE(val >>> 0, this.at);
    this.at += 4;
    return this;
  }
  float(val) {
    _Writer.OUTPUT_BUFFER.writeFloatLE(val, this.at);
    this.at += 4;
    return this;
  }
  vf(val) {
    f32[0] = val;
    return this.vi(endianSwap(i32[0]));
  }
  vu(val) {
    val |= 0;
    do {
      let part = val;
      val >>>= 7;
      if (val)
        part |= 128;
      _Writer.OUTPUT_BUFFER.writeUint8(part >>> 0 & 255, this.at);
      this.at += 1;
    } while (val);
    return this;
  }
  vi(val) {
    val |= 0;
    return this.vu(0 - (val < 0 ? 1 : 0) ^ val << 1);
  }
  bytes(buffer) {
    _Writer.OUTPUT_BUFFER.set(buffer, this.at);
    this.at += buffer.byteLength;
    return this;
  }
  raw(...data) {
    _Writer.OUTPUT_BUFFER.set(data, this.at);
    this.at += data.length;
    return this;
  }
  float64Precision(float) {
    return this.vi(float * 64);
  }
  degrees(degrees) {
    degrees *= Math.PI / 180;
    return this.vi(degrees * 64);
  }
  stringNT(str) {
    const bytes = Encoder.encode(str + "\0");
    for (let i = 0; i < bytes.byteLength; ++i) {
      _Writer.OUTPUT_BUFFER[this.at] = bytes[i];
      this.at += 1;
    }
    return this;
  }
  entid(entity) {
    if (!entity || entity.hash === 0)
      return this.u8(0);
    return this.vu(entity.hash).vu(entity.id);
  }
  write(slice = false) {
    if (slice)
      return _Writer.OUTPUT_BUFFER.slice(0, this.at);
    return _Writer.OUTPUT_BUFFER.subarray(0, this.at);
  }
};
let Writer = _Writer;
Writer.OUTPUT_BUFFER = Buffer.alloc(import_config.writtenBufferChunkSize);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Writer.js.map
