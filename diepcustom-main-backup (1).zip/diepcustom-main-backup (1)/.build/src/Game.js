var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => GameServer
});
var config = __toModule(require("./config"));
var util = __toModule(require("./util"));
var import_Writer = __toModule(require("./Coder/Writer"));
var import_Manager = __toModule(require("./Native/Manager"));
var import_FFA = __toModule(require("./Gamemodes/FFA"));
var import_Team2 = __toModule(require("./Gamemodes/Team2"));
var import_Sandbox = __toModule(require("./Gamemodes/Sandbox"));
var import_Enums = __toModule(require("./Const/Enums"));
var import_Team4 = __toModule(require("./Gamemodes/Team4"));
var import_Domination = __toModule(require("./Gamemodes/Domination"));
var import_Mothership = __toModule(require("./Gamemodes/Mothership"));
var import_Testing = __toModule(require("./Gamemodes/Misc/Testing"));
var import_Spikebox = __toModule(require("./Gamemodes/Misc/Spikebox"));
var import_DomTest = __toModule(require("./Gamemodes/Misc/DomTest"));
var import_Jungle = __toModule(require("./Gamemodes/Misc/Jungle"));
var import_FactoryTest = __toModule(require("./Gamemodes/Misc/FactoryTest"));
var import_Ball = __toModule(require("./Gamemodes/Misc/Ball"));
var import_Maze = __toModule(require("./Gamemodes/Maze"));
class WSSWriterStream extends import_Writer.default {
  constructor(game) {
    super();
    this.game = game;
  }
  send() {
    const bytes = this.write();
    for (let client of this.game.clients) {
      client.send(bytes);
    }
  }
}
const GamemodeToArenaClass = {
  "ffa": import_FFA.default,
  "teams": import_Team2.default,
  "4teams": import_Team4.default,
  "sandbox": import_Sandbox.default,
  "*": import_Sandbox.default,
  "dom": import_Domination.default,
  "survival": null,
  "tag": null,
  "mot": import_Mothership.default,
  "maze": import_Maze.default,
  "testing": import_Testing.default,
  "spike": import_Spikebox.default,
  "domtest": import_DomTest.default,
  "jungle": import_Jungle.default,
  "factest": import_FactoryTest.default,
  "ball": import_Ball.default
};
const _GameServer = class {
  constructor(gamemode, name) {
    this.running = true;
    this.playersOnMap = false;
    this.gamemode = gamemode;
    this.name = name;
    this.clients = new Set();
    const _add = this.clients.add;
    this.clients.add = (client) => {
      _GameServer.globalPlayerCount += 1;
      this.broadcastPlayerCount();
      return _add.call(this.clients, client);
    };
    const _delete = this.clients.delete;
    this.clients.delete = (client) => {
      let success = _delete.call(this.clients, client);
      if (success) {
        _GameServer.globalPlayerCount -= 1;
        this.broadcastPlayerCount();
      }
      return success;
    };
    const _clear = this.clients.clear;
    this.clients.clear = () => {
      _GameServer.globalPlayerCount -= this.clients.size;
      this.broadcastPlayerCount();
      return _clear.call(this.clients);
    };
    this.entities = new import_Manager.default(this);
    this.tick = 0;
    this.arena = new (GamemodeToArenaClass[this.gamemode] || GamemodeToArenaClass["*"])(this);
    this._tickInterval = setInterval(() => {
      if (this.clients.size)
        this.tickLoop();
    }, config.mspt);
  }
  broadcast() {
    return new WSSWriterStream(this);
  }
  broadcastPlayerCount() {
    this.broadcast().vu(import_Enums.ClientBound.PlayerCount).vu(_GameServer.globalPlayerCount).send();
  }
  end() {
    util.saveToLog("Game Instance Ending", "Game running " + this.gamemode + " at `" + this.gamemode + "` is now closing.", 15614258);
    util.log("Ending Game instance");
    clearInterval(this._tickInterval);
    for (const client of this.clients) {
      client.terminate();
    }
    this.tick = 0;
    this.clients.clear();
    this.entities.clear();
    this.running = false;
    this.onEnd();
  }
  onEnd() {
    util.log("Game instance is now over");
    this.start();
  }
  start() {
    if (this.running)
      return;
    util.log("New game instance booting up");
    this.clients.clear();
    this.entities = new import_Manager.default(this);
    this.tick = 0;
    this.arena = new (GamemodeToArenaClass[this.gamemode] || GamemodeToArenaClass["*"])(this);
    this._tickInterval = setInterval(() => {
      if (this.clients.size)
        this.tickLoop();
    }, config.mspt);
  }
  tickLoop() {
    this.tick += 1;
    this.entities.tick(this.tick);
    for (const client of this.clients)
      client.tick(this.tick);
  }
};
let GameServer = _GameServer;
GameServer.globalPlayerCount = 0;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Game.js.map
