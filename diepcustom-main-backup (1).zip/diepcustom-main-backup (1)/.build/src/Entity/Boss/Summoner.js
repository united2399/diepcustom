var __create = Object.create;
var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Summoner
});
var import_Barrel = __toModule(require("../Tank/Barrel"));
var import_AbstractBoss = __toModule(require("./AbstractBoss"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_util = __toModule(require("../../util"));
const SummonerSpawnerDefinition = {
  angle: Math.PI,
  offset: 0,
  size: 135,
  width: 71.4,
  delay: 0,
  reload: 0.25,
  recoil: 1,
  isTrapezoid: true,
  trapezoidDirection: 0,
  addon: null,
  droneCount: 7,
  canControlDrones: true,
  bullet: {
    type: "drone",
    sizeRatio: 55 * Math.SQRT1_2 / (71.4 / 2),
    health: 12.5,
    damage: 0.5,
    speed: 1.7,
    scatterRate: 1,
    lifeLength: -1,
    absorbtionFactor: 1,
    color: import_Enums.Color.NecromancerSquare,
    sides: 4
  }
};
const SUMMONER_SIZE = 150;
class Summoner extends import_AbstractBoss.default {
  constructor(game) {
    super(game);
    this.spawners = [];
    this.nameData.values.name = "Summoner";
    this.styleData.values.color = import_Enums.Color.EnemySquare;
    this.relationsData.values.team = this.game.arena;
    this.physicsData.values.size = SUMMONER_SIZE * Math.SQRT1_2;
    this.physicsData.values.sides = 4;
    for (let i = 0; i < 4; ++i) {
      this.spawners.push(new import_Barrel.default(this, __spreadProps(__spreadValues({}, SummonerSpawnerDefinition), {
        angle: import_util.PI2 * (i / 4 - 1 / 4)
      })));
    }
  }
  get sizeFactor() {
    return this.physicsData.values.size / Math.SQRT1_2 / SUMMONER_SIZE;
  }
  tick(tick) {
    super.tick(tick);
    if (this.ai.state !== import_AI.AIState.possessed) {
      this.positionData.angle += this.ai.passiveRotation;
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Summoner.js.map
