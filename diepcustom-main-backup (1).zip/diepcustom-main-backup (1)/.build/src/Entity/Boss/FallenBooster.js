var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => FallenBooster
});
var import_Barrel = __toModule(require("../Tank/Barrel"));
var import_TankDefinitions = __toModule(require("../../Const/TankDefinitions"));
var import_AbstractBoss = __toModule(require("./AbstractBoss"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
class FallenBooster extends import_AbstractBoss.default {
  constructor(game) {
    super(game);
    this.movementSpeed = 1;
    this.nameData.values.name = "Fallen Booster";
    for (const barrelDefinition of import_TankDefinitions.default[import_Enums.Tank.Booster].barrels) {
      const def = Object.assign({}, barrelDefinition, {});
      def.bullet = Object.assign({}, def.bullet, { speed: 1.7, health: 6.25 });
      this.barrels.push(new import_Barrel.default(this, def));
    }
  }
  get sizeFactor() {
    return this.physicsData.values.size / 50;
  }
  moveAroundMap() {
    const x = this.positionData.values.x, y = this.positionData.values.y;
    if (this.ai.state === import_AI.AIState.idle) {
      super.moveAroundMap();
      this.positionData.angle = Math.atan2(this.inputs.movement.y, this.inputs.movement.x);
    } else {
      this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - y, this.ai.inputs.mouse.x - x);
    }
  }
  tick(tick) {
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=FallenBooster.js.map
