var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Guardian
});
var import_Barrel = __toModule(require("../Tank/Barrel"));
var import_AbstractBoss = __toModule(require("./AbstractBoss"));
var import_Enums = __toModule(require("../../Const/Enums"));
const GuardianSpawnerDefinition = {
  angle: Math.PI,
  offset: 0,
  size: 100,
  width: 71.4,
  delay: 0,
  reload: 0.25,
  recoil: 1,
  isTrapezoid: true,
  trapezoidDirection: 0,
  addon: null,
  droneCount: 24,
  canControlDrones: true,
  bullet: {
    type: "drone",
    sizeRatio: 21 / (71.4 / 2),
    health: 12.5,
    damage: 0.5,
    speed: 1.7,
    scatterRate: 1,
    lifeLength: 1.5,
    absorbtionFactor: 1
  }
};
const GUARDIAN_SIZE = 135;
class Guardian extends import_AbstractBoss.default {
  constructor(game) {
    super(game);
    this.nameData.values.name = "Guardian";
    this.altName = "Guardian of the Pentagons";
    this.styleData.values.color = import_Enums.Color.EnemyCrasher;
    this.relationsData.values.team = this.game.arena;
    this.physicsData.values.size = GUARDIAN_SIZE * Math.SQRT1_2;
    this.physicsData.values.sides = 3;
    this.barrels.push(new import_Barrel.default(this, GuardianSpawnerDefinition));
  }
  get sizeFactor() {
    return this.physicsData.values.size / Math.SQRT1_2 / GUARDIAN_SIZE;
  }
  moveAroundMap() {
    super.moveAroundMap();
    this.positionData.angle = Math.atan2(this.inputs.movement.y, this.inputs.movement.x);
  }
  tick(tick) {
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Guardian.js.map
