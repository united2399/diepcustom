var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Square
});
var import_Triangle = __toModule(require("./Triangle"));
var import_AbstractShape = __toModule(require("./AbstractShape"));
var import_Enums = __toModule(require("../../Const/Enums"));
class Square extends import_AbstractShape.default {
  constructor(arena, game, fromEgg = false, shiny = Math.random() < 1e-6) {
    super(game);
    this.finalSize = 55 * Math.SQRT1_2 + (Math.random() * 6.76362956 - 6.76362956 / 2);
    this.perFrameSizeIncrease = (this.finalSize - 16) / 15;
    this.timer = 0;
    this.evolutionTime = (Math.random() * 50 + 30) * 30 + 10;
    this.doEvolve = true;
    this.arena = arena;
    this.game = arena.game;
    if (Math.random() > 0.4)
      this.doEvolve = false;
    this.nameData.values.name = "Square";
    this.healthData.values.health = this.healthData.values.maxHealth = 10;
    if (fromEgg) {
      this.physicsData.values.size = 16;
      this.styleData.values.opacity = 0.5;
    } else
      this.physicsData.values.size = 55 * Math.SQRT1_2 + (Math.random() * 6.76362956 - 6.76362956 / 2);
    this.physicsData.values.sides = 4;
    this.styleData.values.color = shiny ? import_Enums.Color.Shiny : import_Enums.Color.EnemySquare;
    this.damagePerTick = 8;
    this.scoreReward = 10;
    this.isShiny = shiny;
    this.isFromEgg = fromEgg;
    if (shiny) {
      this.scoreReward *= 100;
      this.healthData.values.health = this.healthData.values.maxHealth *= 10;
    }
  }
  tick(tick) {
    this.timer += 1;
    if (this.timer <= 15 && this.isFromEgg) {
      this.physicsData.size += this.perFrameSizeIncrease;
      this.styleData.opacity += 0.5 / 15;
    }
    if (this.timer > this.evolutionTime && this.doEvolve) {
      let shape;
      shape = new import_Triangle.default(this.arena, this.game);
      shape.positionData.values.x = this.positionData.x;
      shape.positionData.values.y = this.positionData.y;
      shape.relationsData.values.owner = shape.relationsData.values.team = this.arena;
      shape.scoreReward *= this.arena.shapeScoreRewardMultiplier;
      this.delete();
    }
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Square.js.map
