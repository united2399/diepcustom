var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Sentry
});
var import_AbstractShape = __toModule(require("./AbstractShape"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_Barrel = __toModule(require("../Tank/Barrel"));
var import_config = __toModule(require("../../config"));
class Sentry extends import_AbstractShape.default {
  constructor(game) {
    super(game);
    this.cameraEntity = this;
    this.reloadTime = 4;
    this.sizeFactor = this.physicsData.values.size / 50 * 100;
    this.targettingSpeed = 1.4;
    let barrel;
    let GuardianSpawnerDefinition = {
      angle: Math.PI,
      offset: 0,
      size: 90,
      width: 67.2,
      delay: 0,
      reload: 4,
      recoil: 0,
      isTrapezoid: true,
      trapezoidDirection: 0,
      addon: null,
      bullet: {
        type: "bullet",
        sizeRatio: 1,
        health: 2.5,
        damage: 1.25,
        speed: 2,
        scatterRate: 0,
        lifeLength: 4,
        absorbtionFactor: 0.8
      }
    };
    barrel = new import_Barrel.default(this, GuardianSpawnerDefinition);
    barrel.styleData.color = import_Enums.Color.Barrel;
    this.ai = new import_AI.AI(this);
    this.ai.viewRange = 1750;
    this.ai.aimSpeed = this.ai.movementSpeed = this.targettingSpeed;
    this.ai["_findTargetInterval"] = import_config.tps;
    this.inputs = this.ai.inputs;
    this.healthData.values.health = this.healthData.values.maxHealth = 500;
    this.physicsData.values.size = 85 * Math.SQRT1_2;
    this.physicsData.values.sides = 3;
    this.physicsData.values.absorbtionFactor = 0.1;
    this.physicsData.values.pushFactor = 12;
    this.styleData.values.color = import_Enums.Color.EnemyCrasher;
    this.scoreReward = 450;
    this.damagePerTick = 20;
  }
  tick(tick) {
    this.ai.aimSpeed = 0;
    this.ai.movementSpeed = this.targettingSpeed;
    if (this.ai.state === import_AI.AIState.idle) {
      this.doIdleRotate = true;
    } else {
      this.doIdleRotate = false;
      this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - this.positionData.values.y, this.ai.inputs.mouse.x - this.positionData.values.x);
      this.accel.add({
        x: this.ai.inputs.movement.x * this.targettingSpeed,
        y: this.ai.inputs.movement.y * this.targettingSpeed
      });
    }
    this.ai.inputs.movement.set({
      x: 0,
      y: 0
    });
    super.tick(tick);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Sentry.js.map
