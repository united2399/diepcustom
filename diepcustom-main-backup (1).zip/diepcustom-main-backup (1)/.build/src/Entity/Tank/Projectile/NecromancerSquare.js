var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => NecromancerSquare
});
var import_Drone = __toModule(require("./Drone"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_AI = __toModule(require("../../AI"));
class NecromancerSquare extends import_Drone.default {
  constructor(barrel, tank, tankDefinition, shootAngle) {
    super(barrel, tank, tankDefinition, shootAngle);
    var _a, _b;
    const bulletDefinition = barrel.definition.bullet;
    this.ai = new import_AI.AI(this);
    this.ai.viewRange = 900;
    this.physicsData.values.sides = 4;
    this.styleData.values.color = ((_b = (_a = tank.relationsData.values.team) == null ? void 0 : _a.teamData) == null ? void 0 : _b.values.teamColor) || import_Enums.Color.NecromancerSquare;
    if (this.physicsData.values.flags & import_Enums.PhysicsFlags.noOwnTeamCollision)
      this.physicsData.values.flags ^= import_Enums.PhysicsFlags.noOwnTeamCollision;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.onlySameOwnerCollision;
    if (tankDefinition && tankDefinition.id === import_Enums.Tank.Battleship) {
      this.lifeLength = 88;
    } else {
      this.lifeLength = Infinity;
      if (this.physicsData.values.flags & import_Enums.PhysicsFlags.canEscapeArena)
        this.physicsData.values.flags ^= import_Enums.PhysicsFlags.canEscapeArena;
    }
    this.deathAccelFactor = 1;
    this.physicsData.values.pushFactor = 4;
    this.physicsData.values.absorbtionFactor = bulletDefinition.absorbtionFactor;
    this.baseSpeed = 0;
  }
  static fromShape(barrel, tank, tankDefinition, shape) {
    const sunchip = new NecromancerSquare(barrel, tank, tankDefinition, shape.positionData.values.angle);
    sunchip.physicsData.values.sides = shape.physicsData.values.sides;
    sunchip.physicsData.values.size = shape.physicsData.values.size;
    sunchip.positionData.values.x = shape.positionData.values.x;
    sunchip.positionData.values.y = shape.positionData.values.y;
    sunchip.positionData.values.angle = shape.positionData.values.angle;
    const shapeDamagePerTick = shape["damagePerTick"];
    sunchip.damagePerTick *= shapeDamagePerTick / 8;
    sunchip.healthData.values.maxHealth = sunchip.healthData.values.health *= shapeDamagePerTick / 8;
    return sunchip;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=NecromancerSquare.js.map
