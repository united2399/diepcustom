var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => Skimmer
});
var import_Barrel = __toModule(require("../Barrel"));
var import_Bullet = __toModule(require("./Bullet"));
var import_Enums = __toModule(require("../../../Const/Enums"));
var import_AI = __toModule(require("../../AI"));
const SkimmerBarrelDefinition = {
  angle: Math.PI / 2,
  offset: 0,
  size: 70,
  width: 42,
  delay: 0,
  reload: 0.35,
  recoil: 0,
  isTrapezoid: false,
  trapezoidDirection: 0,
  addon: null,
  bullet: {
    type: "bullet",
    health: 0.3,
    damage: 3 / 5,
    speed: 1.1,
    scatterRate: 1,
    lifeLength: 0.25,
    sizeRatio: 1,
    absorbtionFactor: 1
  }
};
const _Skimmer = class extends import_Bullet.default {
  constructor(barrel, tank, tankDefinition, shootAngle, direction) {
    super(barrel, tank, tankDefinition, shootAngle);
    this.reloadTime = 15;
    this.rotationPerTick = _Skimmer.BASE_ROTATION;
    this.rotationPerTick = direction;
    this.cameraEntity = tank.cameraEntity;
    const skimmerBarrels = this.skimmerBarrels = [];
    const s1 = new class extends import_Barrel.default {
      resize() {
        super.resize();
        this.physicsData.values.width = this.definition.width;
      }
    }(this, __spreadValues({}, SkimmerBarrelDefinition));
    const s2Definition = __spreadValues({}, SkimmerBarrelDefinition);
    s2Definition.angle += Math.PI;
    const s2 = new class extends import_Barrel.default {
      resize() {
        super.resize();
        this.physicsData.width = this.definition.width;
      }
    }(this, s2Definition);
    s1.styleData.values.color = this.styleData.values.color;
    s2.styleData.values.color = this.styleData.values.color;
    skimmerBarrels.push(s1, s2);
    this.inputs = new import_AI.Inputs();
    this.inputs.flags |= import_Enums.InputFlags.leftclick;
  }
  get sizeFactor() {
    return this.physicsData.values.size / 50;
  }
  tick(tick) {
    this.reloadTime = this.tank.reloadTime;
    this.positionData.angle += this.rotationPerTick;
    super.tick(tick);
    if (this.deletionAnimation)
      return;
  }
};
let Skimmer = _Skimmer;
Skimmer.BASE_ROTATION = 0.1;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=Skimmer.js.map
