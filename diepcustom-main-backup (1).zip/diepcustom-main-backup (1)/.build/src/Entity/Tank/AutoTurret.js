var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  AutoTurretDefinition: () => AutoTurretDefinition,
  default: () => AutoTurret
});
var import_Object = __toModule(require("../Object"));
var import_Barrel = __toModule(require("./Barrel"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_AI = __toModule(require("../AI"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
var import_Live = __toModule(require("../Live"));
const AutoTurretDefinition = {
  angle: 0,
  offset: 0,
  size: 55,
  width: 42 * 0.7,
  delay: 0.01,
  reload: 1,
  recoil: 0.3,
  isTrapezoid: false,
  trapezoidDirection: 0,
  addon: null,
  bullet: {
    type: "bullet",
    health: 1,
    damage: 0.3,
    speed: 1.2,
    scatterRate: 1,
    lifeLength: 1,
    sizeRatio: 1,
    absorbtionFactor: 1
  }
};
class AutoTurret extends import_Object.default {
  constructor(owner, turretDefinition = AutoTurretDefinition, baseSize = 25) {
    super(owner.game);
    this.nameData = new import_FieldGroups.NameGroup(this);
    this.influencedByOwnerInputs = false;
    this.reloadTime = 15;
    this.cameraEntity = owner.cameraEntity;
    this.ai = new import_AI.AI(this);
    this.ai.doAimPrediction = true;
    this.inputs = this.ai.inputs;
    this.owner = owner;
    this.setParent(owner);
    this.relationsData.values.owner = owner;
    this.relationsData.values.team = owner.relationsData.values.team;
    this.physicsData.values.sides = 1;
    this.baseSize = baseSize;
    this.physicsData.values.size = this.baseSize * this.sizeFactor;
    this.styleData.values.color = import_Enums.Color.Barrel;
    this.styleData.values.flags |= import_Enums.StyleFlags.showsAboveParent;
    this.positionData.values.flags |= import_Enums.PositionFlags.absoluteRotation;
    this.nameData.values.name = "Mounted Turret";
    this.nameData.values.flags |= import_Enums.NameFlags.hiddenName;
    this.turret = new import_Barrel.default(this, turretDefinition);
    this.turret.physicsData.values.flags |= import_Enums.PhysicsFlags._unknown;
  }
  get sizeFactor() {
    return this.owner.sizeFactor;
  }
  onKill(killedEntity) {
    if (!(this.owner instanceof import_Live.default))
      return;
    this.owner.onKill(killedEntity);
  }
  tick(tick) {
    if (this.inputs !== this.ai.inputs)
      this.inputs = this.ai.inputs;
    if (this.ai.state === import_AI.AIState.hasTarget)
      this.ai.passiveRotation = Math.random() < 0.5 ? import_AI.AI.PASSIVE_ROTATION : -import_AI.AI.PASSIVE_ROTATION;
    this.physicsData.size = this.baseSize * this.sizeFactor;
    this.ai.aimSpeed = this.turret.bulletAccel;
    this.ai.movementSpeed = 0;
    this.reloadTime = this.owner.reloadTime;
    let useAI = !(this.influencedByOwnerInputs && (this.owner.inputs.attemptingRepel() || this.owner.inputs.attemptingShot()));
    if (!useAI) {
      const { x, y } = this.getWorldPosition();
      let flip = this.owner.inputs.attemptingRepel() ? -1 : 1;
      const deltaPos = { x: (this.owner.inputs.mouse.x - x) * flip, y: (this.owner.inputs.mouse.y - y) * flip };
      if (this.ai.targetFilter({ x: x + deltaPos.x, y: y + deltaPos.y }) === false)
        useAI = true;
      else {
        this.inputs.flags |= import_Enums.InputFlags.leftclick;
        this.positionData.angle = Math.atan2(deltaPos.y, deltaPos.x);
        this.ai.state = import_AI.AIState.hasTarget;
      }
    }
    if (useAI) {
      if (this.ai.state === import_AI.AIState.idle) {
        this.positionData.angle += this.ai.passiveRotation;
        this.turret.attemptingShot = false;
      } else {
        const { x, y } = this.getWorldPosition();
        this.positionData.angle = Math.atan2(this.ai.inputs.mouse.y - y, this.ai.inputs.mouse.x - x);
      }
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AutoTurretDefinition
});
//# sourceMappingURL=AutoTurret.js.map
