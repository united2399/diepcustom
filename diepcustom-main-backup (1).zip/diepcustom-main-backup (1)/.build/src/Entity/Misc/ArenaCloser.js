var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  default: () => ArenaCloser
});
var import_TankBody = __toModule(require("../Tank/TankBody"));
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Camera = __toModule(require("../../Native/Camera"));
var import_AI = __toModule(require("../AI"));
const _ArenaCloser = class extends import_TankBody.default {
  constructor(game) {
    const inputs = new import_AI.Inputs();
    const camera = new import_Camera.CameraEntity(game);
    const setLevel = camera.setLevel;
    camera.setLevel = function(level) {
      setLevel.call(this, level);
      this.sizeFactor *= _ArenaCloser.BASE_SIZE / 50;
    };
    camera.sizeFactor = _ArenaCloser.BASE_SIZE / 50;
    super(game, camera, inputs);
    this.relationsData.values.team = game.arena;
    this.ai = new import_AI.AI(this);
    this.ai.inputs = inputs;
    this.ai.viewRange = Infinity;
    this.setTank(import_Enums.Tank.ArenaCloser);
    const def = this.definition = Object.assign({}, this.definition);
    def.maxHealth = 1e4;
    def.speed = 1;
    this.damagePerTick = 200;
    this.nameData.values.name = "Arena Closer";
    this.styleData.values.color = import_Enums.Color.Neutral;
    this.positionData.values.flags |= import_Enums.PositionFlags.canMoveThroughWalls;
    this.physicsData.values.flags |= import_Enums.PhysicsFlags.canEscapeArena;
    camera.cameraData.values.player = this;
    for (let i = import_Enums.Stat.MovementSpeed; i < import_Enums.Stat.BodyDamage; ++i)
      camera.cameraData.values.statLevels.values[i] = 7;
    this.ai.aimSpeed = this.barrels[0].bulletAccel * 1.6;
    this.setInvulnerability(true);
  }
  tick(tick) {
    this.ai.movementSpeed = this.cameraEntity.cameraData.values.movementSpeed * 10;
    this.inputs = this.ai.inputs;
    if (this.ai.state === import_AI.AIState.idle) {
      const angle = this.positionData.values.angle + this.ai.passiveRotation;
      const mag = Math.sqrt((this.inputs.mouse.x - this.positionData.values.x) ** 2 + (this.inputs.mouse.y - this.positionData.values.y) ** 2);
      this.inputs.mouse.set({
        x: this.positionData.values.x + Math.cos(angle) * mag,
        y: this.positionData.values.y + Math.sin(angle) * mag
      });
    }
    super.tick(tick);
  }
};
let ArenaCloser = _ArenaCloser;
ArenaCloser.BASE_SIZE = 175;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=ArenaCloser.js.map
