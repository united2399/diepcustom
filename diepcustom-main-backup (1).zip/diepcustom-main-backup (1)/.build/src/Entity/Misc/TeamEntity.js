var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
__export(exports, {
  ColorsTeamName: () => ColorsTeamName,
  TeamEntity: () => TeamEntity
});
var import_Enums = __toModule(require("../../Const/Enums"));
var import_Entity = __toModule(require("../../Native/Entity"));
var import_FieldGroups = __toModule(require("../../Native/FieldGroups"));
const ColorsTeamName = {
  [import_Enums.Color.Border]: "BORDER",
  [import_Enums.Color.Barrel]: "BARREL",
  [import_Enums.Color.Tank]: "TANK",
  [import_Enums.Color.TeamBlue]: "BLUE",
  [import_Enums.Color.TeamRed]: "RED",
  [import_Enums.Color.TeamPurple]: "PURPLE",
  [import_Enums.Color.TeamGreen]: "GREEN",
  [import_Enums.Color.Shiny]: "SHINY",
  [import_Enums.Color.EnemySquare]: "SQUARE",
  [import_Enums.Color.EnemyTriangle]: "TRIANGLE",
  [import_Enums.Color.EnemyPentagon]: "PENTAGON",
  [import_Enums.Color.EnemyCrasher]: "CRASHER",
  [import_Enums.Color.Neutral]: "a mysterious group",
  [import_Enums.Color.ScoreboardBar]: "SCOREBOARD",
  [import_Enums.Color.Box]: "MAZE",
  [import_Enums.Color.EnemyTank]: "ENEMY",
  [import_Enums.Color.NecromancerSquare]: "SUNCHIP",
  [import_Enums.Color.Fallen]: "FALLEN",
  [import_Enums.Color.Egg]: "EGG"
};
class TeamEntity extends import_Entity.Entity {
  constructor(game, color, name = ColorsTeamName[color] || "UNKNOWN") {
    super(game);
    this.teamData = new import_FieldGroups.TeamGroup(this);
    this.teamData.values.teamColor = color;
    this.teamName = name;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ColorsTeamName,
  TeamEntity
});
//# sourceMappingURL=TeamEntity.js.map
