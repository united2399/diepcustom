var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
__export(exports, {
  default: () => SpatialHashing
});
class SpatialHashing {
  constructor(cellSize) {
    this.hashMap = new Map();
    this.queryId = 0;
    this.cellSize = cellSize;
  }
  insertEntity(entity) {
    const { sides, size, width } = entity.physicsData.values;
    const { x, y } = entity.positionData.values;
    const isLine = sides === 2;
    const radiW = isLine ? size / 2 : size;
    const radiH = isLine ? width / 2 : size;
    const topX = x - radiW >> this.cellSize;
    const topY = y - radiH >> this.cellSize;
    const bottomX = x + radiW >> this.cellSize;
    const bottomY = y + radiH >> this.cellSize;
    for (let y2 = topY; y2 <= bottomY; ++y2) {
      for (let x2 = topX; x2 <= bottomX; ++x2) {
        const key = x2 | y2 << 10;
        if (!this.hashMap.has(key)) {
          this.hashMap.set(key, []);
        }
        this.hashMap.get(key).push(entity);
      }
    }
  }
  retrieve(x, y, width, height) {
    const result = [];
    const startX = x - width >> this.cellSize;
    const startY = y - height >> this.cellSize;
    const endX = x + width >> this.cellSize;
    const endY = y + height >> this.cellSize;
    for (let y2 = startY; y2 <= endY; ++y2) {
      for (let x2 = startX; x2 <= endX; ++x2) {
        const key = x2 | y2 << 10;
        const cell = this.hashMap.get(key);
        if (cell == null)
          continue;
        for (let i = 0; i < cell.length; ++i) {
          if (cell[i]["_queryId"] != this.queryId) {
            cell[i]["_queryId"] = this.queryId;
            if (cell[i].hash !== 0)
              result.push(cell[i]);
          }
        }
      }
    }
    this.queryId = this.queryId + 1 >>> 0;
    return result;
  }
  retrieveEntitiesByEntity(entity) {
    const { sides, size, width } = entity.physicsData.values;
    const { x, y } = entity.positionData;
    const isLine = sides === 2;
    const w = isLine ? size / 2 : size;
    const h = isLine ? width / 2 : size;
    return this.retrieve(x, y, w, h);
  }
  reset() {
    this.hashMap = new Map();
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
//# sourceMappingURL=SpatialHashing.js.map
