var __defProp = Object.defineProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
__markAsModule(exports);
//# sourceMappingURL=CollisionManager.js.map
