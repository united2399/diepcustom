module.exports = require("./lib/index");
//# sourceMappingURL=index.js.map
